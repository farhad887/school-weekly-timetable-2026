import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import {
  BookOpen,
  CalendarDays,
  ChevronDown,
  ChevronUp,
  Eye,
  EyeOff,
  GraduationCap,
  Users,
  BookPlus,
  CalendarOff,
  Ban,
  Rows3,
  Pencil,
  Trash2,
  Minus,
  Plus,
  Monitor,
  Smartphone,
  Lock,
  Unlock,
  Save,
  FolderOpen,
  RotateCcw,
  Printer,
  FileDown,
  FileUp,
  LoaderCircle,
} from "lucide-react";
const EXCEL_EXPORT_ICON = new URL(
  "../assets/icons/microsoft-excel-icon.svg",
  import.meta.url
).href;
const PDF_EXPORT_ICON = new URL(
  "../assets/icons/pdf-file-color-red-icon.svg",
  import.meta.url
).href;
const WORD_EXPORT_ICON = new URL(
  "../assets/icons/microsoft-word-icon.svg",
  import.meta.url
).href;
import { TimetableSheet, cellKey } from "@/components/timetable/TimetableSheet";
import {
  ClassSheets,
  CLASS_SHEETS_ROOT,
  type PerPage,
  type CopiesPerSheet,
} from "@/components/timetable/ClassSheets";
import {
  TeacherSheets,
  TEACHER_SHEETS_ROOT,
} from "@/components/timetable/TeacherSheets";
import {
  DistributionSheets,
  DISTRIBUTION_ROOT,
} from "@/components/timetable/DistributionSheet";
import {
  DEFAULT_DISTRIBUTION_TYPOGRAPHY,
  type DistributionTypographySettings,
  type SheetFont,
} from "@/lib/typography";
import { useTimetable } from "@/lib/timetable-store";
import {
  entityStyle,
  entityPickerColor,
  TEACHER_COLOR_PALETTE,
  type EntityColorKind,
} from "@/lib/entity-colors";
import {
  solveTimetable,
  findConflicts,
  nameOf,
  swapLessons,
  type LessonLocation,
} from "@/lib/scheduler";
import {
  exportClassSheetsExcel,
  exportTeacherSheetsExcel,
  exportDistributionExcel,
  exportWord,
  exportExcel,
  exportPdf,
  printSheet,
} from "@/lib/exporters";
import {
  downloadTableFile,
  deleteTableFile,
  deleteAllTableFiles,
  importTableFile,
  listTableFiles,
  openTableFile,
  tableFilesUpdatedEvent,
  type TableFileMeta,
} from "@/lib/table-files";
import {
  emptyGrid,
  uid,
  type TimetableState,
  type Named,
} from "@/lib/timetable-types";
import {
  LANGS,
  LANG_LABEL,
  CLASS_NAMES,
  setLang,
  tName,
  useT,
  type Lang,
} from "@/lib/i18n";

type TypographyFont = SheetFont;
type TypographySettings = { font: TypographyFont; titleSize: number; daySize: number; bodySize: number; metadataSize: number; bold: boolean };
type SheetTextSizes = Pick<TypographySettings, "titleSize" | "daySize" | "bodySize" | "metadataSize">;
type SavedScheduleSnapshot = { id: string; name: string; savedAt: string; state: TimetableState };

const TYPOGRAPHY_STORAGE_KEY = "smart-school-planner-typography-v2";
const SAVED_SCHEDULES_STORAGE_KEY = "smart-school-planner-saved-schedules-v1";
const MAX_SAVED_SCHEDULES = 40;
const CLASS_SHEETS_FONT_STORAGE_KEY = "smart-school-planner-class-sheets-font-v1";
const TEACHER_SHEETS_FONT_STORAGE_KEY = "smart-school-planner-teacher-sheets-font-v1";
const CLASS_SHEETS_SIZE_STORAGE_KEY = "smart-school-planner-class-sheets-size-v1";
const TEACHER_SHEETS_SIZE_STORAGE_KEY = "smart-school-planner-teacher-sheets-size-v1";
const DISTRIBUTION_TYPOGRAPHY_STORAGE_KEY = "smart-school-planner-distribution-typography-v1";
const VIEW_MODE_STORAGE_KEY = "smart-school-planner-view-mode-v1";
const TYPOGRAPHY_FONTS: Record<TypographyFont, string> = {
  system: '"Noto Sans Arabic", "Noto Kufi Arabic", "Segoe UI", Tahoma, Arial, sans-serif',
  goran: '"Unikurd Goran", "Noto Sans Arabic", "Segoe UI", Tahoma, Arial, sans-serif',
  jino: '"Unikurd Jino", "Noto Sans Arabic", "Segoe UI", Tahoma, Arial, sans-serif',
};

function readSheetFontSetting(key: string): SheetFont {
  if (typeof window === "undefined") return "jino";
  try {
    const saved = window.localStorage.getItem(key);
    return saved === "system" || saved === "goran" || saved === "jino" ? saved : "jino";
  } catch {
    return "jino";
  }
}

function readSheetTextSizes(key: string): SheetTextSizes {
  const fallback: SheetTextSizes = { titleSize: 27, daySize: 18, bodySize: 14, metadataSize: 14 };
  if (typeof window === "undefined") return fallback;
  try {
    const saved = window.localStorage.getItem(key);
    if (!saved) return fallback;
    const value = JSON.parse(saved) as Partial<SheetTextSizes>;
    const size = (field: keyof SheetTextSizes) => {
      const parsed = Number(value[field]);
      return Number.isFinite(parsed) ? Math.max(8, Math.min(40, Math.round(parsed))) : fallback[field];
    };
    return { titleSize: size("titleSize"), daySize: size("daySize"), bodySize: size("bodySize"), metadataSize: size("metadataSize") };
  } catch {
    return fallback;
  }
}

function readSavedSchedules(): SavedScheduleSnapshot[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = window.localStorage.getItem(SAVED_SCHEDULES_STORAGE_KEY);
    const parsed: unknown = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((item): item is SavedScheduleSnapshot =>
      !!item &&
      typeof item.id === "string" &&
      typeof item.name === "string" &&
      typeof item.savedAt === "string" &&
      !!item.state &&
      Array.isArray(item.state.teachers) &&
      Array.isArray(item.state.subjects) &&
      Array.isArray(item.state.classes) &&
      Array.isArray(item.state.days) &&
      Array.isArray(item.state.assignments) &&
      !!item.state.grid &&
      typeof item.state.grid === "object"
    ).slice(0, MAX_SAVED_SCHEDULES);
  } catch {
    return [];
  }
}

function cloneScheduleState(state: TimetableState): TimetableState {
  return JSON.parse(JSON.stringify(state)) as TimetableState;
}

function readTypographySettings(): TypographySettings {
  const fallback: TypographySettings = { font: "jino", titleSize: 25, daySize: 16, bodySize: 12, metadataSize: 12, bold: true };
  if (typeof window === "undefined") return fallback;
  try {
    const saved = window.localStorage.getItem(TYPOGRAPHY_STORAGE_KEY);
    if (!saved) return fallback;
    const value = JSON.parse(saved) as Partial<TypographySettings> & { size?: number };
    const font: TypographyFont =
      value.font === "goran" || value.font === "jino" ? value.font : "system";
    const oldSize = Number(value.size);
    const readSize = (key: "titleSize" | "daySize" | "bodySize" | "metadataSize", fallbackSize: number) => {
      const n = Number(value[key]);
      if (Number.isFinite(n)) return Math.min(40, Math.max(8, Math.round(n)));
      if (Number.isFinite(oldSize)) return Math.min(40, Math.max(8, Math.round(oldSize)));
      return fallbackSize;
    };
    return {
      font,
      titleSize: readSize("titleSize", 25),
      daySize: readSize("daySize", 16),
      bodySize: readSize("bodySize", 12),
      metadataSize: readSize("metadataSize", 12),
      bold: true,
    };
  } catch {
    return fallback;
  }
}

function readDistributionTypographySettings(): DistributionTypographySettings {
  if (typeof window === "undefined") return DEFAULT_DISTRIBUTION_TYPOGRAPHY;
  try {
    const saved = window.localStorage.getItem(DISTRIBUTION_TYPOGRAPHY_STORAGE_KEY);
    if (!saved) return DEFAULT_DISTRIBUTION_TYPOGRAPHY;
    const value = JSON.parse(saved) as Partial<DistributionTypographySettings>;
    const size = (key: "titleSize" | "contentSize" | "headerSize" | "teacherSize" | "classSize" | "metadataSize") => {
      const n = Number(value[key]);
      return Number.isFinite(n)
        ? Math.max(8, Math.min(40, Math.round(n)))
        : DEFAULT_DISTRIBUTION_TYPOGRAPHY[key];
    };
    return {
      font: value.font === "goran" || value.font === "system" ? value.font : "jino",
      titleSize: size("titleSize"),
      contentSize: size("contentSize"),
      headerSize: size("headerSize"),
      teacherSize: size("teacherSize"),
      classSize: size("classSize"),
      metadataSize: size("metadataSize"),
      bold: true,
    };
  } catch {
    return DEFAULT_DISTRIBUTION_TYPOGRAPHY;
  }
}

function readViewMode(): "auto" | "mobile" | "desktop" {
  // The complete computer canvas is the default on every device, including phones.
  // The mobile button remains available as an optional compact view.
  return "desktop";
}

/* ---------- small ui primitives ---------- */

function Card({
  title,
  children,
  right,
  id,
}: {
  title?: string;
  children: React.ReactNode;
  right?: React.ReactNode;
  id?: string;
}) {
  return (
    <section id={id} className="glass-panel mb-4 rounded-2xl p-4">
      {(title || right) && (
        <div className="mb-3 flex items-center justify-between gap-2">
          {title && <h2 className="text-lg font-bold text-brand">{title}</h2>}
          {right}
        </div>
      )}
      {children}
    </section>
  );
}

function CollapsibleCard({
  sectionId,
  title,
  collapsed,
  onToggle,
  children,
}: {
  sectionId: string;
  title: string;
  collapsed: boolean;
  onToggle: () => void;
  children: React.ReactNode;
}) {
  const { t } = useT();
  return (
    <Card
      id={sectionId}
      title={title}
      right={
        <button
          type="button"
          onClick={onToggle}
          aria-expanded={!collapsed}
          aria-controls={`${sectionId}-content`}
          className="glass-button inline-flex items-center gap-1.5 rounded-xl border border-white/60 px-3 py-2 text-xs font-bold text-brand transition-colors"
        >
          {collapsed ? (
            <Eye size={16} aria-hidden="true" />
          ) : (
            <EyeOff size={16} aria-hidden="true" />
          )}
          <span>{collapsed ? t("btn.show") : t("btn.hide")}</span>
          {collapsed ? (
            <ChevronDown size={14} aria-hidden="true" />
          ) : (
            <ChevronUp size={14} aria-hidden="true" />
          )}
        </button>
      }
    >
      <div id={`${sectionId}-content`} hidden={collapsed}>
        {children}
      </div>
    </Card>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-2 block text-base font-bold text-brand">{label}</span>
      {children}
    </label>
  );
}

const inputCls =
  "w-full min-h-[60px] rounded-lg border border-white/70 bg-white/65 px-4 py-4 text-lg outline-none backdrop-blur-md focus:border-brand";

function GoldBtn({
  children,
  onClick,
  disabled,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="glass-gold-button whitespace-nowrap rounded-xl border border-white/35 px-3 py-2 text-xs font-bold text-gold-foreground shadow-sm transition-all hover:-translate-y-0.5 hover:brightness-105 disabled:opacity-40"
    >
      {children}
    </button>
  );
}

function ExportIcon({
  format,
  size,
}: {
    format: "excel" | "pdf" | "word";
  size?: "A4" | "A3";
}) {
  const label = format === "excel" ? "Excel" : format === "word" ? "Word" : "PDF";
  const icon = format === "excel" ? EXCEL_EXPORT_ICON : format === "word" ? WORD_EXPORT_ICON : PDF_EXPORT_ICON;
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    const end = () => setBusy(false);
    window.addEventListener("smart-school-planner-export-end", end);
    return () => {
      window.removeEventListener("smart-school-planner-export-end", end);
    };
  }, []);
  return (
    <span
      title={size ? `${label} ${size}` : label}
      className="inline-flex min-w-[84px] items-center justify-center gap-2"
      onClick={() => {
        setBusy(true);
        window.setTimeout(() => setBusy(false), 45_000);
      }}
    >
      <span className="relative inline-flex h-12 w-12 items-center justify-center">
        <img src={icon} alt="" aria-hidden="true" className="h-12 w-12 object-contain" />
        {busy && (
          <span className="absolute inset-0 inline-flex items-center justify-center rounded-full bg-white/75" aria-label="لە حالەتی داونلۆدە">
            <LoaderCircle size={34} className="animate-spin text-brand" aria-hidden="true" />
          </span>
        )}
      </span>
      <span aria-hidden="true" className="text-xs font-extrabold">{label}</span>
      {size && <span aria-hidden="true" className="text-xs font-extrabold">{size}</span>}
      <span className="sr-only">{size ? `${label} ${size}` : label}</span>
    </span>
  );
}

function WhiteBtn({
  children,
  onClick,
  disabled,
  className = "",
}: {
  children: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  className?: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className={`glass-gold-button whitespace-nowrap rounded-xl border border-white/35 px-3 py-2 text-xs font-bold text-gold-foreground shadow-sm transition-all hover:-translate-y-0.5 hover:brightness-105 disabled:opacity-40 ${className}`}
    >
      {children}
    </button>
  );
}

function SheetFontPicker({
  label,
  value,
  onChange,
}: {
  label: string;
  value: SheetFont;
  onChange: (font: SheetFont) => void;
}) {
  return (
    <label className="block text-xs font-bold text-brand">
      {label}
      <select
        className={`${inputCls} mt-1 min-h-0 py-2 text-sm`}
        value={value}
        onChange={event => onChange(event.target.value as SheetFont)}
      >
        <option value="jino">Unikurd Jino</option>
        <option value="goran">Unikurd Goran</option>
        <option value="system">فۆنتی سیستەم</option>
      </select>
    </label>
  );
}

function SheetSizePicker({
  value,
  onChange,
}: {
  value: SheetTextSizes;
  onChange: (field: keyof SheetTextSizes, size: number) => void;
}) {
  const fields: { field: keyof SheetTextSizes; label: string }[] = [
    { field: "bodySize", label: "قەبارەی ناوەڕۆک" },
    { field: "daySize", label: "قەبارەی ڕۆژەکان" },
    { field: "titleSize", label: "قەبارەی سەردێڕ و لیبڵ" },
    { field: "metadataSize", label: "قەبارەی زانیاری" },
  ];
  return (
    <div className="grid grid-cols-2 gap-2 md:grid-cols-4">
      {fields.map(({ field, label }) => (
        <label key={field} className="block text-xs font-bold text-brand">
          {label}
          <select
            className={`${inputCls} mt-1 min-h-0 py-2 text-sm`}
            value={value[field]}
            onChange={event => onChange(field, Number(event.target.value))}
          >
            {Array.from({ length: 33 }, (_, index) => index + 8).map(size => (
              <option key={size} value={size}>{size} px</option>
            ))}
          </select>
        </label>
      ))}
    </div>
  );
}

function DistributionSizePicker({
  value,
  onChange,
}: {
  value: DistributionTypographySettings;
  onChange: (field: keyof Pick<DistributionTypographySettings, "titleSize" | "contentSize" | "headerSize" | "teacherSize" | "classSize" | "metadataSize">, size: number) => void;
}) {
  const fields: {
    field: keyof Pick<DistributionTypographySettings, "titleSize" | "contentSize" | "headerSize" | "teacherSize" | "classSize" | "metadataSize">;
    label: string;
  }[] = [
    { field: "contentSize", label: "قەبارەی ناوەڕۆک" },
    { field: "headerSize", label: "قەبارەی سەردێڕ و لیبڵ" },
    { field: "teacherSize", label: "قەبارەی ناوی مامۆستا" },
    { field: "classSize", label: "قەبارەی ناوی پۆل" },
    { field: "titleSize", label: "قەبارەی ناونیشانی خشتە" },
    { field: "metadataSize", label: "قەبارەی زانیاری خوارەوە" },
  ];
  return (
    <div className="grid grid-cols-2 gap-2 md:grid-cols-3">
      {fields.map(({ field, label }) => (
        <label key={field} className="block text-xs font-bold text-brand">
          {label}
          <select
            className={`${inputCls} mt-1 min-h-0 py-2 text-sm`}
            value={value[field]}
            onChange={event => onChange(field, Number(event.target.value))}
          >
            {Array.from({ length: 33 }, (_, index) => index + 8).map(size => (
              <option key={size} value={size}>{size} px</option>
            ))}
          </select>
        </label>
      ))}
    </div>
  );
}

function OkBtn({ onClick }: { onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className="glass-primary-button mt-3 w-full rounded-xl border border-white/30 py-2 text-sm font-bold text-white backdrop-blur-lg"
    >
      OK
    </button>
  );
}

function Chip({
  label,
  onRemove,
  removeLabel,
  style,
  className = "",
}: {
  label: string;
  onRemove: () => void;
  removeLabel: string;
  style?: React.CSSProperties;
  className?: string;
}) {
  return (
    <span
      className={`glass-chip inline-flex items-center gap-1 rounded-lg px-2 py-1 text-xs ${className}`}
      style={style}
    >
      <button
        type="button"
        onClick={onRemove}
        aria-label={`${removeLabel} ${label}`}
        className="text-destructive"
      >
        ✕
      </button>
      {label}
    </span>
  );
}

function NameList({
  label,
  placeholder,
  items,
  onAdd,
  onRemove,
  onUpdateColor,
  display,
  colorKind,
}: {
  label: string;
  placeholder: string;
  items: Pick<Named, "id" | "name" | "color">[];
  onAdd: (name: string) => void;
  onRemove: (id: string) => void;
  onUpdateColor?: (id: string, color: string) => void;
  display?: (name: string) => string;
  colorKind?: EntityColorKind;
}) {
  const { t } = useT();
  const [value, setValue] = useState("");
  const add = () => {
    const v = value.trim();
    if (!v) return;
    onAdd(v);
    setValue("");
  };
  return (
    <div>
      <span className="mb-2 block text-base font-bold text-brand">{label}</span>
      <div className="flex gap-2">
        <input
          className={inputCls}
          placeholder={placeholder}
          value={value}
          onChange={e => setValue(e.target.value)}
          onKeyDown={e => e.key === "Enter" && add()}
        />
        <button
          type="button"
          onClick={add}
          className="shrink-0 glass-button rounded-lg border border-white/60 px-3 text-xs font-bold"
        >
          {t("btn.add")}
        </button>
      </div>
      <div className="mt-2 flex flex-wrap gap-1">
        {items.length === 0 ? (
          <span className="text-xs text-muted-foreground">
            {t("common.none")}
          </span>
        ) : (
          items.map(i => (
            <span key={i.id} className="inline-flex items-center gap-1">
              <Chip
                label={display ? display(i.name) : i.name}
                removeLabel={t("common.remove")}
                onRemove={() => onRemove(i.id)}
                className={colorKind ? "glass-entity-chip" : ""}
                style={
                  colorKind
                    ? entityStyle(i.id, colorKind, false, i.color)
                    : undefined
                }
              />
              {colorKind && onUpdateColor && (
                <input
                  type="color"
                  aria-label={`${t("color.choose")} ${i.name}`}
                  title={`${t("color.choose")} ${i.name}`}
                  value={entityPickerColor(i.id, colorKind, i.color)}
                  onChange={e => onUpdateColor(i.id, e.target.value)}
                  className="entity-color-picker"
                />
              )}
            </span>
          ))
        )}
      </div>
    </div>
  );
}

function TeacherNameList({
  items,
  onAdd,
  onRemove,
  onUpdateSpecialty,
  onUpdateColor,
}: {
  items: Named[];
  onAdd: (name: string, specialty: string) => void;
  onRemove: (id: string) => void;
  onUpdateSpecialty: (id: string, specialty: string) => void;
  onUpdateColor: (id: string, color: string) => void;
}) {
  const { t } = useT();
  const [name, setName] = useState("");
  const [specialty, setSpecialty] = useState("");
  const [openPaletteId, setOpenPaletteId] = useState<string | null>(null);
  const add = () => {
    if (!name.trim()) return;
    onAdd(name.trim(), specialty.trim());
    setName("");
    setSpecialty("");
  };
  return (
    <div>
      <span className="mb-2 block text-base font-bold text-brand">
        {t("label.teachers")}
      </span>
      <div className="grid gap-2 sm:grid-cols-[1fr_1fr_auto]">
        <input
          className={inputCls}
          placeholder={t("ph.teacher")}
          value={name}
          onChange={e => setName(e.target.value)}
          onKeyDown={e => e.key === "Enter" && add()}
        />
        <input
          className={inputCls}
          placeholder={t("ph.specialty")}
          value={specialty}
          onChange={e => setSpecialty(e.target.value)}
          onKeyDown={e => e.key === "Enter" && add()}
        />
        <button
          type="button"
          onClick={add}
          className="glass-button rounded-lg border border-white/60 px-3 text-xs font-bold"
        >
          {t("btn.add")}
        </button>
      </div>
      <div className="mt-3 grid grid-cols-3 gap-3">
        {items.length === 0 ? (
          <span className="text-xs text-muted-foreground">
            {t("common.none")}
          </span>
        ) : (
          items.map(item => (
            <div
              key={item.id}
              className="grid items-center gap-2 rounded-2xl border border-white/70 bg-white/55 p-3 shadow-sm grid-cols-[auto_32px_1fr_32px]"
            >
              <button
                type="button"
                onClick={() => onRemove(item.id)}
                className="text-xs text-destructive"
                aria-label={`${t("common.remove")} ${item.name}`}
              >
                ✕
              </button>
              <span
                className="glass-entity-chip rounded-lg px-2 py-1 text-xs font-semibold"
                style={entityStyle(item.id, "teacher", false, item.color)}
              >
                {item.name}
              </span>
              <input
                type="color"
                aria-label={`${t("color.choose")} ${item.name}`}
                title={`${t("color.choose")} ${item.name}`}
                value={entityPickerColor(item.id, "teacher", item.color)}
                onChange={e => onUpdateColor(item.id, e.target.value)}
                className="entity-color-picker"
              />
              <button
                type="button"
                aria-label={`پیشاندانی ڕەنگەکانی ${item.name}`}
                aria-expanded={openPaletteId === item.id}
                title="ڕەنگە ئامادەکان"
                onClick={() => setOpenPaletteId(current => current === item.id ? null : item.id)}
                className="teacher-palette-toggle"
                style={{ backgroundColor: entityPickerColor(item.id, "teacher", item.color) }}
              />
              <input
                className={`${inputCls} col-span-full text-base`}
                placeholder={t("ph.specialty")}
                value={item.specialty ?? ""}
                onChange={e => onUpdateSpecialty(item.id, e.target.value)}
              />
              {openPaletteId === item.id && (
                <div className="teacher-color-palette col-span-full" aria-label="ڕەنگە ئامادەکانی مامۆستا">
                  {TEACHER_COLOR_PALETTE.map(color => (
                    <button
                      key={color}
                      type="button"
                      title={color}
                      aria-label={`${t("color.choose")} ${color}`}
                      aria-pressed={entityPickerColor(item.id, "teacher", item.color).toUpperCase() === color}
                      onClick={() => onUpdateColor(item.id, color)}
                      className="teacher-color-swatch"
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}

/* ---------- PWA install ---------- */

type BIPEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<unknown>;
};

function useInstallPrompt() {
  const [evt, setEvt] = useState<BIPEvent | null>(null);
  const [ios, setIos] = useState(false);
  const [installed, setInstalled] = useState(false);
  useEffect(() => {
    const standalone =
      window.matchMedia("(display-mode: standalone)").matches ||
      (navigator as unknown as { standalone?: boolean }).standalone === true;
    if (standalone) {
      setInstalled(true);
      return;
    }
    const ua = navigator.userAgent;
    const isIos =
      /iPhone|iPad|iPod/.test(ua) ||
      (ua.includes("Mac") && "ontouchend" in document);
    setIos(isIos);
    const onBip = (e: Event) => {
      e.preventDefault();
      setEvt(e as BIPEvent);
    };
    const onInstalled = () => {
      setInstalled(true);
      setEvt(null);
    };
    window.addEventListener("beforeinstallprompt", onBip);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onBip);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);
  const install = async () => {
    if (!evt) return;
    await evt.prompt();
    setEvt(null);
  };
  return { canInstall: !!evt, ios, installed, install };
}

/* ---------- page ---------- */

export default function Home() {
  const tt = useTimetable();
  const { state, setState } = tt;
  const { lang, t, rtl } = useT();
  const [message, setMessage] = useState<{
    kind: "ok" | "err";
    text: string;
  } | null>(null);
  const [swapSource, setSwapSource] = useState<LessonLocation | null>(null);
  const [lockMode, setLockMode] = useState(false);
  const [saveOpen, setSaveOpen] = useState(false);
  const [tableFilesOpen, setTableFilesOpen] = useState(false);
  const [tableFiles, setTableFiles] = useState<TableFileMeta[]>([]);
  const [tableFileBusyId, setTableFileBusyId] = useState<string | null>(null);
  const tableFileInputRef = useRef<HTMLInputElement>(null);
  const [printPaper, setPrintPaper] = useState<"A4" | "A3">("A4");
  const [printOrientation, setPrintOrientation] = useState<"landscape" | "portrait">("landscape");
  const [distributionPrintOrientation, setDistributionPrintOrientation] = useState<"landscape" | "portrait">("portrait");
  const [savedSchedulesOpen, setSavedSchedulesOpen] = useState(false);
  const [savedSchedules, setSavedSchedules] = useState<SavedScheduleSnapshot[]>(readSavedSchedules);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [classSheetsOpen, setClassSheetsOpen] = useState(false);
  const [teacherSheetsOpen, setTeacherSheetsOpen] = useState(false);
  const [distributionOpen, setDistributionOpen] = useState(false);
  const [distributionTeachers, setDistributionTeachers] = useState(6);
  const [distributionClasses, setDistributionClasses] = useState(6);
  const [distributionSplit, setDistributionSplit] = useState(false);
  const [langOpen, setLangOpen] = useState(false);
  const [typography, setTypography] = useState<TypographySettings>(readTypographySettings);
  const [classSheetsFont, setClassSheetsFont] = useState<SheetFont>(() => readSheetFontSetting(CLASS_SHEETS_FONT_STORAGE_KEY));
  const [teacherSheetsFont, setTeacherSheetsFont] = useState<SheetFont>(() => readSheetFontSetting(TEACHER_SHEETS_FONT_STORAGE_KEY));
  const [classSheetsSizes, setClassSheetsSizes] = useState<SheetTextSizes>(() => readSheetTextSizes(CLASS_SHEETS_SIZE_STORAGE_KEY));
  const [teacherSheetsSizes, setTeacherSheetsSizes] = useState<SheetTextSizes>(() => readSheetTextSizes(TEACHER_SHEETS_SIZE_STORAGE_KEY));
  const [distributionTypography, setDistributionTypography] = useState<DistributionTypographySettings>(readDistributionTypographySettings);
  const [dismissIos, setDismissIos] = useState(false);
  const refreshTableFiles = () => {
    void listTableFiles().then(setTableFiles);
  };
  const handleTableFileImport = async (file: File) => {
    await importTableFile(file);
    refreshTableFiles();
    setTableFilesOpen(true);
  };
  const runTableFileAction = async (id: string, action: (fileId: string) => Promise<boolean>) => {
    setTableFileBusyId(id);
    try {
      const success = await action(id);
      if (!success) setMessage({ kind: "err", text: "کردارەکە لەسەر فایلەکە سەرکەوتوو نەبوو." });
    } finally {
      setTableFileBusyId(null);
    }
  };
  const deleteAllSavedTableFiles = async () => {
    setTableFileBusyId("all");
    try {
      const success = await deleteAllTableFiles();
      if (!success) setMessage({ kind: "err", text: "سڕینەوەی هەموو فایلەکان سەرکەوتوو نەبوو." });
      refreshTableFiles();
    } finally {
      setTableFileBusyId(null);
    }
  };
  useEffect(() => {
    refreshTableFiles();
    const eventName = tableFilesUpdatedEvent();
    window.addEventListener(eventName, refreshTableFiles);
    return () => window.removeEventListener(eventName, refreshTableFiles);
  }, []);
  useEffect(() => {
    const root = document.documentElement;
    root.style.setProperty("--timetable-font-family", TYPOGRAPHY_FONTS[typography.font]);
    root.style.setProperty("--timetable-font-size", `${typography.bodySize}px`);
    root.style.setProperty("--timetable-title-size", `${typography.titleSize}px`);
    root.style.setProperty("--timetable-day-size", `${typography.daySize}px`);
    try {
      window.localStorage.setItem(TYPOGRAPHY_STORAGE_KEY, JSON.stringify(typography));
    } catch {
      // Keep the setting for this session even if storage is unavailable.
    }
  }, [typography]);
  useEffect(() => {
    try {
      window.localStorage.setItem(
        DISTRIBUTION_TYPOGRAPHY_STORAGE_KEY,
        JSON.stringify(distributionTypography)
      );
    } catch {
      // Keep the setting for this session even if storage is unavailable.
    }
  }, [distributionTypography]);
  useEffect(() => {
    try {
      window.localStorage.setItem(CLASS_SHEETS_FONT_STORAGE_KEY, classSheetsFont);
    } catch {
      // Keep the setting for this session even if storage is unavailable.
    }
  }, [classSheetsFont]);
  useEffect(() => {
    try {
      window.localStorage.setItem(TEACHER_SHEETS_FONT_STORAGE_KEY, teacherSheetsFont);
    } catch {
      // Keep the setting for this session even if storage is unavailable.
    }
  }, [teacherSheetsFont]);
  useEffect(() => {
    try {
      window.localStorage.setItem(CLASS_SHEETS_SIZE_STORAGE_KEY, JSON.stringify(classSheetsSizes));
    } catch {
      // Keep the setting for this session even if storage is unavailable.
    }
  }, [classSheetsSizes]);
  useEffect(() => {
    try {
      window.localStorage.setItem(TEACHER_SHEETS_SIZE_STORAGE_KEY, JSON.stringify(teacherSheetsSizes));
    } catch {
      // Keep the setting for this session even if storage is unavailable.
    }
  }, [teacherSheetsSizes]);
  const [collapsedSections, setCollapsedSections] = useState<string[]>(() => {
    if (typeof window === "undefined") return [];
    try {
      const saved = window.localStorage.getItem(
        "smart-school-planner-hidden-entry-sections-v2"
      );
      const parsed: unknown = saved ? JSON.parse(saved) : [];
      return Array.isArray(parsed)
        ? parsed.filter((x): x is string => typeof x === "string")
        : [];
    } catch {
      return [];
    }
  });
  const [selectedSetupSection, setSelectedSetupSection] = useState<
    | "teachers"
    | "subjects"
    | "days"
    | "classes"
    | "lesson"
    | "off"
    | "ban"
    | "pair"
  >(() => {
    if (typeof window === "undefined") return "teachers";
    const saved = window.localStorage.getItem(
      "smart-school-planner-entry-tab-v1"
    );
    const available = [
      "teachers",
      "subjects",
      "days",
      "classes",
      "lesson",
      "off",
      "ban",
      "pair",
    ];
    return available.includes(saved ?? "")
      ? (saved as
          | "teachers"
          | "subjects"
          | "days"
          | "classes"
          | "lesson"
          | "off"
          | "ban"
          | "pair")
      : "teachers";
  });
  const [editingOffId, setEditingOffId] = useState<string | null>(null);
  const [editingBanId, setEditingBanId] = useState<string | null>(null);
  const [editingPairId, setEditingPairId] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<"auto" | "mobile" | "desktop">(
    readViewMode
  );
  const [csPerPage, setCsPerPage] = useState<PerPage>(2);
  const [csCopies, setCsCopies] = useState<CopiesPerSheet>(1);
  const mobileView = viewMode === "mobile";

  const pwa = useInstallPrompt();
  const isSectionCollapsed = (id: string) => collapsedSections.includes(id);
  const toggleSection = (id: string) => {
    setCollapsedSections(current =>
      current.includes(id) ? current.filter(x => x !== id) : [...current, id]
    );
  };

  useEffect(() => {
    window.localStorage.setItem(
      "smart-school-planner-hidden-entry-sections-v2",
      JSON.stringify(collapsedSections)
    );
  }, [collapsedSections]);
  useEffect(() => {
    window.localStorage.setItem(VIEW_MODE_STORAGE_KEY, viewMode);
  }, [viewMode]);

  useEffect(() => {
    window.localStorage.setItem(
      "smart-school-planner-entry-tab-v1",
      selectedSetupSection
    );
  }, [selectedSetupSection]);

  useEffect(() => {
    document.documentElement.dir = rtl ? "rtl" : "ltr";
    document.documentElement.lang = lang;
  }, [rtl, lang]);

  useEffect(() => {
    const root = document.documentElement;
    const updateMobileDesktopScale = () => {
      const scale = Math.min(1, Math.max(0.25, window.innerWidth / 1280));
      root.style.setProperty("--mobile-desktop-scale", String(scale));
    };
    updateMobileDesktopScale();
    window.addEventListener("resize", updateMobileDesktopScale);
    return () => window.removeEventListener("resize", updateMobileDesktopScale);
  }, []);

  const dn = (list: Named[], id: string) => tName(nameOf(list, id), lang);
  const beginEditRule = (section: "off" | "ban" | "pair", id: string) => {
    if (section === "off") setEditingOffId(id);
    if (section === "ban") setEditingBanId(id);
    if (section === "pair") setEditingPairId(id);
    setSelectedSetupSection(section);
    setCollapsedSections(current =>
      current.filter(x => x !== `${section}-form`)
    );
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const totalSlots =
    state.classes.length * state.days.length * state.periodsPerDay;
  const perClass = useMemo(() => {
    const map = new Map<string, number>();
    for (const a of state.assignments)
      map.set(a.classId, (map.get(a.classId) ?? 0) + a.count);
    return map;
  }, [state.assignments]);
  const totalLessons = state.assignments.reduce((s, a) => s + a.count, 0);
  const conflicts = useMemo(() => findConflicts(state), [state]);
  const placed = useMemo(() => {
    let n = 0;
    for (const c of state.classes)
      for (const d of state.days)
        for (const cell of state.grid[c.id]?.[d.id] ?? []) if (cell) n++;
    return n;
  }, [state]);

  const preserveLockedGrid = (original: TimetableState, nextGrid: TimetableState["grid"]) => {
    const grid = structuredClone(nextGrid) as TimetableState["grid"];
    for (const key of original.lockedCells) {
      const [classId, dayId, periodText] = key.split("|");
      const period = Number(periodText);
      const locked = original.grid[classId]?.[dayId]?.[period] ?? null;
      if (grid[classId]?.[dayId] && Number.isInteger(period)) {
        grid[classId][dayId][period] = locked;
      }
    }
    return grid;
  };

  const solveInto = (next: TimetableState, maxAttempts = 12) => {
    const res = solveTimetable(next, Date.now() % 100000, maxAttempts);
    return { next: { ...next, grid: preserveLockedGrid(next, res.grid) }, res };
  };

  const addAssignment = (a: {
    classId: string;
    subjectId: string;
    teacherId: string;
    count: number;
  }) => {
    setSwapSource(null);
    const withA = {
      ...state,
      assignments: [...state.assignments, { id: uid(), ...a }],
    };
    const { next, res } = solveInto(withA);
    setState(() => next);
    setMessage(
      res.missingSix?.length
        ? { kind: "err", text: t("msg.sixthPeriodMissing") }
        : res.ok
          ? { kind: "ok", text: t("msg.added") }
          : { kind: "err", text: t("msg.overflow") }
    );
  };

  const runSolver = (maxAttempts = 12) => {
    setSwapSource(null);
    if (state.assignments.length === 0) {
      setMessage({ kind: "err", text: t("msg.needLessons") });
      return;
    }
    const { next, res } = solveInto(state, maxAttempts);
    setState(() => next);
    const remainingConflicts = findConflicts(next);
    if (res.ok && remainingConflicts.length === 0) {
      setMessage({ kind: "ok", text: t("msg.filled") });
    } else {
      const overflowDetail = res.unplaced
        .map(
          u =>
            `${dn(state.classes, u.classId)} / ${nameOf(state.subjects, u.subjectId)} (${u.count})`
        )
        .join("، ");
      const sixthDetail = res.missingSix
        ?.map(
          rule =>
            `${dn(state.classes, rule.classId)} / ${nameOf(state.subjects, rule.subjectId)}`
        )
        .join("، ");
      const messages = [
        remainingConflicts.length
          ? `هێشتا ${remainingConflicts.length} تەزاربی مامۆستا ماوە؛ خانە قوفڵکراوەکان، ئۆف و قەدەغەکان پشکنە.`
          : "",
        overflowDetail ? `${t("msg.overflow")} ${overflowDetail}` : "",
        sixthDetail ? `${t("msg.sixthPeriodMissing")} ${sixthDetail}` : "",
      ].filter(Boolean);
      setMessage({
        kind: "err",
        text: messages.join(" ") || t("msg.overflow"),
      });
    }
  };

  const clearAll = () => {
    if (!window.confirm(t("msg.confirmClear"))) return;
    setSwapSource(null);
    tt.reset();
    setMessage({ kind: "ok", text: t("msg.cleared") });
  };

  const persistSavedSchedules = (next: SavedScheduleSnapshot[]) => {
    try {
      window.localStorage.setItem(SAVED_SCHEDULES_STORAGE_KEY, JSON.stringify(next));
      setSavedSchedules(next);
      return true;
    } catch {
      setMessage({ kind: "err", text: "نەتوانرا وەشانەکە هەڵبگیرێت؛ شوێنی هەڵگرتنی وێبگەڕ پڕە یان داخراوە." });
      return false;
    }
  };

  const saveCurrentScheduleSnapshot = () => {
    const now = new Date();
    const snapshot: SavedScheduleSnapshot = {
      id: uid(),
      name: `خشتەی هەفتانە — ${now.toLocaleString("en-GB")}`,
      savedAt: now.toISOString(),
      state: cloneScheduleState(state),
    };
    const next = [snapshot, ...savedSchedules].slice(0, MAX_SAVED_SCHEDULES);
    if (persistSavedSchedules(next)) {
      setMessage({ kind: "ok", text: `خشتەی تەواو هەڵگیرا: ${snapshot.name}` });
    }
  };

  const restoreSavedSchedule = (snapshot: SavedScheduleSnapshot) => {
    if (!window.confirm(`خشتەی ئێستا دەگۆڕدرێت. پێش گەڕاندنەوە، وەشانی ئێستات بە خۆکار هەڵدەگیرێت. بەردەوام بیت؟\n\n${snapshot.name}`)) return;
    const currentMatches = JSON.stringify(state) === JSON.stringify(snapshot.state);
    if (!currentMatches) {
      const now = new Date();
      const backup: SavedScheduleSnapshot = {
        id: uid(),
        name: `پێش گەڕاندنەوە — ${now.toLocaleString("en-GB")}`,
        savedAt: now.toISOString(),
        state: cloneScheduleState(state),
      };
      if (!persistSavedSchedules([backup, ...savedSchedules].slice(0, MAX_SAVED_SCHEDULES))) return;
    }
    tt.restore(cloneScheduleState(snapshot.state));
    setSwapSource(null);
    setSavedSchedulesOpen(false);
    setMessage({ kind: "ok", text: `خشتە گەڕێندرایەوە: ${snapshot.name}` });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const deleteSavedSchedule = (snapshot: SavedScheduleSnapshot) => {
    if (!window.confirm(`ئەم وەشانە بسڕدرێتەوە؟\n\n${snapshot.name}`)) return;
    persistSavedSchedules(savedSchedules.filter(item => item.id !== snapshot.id));
  };

  const clearGrid = () => {
    setSwapSource(null);
    setState(s => ({ ...s, grid: preserveLockedGrid(s, emptyGrid(s)) }));
    setMessage(null);
  };

  const smartMoveLesson = (current: TimetableState, from: LessonLocation, to: LessonLocation) => {
    const direct = swapLessons(current, from, to);
    if (direct.ok) return direct;
    const sourceCell = current.grid[from.classId]?.[from.dayId]?.[from.period] ?? null;
    if (!sourceCell) return direct;

    let working = current;
    const relocateToEmpty = (source: LessonLocation, excluded: string[]) => {
      for (const day of working.days) {
        for (let period = 0; period < working.periodsPerDay; period++) {
          const candidate = { classId: source.classId, dayId: day.id, period };
          const key = cellKey(candidate);
          if (
            excluded.includes(key) ||
            working.lockedCells.includes(key) ||
            working.grid[candidate.classId]?.[candidate.dayId]?.[candidate.period]
          )
            continue;
          const result = swapLessons(working, source, candidate);
          if (result.ok) {
            working = { ...working, grid: result.grid };
            return true;
          }
        }
      }
      return false;
    };

    // Clear an occupied destination first, keeping its lesson in the same class.
    if (working.grid[to.classId]?.[to.dayId]?.[to.period]) {
      if (!relocateToEmpty(to, [cellKey(from), cellKey(to)])) return direct;
    }

    // If the source teacher is busy in another class at the destination time,
    // move that lesson to a valid empty slot before placing the source lesson.
    const busyTeacherLocations: LessonLocation[] = working.classes
      .filter(c => c.id !== from.classId)
      .map(c => ({ classId: c.id, dayId: to.dayId, period: to.period }))
      .filter(location => {
        const cell = working.grid[location.classId]?.[location.dayId]?.[location.period];
        return !!cell && cell.teacherId === sourceCell.teacherId;
      });
    for (const busyLocation of busyTeacherLocations) {
      if (!relocateToEmpty(busyLocation, [cellKey(from), cellKey(to)])) return direct;
    }

    const move = swapLessons(working, from, to);
    return move.ok ? move : direct;
  };

  const handleLessonClick = (location: LessonLocation) => {
    if (lockMode) {
      const key = cellKey(location);
      setState(current => ({
        ...current,
        lockedCells: current.lockedCells.includes(key)
          ? current.lockedCells.filter(item => item !== key)
          : [...current.lockedCells, key],
      }));
      setMessage({ kind: "ok", text: "شوێنی خشتە قوفڵ کرا/کرایەوە" });
      return;
    }
    if (!swapSource) {
      setSwapSource(location);
      setMessage({ kind: "ok", text: t("swap.selected") });
      return;
    }
    if (
      swapSource.classId === location.classId &&
      swapSource.dayId === location.dayId &&
      swapSource.period === location.period
    ) {
      setSwapSource(null);
      setMessage(null);
      return;
    }

    const result = smartMoveLesson(state, swapSource, location);
    if (!result.ok) {
      const keyByReason = {
        same: "swap.same",
        empty: "swap.empty",
        class: "swap.class",
        off: "swap.off",
        ban: "swap.ban",
        conflict: "swap.conflict",
        pair: "swap.pair",
        sixth: "swap.sixth",
      } as const;
      setMessage({ kind: "err", text: t(keyByReason[result.reason]) });
      return;
    }
    setState(current => ({ ...current, grid: result.grid }));
    setSwapSource(null);
    setMessage({ kind: "ok", text: t("swap.done") });
  };

  const periodLabel = (p: number) =>
    p === 0 ? t("opt.allDay") : `${t("opt.period")} ${p}`;

  return (
    <div
      dir={rtl ? "rtl" : "ltr"}
      className={`min-h-screen planner-glass-shell pb-16 ${
        mobileView
          ? "mx-auto max-w-[430px] border-x border-border shadow-2xl"
          : "planner-desktop-view"
      }`}
    >
      {/* header */}
      <header className="border-b border-white/20 bg-brand/85 px-4 py-4 text-brand-foreground shadow-lg backdrop-blur-xl">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h1 className="text-xl font-bold">{t("app.title")}</h1>
            <p className="mt-1 text-xs opacity-90">{t("app.subtitle")}</p>
          </div>
          <div className="flex items-start gap-2">
            <button
              type="button"
              onClick={() => setViewMode("mobile")}
              className={`view-mode-trigger glass-button inline-flex items-center gap-1 rounded-xl border border-white/60 px-2 py-2 text-xs font-bold ${viewMode === "mobile" ? "ring-2 ring-white" : ""}`}
              aria-label={t("btn.viewMobile")}
              title={t("btn.viewMobile")}
              aria-pressed={viewMode === "mobile"}
            >
              <Smartphone size={18} aria-hidden="true" />
              <span className="hidden sm:inline">مۆبایل</span>
            </button>
            <button
              type="button"
              onClick={() => setViewMode("desktop")}
              className={`view-mode-trigger glass-button inline-flex items-center gap-1 rounded-xl border border-white/60 px-2 py-2 text-xs font-bold ${viewMode === "desktop" ? "ring-2 ring-white" : ""}`}
              aria-label={t("btn.viewDesktop")}
              title={t("btn.viewDesktop")}
              aria-pressed={viewMode === "desktop"}
            >
              <Monitor size={18} aria-hidden="true" />
              <span className="hidden sm:inline">کۆمپیوتەر</span>
            </button>
            <div className="relative shrink-0">
              <button
                type="button"
                onClick={() => setLangOpen(v => !v)}
                className="flex items-center gap-1 rounded-md bg-white/15 px-3 py-2 text-xs font-bold hover:bg-white/25"
                aria-haspopup="listbox"
                aria-expanded={langOpen}
              >
                🌐 {LANG_LABEL[lang]}
              </button>
              {langOpen && (
                <ul
                  role="listbox"
                  className="glass-popover absolute end-0 z-40 mt-1 min-w-40 overflow-hidden rounded-xl text-foreground"
                >
                  {LANGS.map((l: Lang) => (
                    <li key={l}>
                      <button
                        type="button"
                        role="option"
                        aria-selected={l === lang}
                        onClick={() => {
                          setLang(l);
                          setLangOpen(false);
                        }}
                        className={`block w-full px-3 py-2 text-start text-sm hover:bg-sheet ${
                          l === lang ? "font-bold text-brand" : ""
                        }`}
                      >
                        {LANG_LABEL[l]}
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>

        <div className="mt-3 flex flex-wrap gap-2">
          <WhiteBtn onClick={tt.undo} disabled={!tt.canUndo}>
            {t("btn.undo")}
          </WhiteBtn>
          <WhiteBtn onClick={tt.redo} disabled={!tt.canRedo}>
            {t("btn.redo")}
          </WhiteBtn>
          <GoldBtn onClick={clearGrid}>{t("btn.refresh")}</GoldBtn>
          <GoldBtn onClick={() => runSolver(72)}>{t("btn.fixConflicts")}</GoldBtn>
          <GoldBtn onClick={saveCurrentScheduleSnapshot}>
            <Save size={15} className="mr-1 inline-block" aria-hidden="true" />
            سەیڤ
          </GoldBtn>
          <WhiteBtn onClick={() => setSavedSchedulesOpen(true)}>
            <FolderOpen size={15} className="mr-1 inline-block" aria-hidden="true" />
            خشتە هەڵگیراوەکان ({savedSchedules.length})
          </WhiteBtn>
          <WhiteBtn
            onClick={() => {
              refreshTableFiles();
              setTableFilesOpen(true);
            }}
          >
            <FileUp size={15} className="mr-1 inline-block" aria-hidden="true" />
            فایلەکانی خشتەکان: PDF، Excel، Word ({tableFiles.length})
          </WhiteBtn>
          <input
            ref={tableFileInputRef}
            type="file"
            accept=".pdf,.xls,.xlsx,.doc,.docx,application/pdf,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            className="hidden"
            onChange={event => {
              const file = event.target.files?.[0];
              event.target.value = "";
              if (file) void handleTableFileImport(file);
            }}
          />
          <div className="basis-full flex flex-wrap items-center gap-2 rounded-xl border-t border-white/45 bg-white/10 pt-2">
            <GoldBtn onClick={() => setSaveOpen(true)}>
              <CalendarDays size={16} className="mr-1 inline-block" aria-hidden="true" />
              خشتەی هەفتانە
            </GoldBtn>
            <GoldBtn onClick={() => setClassSheetsOpen(true)}>
              <GraduationCap size={16} className="mr-1 inline-block" aria-hidden="true" />
              {t("btn.classSheets")}
            </GoldBtn>
            <GoldBtn onClick={() => setTeacherSheetsOpen(true)}>
              <Users size={16} className="mr-1 inline-block" aria-hidden="true" />
              {t("btn.teacherSheets")}
            </GoldBtn>
            <GoldBtn onClick={() => setDistributionOpen(true)}>
              <Rows3 size={16} className="mr-1 inline-block" aria-hidden="true" />
              {t("btn.distribution")}
            </GoldBtn>
          </div>
          <WhiteBtn onClick={clearAll}>{t("btn.clearAll")}</WhiteBtn>
          <WhiteBtn onClick={() => setAboutOpen(true)}>
            {t("btn.about")}
          </WhiteBtn>

          {pwa.canInstall && !pwa.installed && (
            <GoldBtn onClick={() => void pwa.install()}>
              {t("btn.install")}
            </GoldBtn>
          )}
        </div>

        {tt.savedAt && (
          <p className="mt-2 text-xs opacity-90">
            {t("saved.at")} ({tt.savedAt})
          </p>
        )}
      </header>

      <main className="mx-auto max-w-[1500px] p-4">
        <Card>
          <p className="text-sm font-bold">
            {t("stats.total")}: {totalLessons} {t("stats.of")} {totalSlots}{" "}
            {t("stats.slots")} — {t("stats.placed")}: {placed}
          </p>
          <div className="mt-2 flex flex-wrap gap-2">
            {state.classes.map(c => (
              <span
                key={c.id}
                className="glass-token rounded-lg px-2 py-1 text-xs"
              >
                {tName(c.name, lang)}: {perClass.get(c.id) ?? 0}/
                {state.days.length * state.periodsPerDay}
              </span>
            ))}
          </div>
          <p
            className={`mt-2 text-xs font-bold ${conflicts.length ? "text-destructive" : "text-brand"}`}
          >
            {conflicts.length === 0
              ? t("stats.noConflict")
              : `⚠ ${conflicts.length} ${t("stats.conflict")}`}
          </p>
        </Card>

        <nav
          aria-label={t("nav.sections")}
          className="mb-4 grid grid-cols-4 gap-3"
        >
          {[
            { id: "teachers", label: t("label.teachers"), Icon: Users },
            { id: "subjects", label: t("label.subjects"), Icon: BookOpen },
            { id: "days", label: t("label.days"), Icon: CalendarDays },
            { id: "classes", label: t("label.classes"), Icon: GraduationCap },
            { id: "lesson", label: t("nav.lessonEntry"), Icon: BookPlus },
            { id: "off", label: t("nav.teacherOff"), Icon: CalendarOff },
            { id: "ban", label: t("nav.subjectBan"), Icon: Ban },
            { id: "pair", label: t("nav.backToBack"), Icon: Rows3 },
          ].map(({ id, label, Icon }) => (
            <button
              key={id}
              type="button"
              onClick={() =>
                setSelectedSetupSection(
                  id as
                    | "teachers"
                    | "subjects"
                    | "days"
                    | "classes"
                    | "lesson"
                    | "off"
                    | "ban"
                    | "pair"
                )
              }
              aria-pressed={selectedSetupSection === id}
              className={`group flex min-h-28 flex-col items-center justify-center gap-2 rounded-xl border p-2 shadow-sm transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand ${
                selectedSetupSection === id
                  ? "border-white/60 bg-brand/80 text-white shadow-lg backdrop-blur-xl"
                  : "border-white/70 bg-white/45 text-brand backdrop-blur-xl hover:-translate-y-0.5 hover:border-white hover:bg-white/65 hover:shadow-md"
              }`}
            >
              <span
                className={`flex h-11 w-11 items-center justify-center rounded-full transition-colors ${selectedSetupSection === id ? "bg-white/20" : "bg-white/60 group-hover:bg-white/80"}`}
              >
                <Icon size={27} strokeWidth={2} aria-hidden="true" />
              </span>
              <span className="text-xs font-bold text-center sm:text-sm">{label}</span>
            </button>
          ))}
        </nav>

        {pwa.canInstall && !pwa.installed && (
          <div className="glass-success-toast mb-3 flex items-center justify-between gap-3 rounded-xl px-3 py-2 text-sm text-brand">
            <span>📲 {t("btn.install").replace("⬇ ", "")}</span>
            <GoldBtn onClick={() => void pwa.install()}>
              {t("btn.install")}
            </GoldBtn>
          </div>
        )}
        {pwa.ios && !pwa.installed && !dismissIos && (
          <div className="glass-success-toast mb-3 flex items-center justify-between gap-3 rounded-xl px-3 py-2 text-sm text-brand">
            <span>📲 {t("install.ios")}</span>
            <button
              type="button"
              className="glass-button rounded-full px-2 py-1 text-xs font-bold"
              onClick={() => setDismissIos(true)}
            >
              ✕
            </button>
          </div>
        )}

        {message && (
          <div
            className={`mb-3 rounded-md px-3 py-2 text-sm ${
              message.kind === "ok"
                ? "glass-success-toast text-brand"
                : "bg-destructive/10 text-destructive"
            }`}
          >
            {message.text}
          </div>
        )}

        {selectedSetupSection === "teachers" && (
          <Card id="teachers" title={t("label.teachers")}>
            <TeacherNameList
              items={state.teachers}
              onAdd={(name, specialty) =>
                setState(s => ({
                  ...s,
                  teachers: [...s.teachers, { id: uid(), name, specialty }],
                }))
              }
              onRemove={id =>
                setState(s => ({
                  ...s,
                  teachers: s.teachers.filter(x => x.id !== id),
                  assignments: s.assignments.filter(a => a.teacherId !== id),
                }))
              }
              onUpdateSpecialty={(id, specialty) =>
                setState(s => ({
                  ...s,
                  teachers: s.teachers.map(teacher =>
                    teacher.id === id ? { ...teacher, specialty } : teacher
                  ),
                }))
              }
              onUpdateColor={(id, color) =>
                setState(s => ({
                  ...s,
                  teachers: s.teachers.map(teacher =>
                    teacher.id === id ? { ...teacher, color } : teacher
                  ),
                }))
              }
            />
          </Card>
        )}
        {selectedSetupSection === "subjects" && (
          <Card id="subjects" title={t("label.subjects")}>
            <NameList
              label={t("label.subjects")}
              placeholder={t("ph.subject")}
              items={state.subjects}
              colorKind="subject"
              onAdd={name =>
                setState(s => ({
                  ...s,
                  subjects: [...s.subjects, { id: uid(), name }],
                }))
              }
              onRemove={id =>
                setState(s => ({
                  ...s,
                  subjects: s.subjects.filter(x => x.id !== id),
                  assignments: s.assignments.filter(a => a.subjectId !== id),
                  pairs: s.pairs.filter(r => r.subjectId !== id),
                }))
              }
              onUpdateColor={(id, color) =>
                setState(s => ({
                  ...s,
                  subjects: s.subjects.map(subject =>
                    subject.id === id ? { ...subject, color } : subject
                  ),
                }))
              }
            />
          </Card>
        )}
        {selectedSetupSection === "days" && (
          <Card id="days" title={t("label.days")}>
            <NameList
              label={t("label.days")}
              placeholder={t("ph.day")}
              items={state.days}
              display={n => tName(n, lang)}
              onAdd={name =>
                setState(s => {
                  const days = [...s.days, { id: uid(), name }];
                  const next = { ...s, days };
                  return { ...next, grid: emptyGrid(next) };
                })
              }
              onRemove={id =>
                setState(s => {
                  const days = s.days.filter(d => d.id !== id);
                  const next = { ...s, days };
                  return { ...next, grid: emptyGrid(next) };
                })
              }
            />
          </Card>
        )}
        {selectedSetupSection === "classes" && (
          <Card id="classes" title={t("label.classes")}>
            <ClassAdder
              items={state.classes}
              onAdd={name =>
                setState(s => {
                  const classes = [...s.classes, { id: uid(), name }];
                  const next = { ...s, classes };
                  return { ...next, grid: emptyGrid(next) };
                })
              }
              onRemove={id =>
                setState(s => {
                  const classes = s.classes.filter(c => c.id !== id);
                  const next = {
                    ...s,
                    classes,
                    assignments: s.assignments.filter(a => a.classId !== id),
                  };
                  return { ...next, grid: emptyGrid(next) };
                })
              }
            />
          </Card>
        )}

        {selectedSetupSection === "lesson" && (
          <LessonForm
            state={state}
            onAdd={addAssignment}
            onMessage={setMessage}
            collapsed={isSectionCollapsed("lesson-form")}
            onToggle={() => toggleSection("lesson-form")}
          />
        )}
        {selectedSetupSection === "off" && (
          <OffForm
            state={state}
            setState={setState}
            editing={state.offs.find(x => x.id === editingOffId)}
            onEditDone={() => setEditingOffId(null)}
            collapsed={isSectionCollapsed("off-form")}
            onToggle={() => toggleSection("off-form")}
          />
        )}
        {selectedSetupSection === "ban" && (
          <BanForm
            state={state}
            setState={setState}
            editing={state.bans.find(x => x.id === editingBanId)}
            onEditDone={() => setEditingBanId(null)}
            collapsed={isSectionCollapsed("ban-form")}
            onToggle={() => toggleSection("ban-form")}
          />
        )}
        {selectedSetupSection === "pair" && (
          <PairForm
            state={state}
            setState={setState}
            editing={state.pairs.find(x => x.id === editingPairId)}
            onEditDone={() => setEditingPairId(null)}
            collapsed={isSectionCollapsed("pair-form")}
            onToggle={() => toggleSection("pair-form")}
          />
        )}

        <Card id="school-info" title={t("sections.schoolInfo")}>
          <div className="grid gap-3 md:grid-cols-7">
            <Field label={t("label.year")}>
              <input
                className={inputCls}
                value={state.year}
                onChange={e => setState(s => ({ ...s, year: e.target.value }))}
              />
            </Field>
            <Field label={t("label.startDate")}>
              <input
                className={inputCls}
                value={state.startDate}
                onChange={e =>
                  setState(s => ({ ...s, startDate: e.target.value }))
                }
              />
            </Field>
            <Field label={t("label.principal")}>
              <input
                className={inputCls}
                value={state.principal}
                onChange={e =>
                  setState(s => ({ ...s, principal: e.target.value }))
                }
              />
            </Field>
            <Field label="ناوی بەڕێوەبەرایەتی">
              <input
                className={inputCls}
                value={state.directorate}
                onChange={e =>
                  setState(s => ({ ...s, directorate: e.target.value }))
                }
              />
            </Field>
            <Field label="ناوی قوتابخانە">
              <input
                className={inputCls}
                value={state.schoolName}
                onChange={e =>
                  setState(s => ({ ...s, schoolName: e.target.value }))
                }
              />
            </Field>
            <Field label="ڕەنگی سەردێڕ">
              <input
                type="color"
                className="h-[60px] w-full cursor-pointer rounded-xl border border-white/60 bg-white p-1"
                value={state.sheetTitleColor || "#263577"}
                onChange={e =>
                  setState(s => ({ ...s, sheetTitleColor: e.target.value }))
                }
                aria-label="ڕەنگی سەردێڕی خشتە"
              />
            </Field>
            <Field label="ڕەنگی نووسینی سەردێڕ">
              <input
                type="color"
                className="h-[60px] w-full cursor-pointer rounded-xl border border-white/60 bg-white p-1"
                value={state.sheetTitleTextColor || "#ffffff"}
                onChange={e =>
                  setState(s => ({ ...s, sheetTitleTextColor: e.target.value }))
                }
                aria-label="ڕەنگی نووسینی سەردێڕی خشتە"
              />
            </Field>
          </div>
        </Card>

        <Card
          id="timetable"
          title={t("sheet.title")}
          right={
            <div className="flex items-center gap-2">
              <GoldBtn
                onClick={() => {
                  tt.save();
                  saveCurrentScheduleSnapshot();
                }}
              >
                <Save size={15} className="mr-1 inline-block" aria-hidden="true" />
                {t("btn.save")}
              </GoldBtn>
              <button
                type="button"
                onClick={() => {
                  setLockMode(current => !current);
                  setSwapSource(null);
                }}
                className={`glass-button inline-flex items-center gap-2 rounded-xl border border-white/60 px-3 py-2 text-xs font-bold ${lockMode ? "glass-selected-control" : ""}`}
                aria-pressed={lockMode}
                title="قوفڵکردن یان کردنەوەی قوفڵی خانە"
              >
                {lockMode ? <Unlock size={16} aria-hidden="true" /> : <Lock size={16} aria-hidden="true" />}
                <span>{lockMode ? "کردنەوەی قوفڵ" : "قوفڵکردنی خانە"}</span>
              </button>
            </div>
          }
        >
          <p
            className="glass-hint mb-3 rounded-xl px-3 py-2 text-xs leading-6 text-brand"
            aria-live="polite"
          >
            {swapSource ? t("swap.selected") : t("swap.hint")}
          </p>
          <div className="timetable-typography overflow-x-auto">
            <div className="min-w-[900px]">
                <TimetableSheet
                  state={state}
                  lang={lang}
                  typography={typography}
                onLessonClick={handleLessonClick}
                onLessonDragStart={location => {
                  setSwapSource(location);
                  setMessage({ kind: "ok", text: t("swap.selected") });
                }}
                onLessonDrop={handleLessonClick}
                selectedLocation={swapSource}
                lockedCells={state.lockedCells}
                lockMode={lockMode}
                onToggleLock={handleLessonClick}
              />
            </div>
          </div>
        </Card>

        <CollapsibleCard
          sectionId="assignment-list"
          title={`${t("list.assignments")} (${state.assignments.length})`}
          collapsed={isSectionCollapsed("assignment-list")}
          onToggle={() => toggleSection("assignment-list")}
        >
          {state.assignments.length === 0 ? (
            <p className="text-xs text-muted-foreground">{t("common.none")}</p>
          ) : (
            <div>
              <div className="mb-2 flex justify-end">
                <button
                  type="button"
                  className="glass-button rounded-xl px-3 py-2 text-xs font-bold text-destructive"
                  onClick={() => {
                    if (!window.confirm(t("msg.confirmClearAssignments"))) return;
                    setState(s => ({
                      ...s,
                      assignments: [],
                      grid: emptyGrid(s),
                      lockedCells: [],
                    }));
                  }}
                >
                  <Trash2 size={14} className="mr-1 inline-block" aria-hidden="true" />
                  {t("btn.clearAll")}
                </button>
              </div>
              <ul className="space-y-1 text-sm">
                {state.assignments.map(a => (
                <li
                  key={a.id}
                  className="glass-list-row flex items-center justify-between rounded-xl px-3 py-2"
                >
                  <span className="flex flex-wrap items-center gap-x-1">
                    {dn(state.classes, a.classId)} —{" "}
                    <span
                      className="glass-entity-chip rounded-lg px-2 py-0.5 text-xs font-bold"
                      style={entityStyle(
                        a.teacherId,
                        "teacher",
                        false,
                        state.teachers.find(t => t.id === a.teacherId)?.color
                      )}
                    >
                      {nameOf(state.subjects, a.subjectId)}
                    </span>{" "}
                    —{" "}
                    <span
                      className="glass-entity-chip rounded-lg px-2 py-0.5 text-xs font-bold"
                      style={entityStyle(
                        a.teacherId,
                        "teacher",
                        false,
                        state.teachers.find(t => t.id === a.teacherId)?.color
                      )}
                    >
                      {nameOf(state.teachers, a.teacherId)}
                    </span>{" "}
                    — {a.count} {t("unit.lessons")}
                  </span>
                  <button
                    type="button"
                    aria-label={t("common.remove")}
                    className="text-destructive"
                    onClick={() =>
                      setState(s => ({
                        ...s,
                        assignments: s.assignments.filter(x => x.id !== a.id),
                      }))
                    }
                  >
                    ✕
                  </button>
                </li>
                ))}
              </ul>
            </div>
          )}
        </CollapsibleCard>

        <CollapsibleCard
          sectionId="off-list"
          title={`${t("list.offs")} (${state.offs.length})`}
          collapsed={isSectionCollapsed("off-list")}
          onToggle={() => toggleSection("off-list")}
        >
          {state.offs.length === 0 ? (
            <p className="text-xs text-muted-foreground">{t("common.none")}</p>
          ) : (
            <div>
              <div className="mb-2 flex justify-end">
                <button
                  type="button"
                  className="glass-button rounded-xl px-3 py-2 text-xs font-bold text-destructive"
                  onClick={() => {
                    if (!window.confirm(t("msg.confirmClearOffs"))) return;
                    setState(s => ({ ...s, offs: [] }));
                    setEditingOffId(null);
                  }}
                >
                  <Trash2 size={14} className="mr-1 inline-block" aria-hidden="true" />
                  {t("btn.clearAll")}
                </button>
              </div>
              <ul className="space-y-1 text-sm">
                {state.offs.map(o => (
                <li
                  key={o.id}
                  className="glass-list-row flex items-center justify-between rounded-xl px-3 py-2"
                >
                  <span className="flex flex-wrap items-center gap-x-1">
                    <span
                      className="glass-entity-chip rounded-lg px-2 py-0.5 text-xs font-bold"
                      style={entityStyle(
                        o.teacherId,
                        "teacher",
                        false,
                        state.teachers.find(t => t.id === o.teacherId)?.color
                      )}
                    >
                      {nameOf(state.teachers, o.teacherId)}
                    </span>{" "}
                    — {dn(state.days, o.dayId)} — {periodLabel(o.period)}
                  </span>
                  <div className="inline-flex shrink-0 items-center gap-1">
                    <button
                      type="button"
                      aria-label={`${t("btn.edit")} ${nameOf(state.teachers, o.teacherId)}`}
                      title={t("btn.edit")}
                      className="glass-button rounded-lg p-2 text-brand"
                      onClick={() => beginEditRule("off", o.id)}
                    >
                      <Pencil size={14} aria-hidden="true" />
                    </button>
                    <button
                      type="button"
                      aria-label={`${t("common.remove")} ${nameOf(state.teachers, o.teacherId)}`}
                      title={t("common.remove")}
                      className="glass-button rounded-lg p-2 text-destructive"
                      onClick={() => {
                        setState(s => ({
                          ...s,
                          offs: s.offs.filter(x => x.id !== o.id),
                        }));
                        setEditingOffId(current =>
                          current === o.id ? null : current
                        );
                      }}
                    >
                      <Trash2 size={14} aria-hidden="true" />
                    </button>
                  </div>
                </li>
                ))}
              </ul>
            </div>
          )}
        </CollapsibleCard>

        <CollapsibleCard
          sectionId="pair-list"
          title={`${t("list.pairs")} (${state.pairs.length})`}
          collapsed={isSectionCollapsed("pair-list")}
          onToggle={() => toggleSection("pair-list")}
        >
          {state.pairs.length === 0 ? (
            <p className="text-xs text-muted-foreground">{t("common.none")}</p>
          ) : (
            <ul className="space-y-1 text-sm">
              {state.pairs.map(r => (
                <li
                  key={r.id}
                  className="glass-list-row flex items-center justify-between rounded-xl px-3 py-2"
                >
                  <span className="flex flex-wrap items-center gap-x-1">
                    {dn(state.classes, r.classId)} — {dn(state.days, r.dayId)} —{" "}
                    <span
                      className="glass-entity-chip rounded-lg px-2 py-0.5 text-xs font-bold"
                      style={entityStyle(
                        r.subjectId,
                        "subject",
                        false,
                        state.subjects.find(s => s.id === r.subjectId)?.color
                      )}
                    >
                      {nameOf(state.subjects, r.subjectId)}
                    </span>
                  </span>
                  <div className="inline-flex shrink-0 items-center gap-1">
                    <button
                      type="button"
                      aria-label={`${t("btn.edit")} ${nameOf(state.subjects, r.subjectId)}`}
                      title={t("btn.edit")}
                      className="glass-button rounded-lg p-2 text-brand"
                      onClick={() => beginEditRule("pair", r.id)}
                    >
                      <Pencil size={14} aria-hidden="true" />
                    </button>
                    <button
                      type="button"
                      aria-label={`${t("common.remove")} ${nameOf(state.subjects, r.subjectId)}`}
                      title={t("common.remove")}
                      className="glass-button rounded-lg p-2 text-destructive"
                      onClick={() => {
                        setState(s => ({
                          ...s,
                          pairs: s.pairs.filter(x => x.id !== r.id),
                        }));
                        setEditingPairId(current =>
                          current === r.id ? null : current
                        );
                      }}
                    >
                      <Trash2 size={14} aria-hidden="true" />
                    </button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CollapsibleCard>

        <CollapsibleCard
          sectionId="ban-list"
          title={`${t("list.bans")} (${state.bans.length})`}
          collapsed={isSectionCollapsed("ban-list")}
          onToggle={() => toggleSection("ban-list")}
        >
          {state.bans.length === 0 ? (
            <p className="text-xs text-muted-foreground">{t("common.none")}</p>
          ) : (
            <div>
              <div className="mb-2 flex justify-end">
                <button
                  type="button"
                  className="glass-button rounded-xl px-3 py-2 text-xs font-bold text-destructive"
                  onClick={() => {
                    if (!window.confirm(t("msg.confirmClearBans"))) return;
                    setState(s => ({ ...s, bans: [] }));
                    setEditingBanId(null);
                  }}
                >
                  <Trash2 size={14} className="mr-1 inline-block" aria-hidden="true" />
                  {t("btn.clearAll")}
                </button>
              </div>
              <ul className="space-y-1 text-sm">
                {state.bans.map(b => (
                <li
                  key={b.id}
                  className="glass-list-row flex items-center justify-between rounded-xl px-3 py-2"
                >
                  <span className="flex flex-wrap items-center gap-x-1">
                    {dn(state.classes, b.classId)} — {dn(state.days, b.dayId)} —{" "}
                    <span
                      className="glass-entity-chip rounded-lg px-2 py-0.5 text-xs font-bold"
                      style={entityStyle(
                        b.subjectId,
                        "subject",
                        false,
                        state.subjects.find(s => s.id === b.subjectId)?.color
                      )}
                    >
                      {nameOf(state.subjects, b.subjectId)}
                    </span>{" "}
                    — {periodLabel(b.period)}
                  </span>
                  <div className="inline-flex shrink-0 items-center gap-1">
                    <button
                      type="button"
                      aria-label={`${t("btn.edit")} ${nameOf(state.subjects, b.subjectId)}`}
                      title={t("btn.edit")}
                      className="glass-button rounded-lg p-2 text-brand"
                      onClick={() => beginEditRule("ban", b.id)}
                    >
                      <Pencil size={14} aria-hidden="true" />
                    </button>
                    <button
                      type="button"
                      aria-label={`${t("common.remove")} ${nameOf(state.subjects, b.subjectId)}`}
                      title={t("common.remove")}
                      className="glass-button rounded-lg p-2 text-destructive"
                      onClick={() => {
                        setState(s => ({
                          ...s,
                          bans: s.bans.filter(x => x.id !== b.id),
                        }));
                        setEditingBanId(current =>
                          current === b.id ? null : current
                        );
                      }}
                    >
                      <Trash2 size={14} aria-hidden="true" />
                    </button>
                  </div>
                </li>
                ))}
              </ul>
            </div>
          )}
        </CollapsibleCard>

        <Card id="settings" title={t("card.settings")}>
          <div className="grid gap-3 md:grid-cols-2">
            <Field label={t("label.periodsPerDay")}>
              <select
                className={inputCls}
                value={state.periodsPerDay}
                onChange={e =>
                  setState(s => {
                    const periodsPerDay = Math.max(
                      1,
                      Math.min(12, Number(e.target.value) || 1)
                    );
                    const next = { ...s, periodsPerDay };
                    return { ...next, grid: emptyGrid(next) };
                  })
                }
              >
                {Array.from({ length: 12 }, (_, i) => i + 1).map(n => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </Field>
            <Field label={t("label.splitPages")}>
              <label className="flex h-9 items-center gap-2 text-sm font-bold">
                <input
                  type="checkbox"
                  checked={state.splitPages}
                  onChange={e =>
                    setState(s => ({ ...s, splitPages: e.target.checked }))
                  }
                />
                {t("label.splitPages")}
              </label>
            </Field>
            {state.splitPages && state.classes.length > 1 && (
              <Field label={t("label.firstPageClasses")}>
                <select
                  className={inputCls}
                  value={Math.max(
                    1,
                    Math.min(state.classes.length, state.firstPageClasses)
                  )}
                  onChange={e =>
                    setState(s => ({
                      ...s,
                      firstPageClasses: Number(e.target.value),
                    }))
                  }
                >
                  {Array.from(
                    { length: Math.min(20, Math.max(9, state.classes.length)) },
                    (_, i) => i + 1
                  ).map(n => (
                    <option key={n} value={n}>
                      {n}
                    </option>
                  ))}
                </select>
              </Field>
            )}
          </div>
        </Card>

        {aboutOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center glass-overlay p-4">
            <div className="max-h-[85vh] w-full max-w-lg overflow-y-auto glass-dialog rounded-2xl p-4">
              <div className="mb-2 flex items-center justify-between gap-2">
                <h3 className="text-lg font-bold text-brand">
                  {t("about.title")}
                </h3>
                <button
                  type="button"
                  onClick={() => setAboutOpen(false)}
                  aria-label={t("btn.close")}
                  title={t("btn.close")}
                  className="glass-button shrink-0 rounded-xl border border-white/60 px-3 py-1.5 text-sm font-bold"
                >
                  ✕
                </button>
              </div>
              <div className="space-y-2 text-sm leading-7">
                <ul className="list-disc space-y-2 ps-5">
                  <li>{t("about.p1")}</li>
                  <li>{t("about.p2")}</li>
                </ul>
                <p className="font-bold">{t("about.features")}</p>
                <ul className="list-disc ps-5">
                  <li>{t("about.f1")}</li>
                  <li>{t("about.f2")}</li>
                  <li>{t("about.f3")}</li>
                  <li>{t("about.f4")}</li>
                  <li>{t("about.f5")}</li>
                  <li>{t("about.f6")}</li>
                  <li>{t("about.f7")}</li>
                  <li>{t("about.f8")}</li>
                </ul>
                <ul className="list-disc space-y-1 border-t border-slate-200 pt-2 ps-5">
                  <li>👤 {t("about.dev")}: {t("about.devName")}</li>
                  <li>📞 {t("about.phone")}: <span dir="ltr">07507229684</span></li>
                  <li>✉️ {t("about.email")}: <span dir="ltr">farhadhamad09@gmail.com</span></li>
                  <li>🏫 {t("label.schoolName")}: قوتابخانەی بنەڕەتی کودەریانی تێکەڵاو</li>
                  <li>📍 {t("label.directorate")}: بەڕێوەبەرایەتی پەروەردەی پیرمام</li>
                </ul>
              </div>
              <button
                type="button"
                onClick={() => setAboutOpen(false)}
                className="mt-3 w-full glass-button rounded-xl border border-white/60 py-2 text-sm font-bold"
              >
                {t("btn.close")}
              </button>
            </div>
          </div>
        )}

        {tableFilesOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center glass-overlay p-4">
            <section className="glass-dialog flex max-h-[86vh] w-full max-w-2xl flex-col rounded-2xl p-4">
              <div className="mb-3 flex items-center justify-between gap-2">
                <div>
                  <h3 className="text-base font-bold text-brand">فایلەکانی خشتەکان</h3>
                  <p className="mt-1 text-xs text-muted-foreground">
                    فایلەکانی PDF و Excel و Word لێرە خەزن دەبن و دەتوانیت بۆ مۆبایل دایانبگریت.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setTableFilesOpen(false)}
                  aria-label={t("btn.close")}
                  className="glass-button rounded-xl border border-white/60 px-3 py-1.5 text-sm font-bold"
                >
                  ✕
                </button>
              </div>
              <div className="mb-3 grid grid-cols-2 gap-2">
                <GoldBtn onClick={() => tableFileInputRef.current?.click()}>
                  <FileUp size={15} className="mr-1 inline-block" aria-hidden="true" />
                  زیادکردنی PDF / Excel / Word
                </GoldBtn>
              </div>
              {tableFiles.length === 0 ? (
                <p className="rounded-xl bg-white/50 p-4 text-center text-sm text-muted-foreground">
                  هیچ فایلێک هێشتا دروست نەکراوە؛ سەرەتا PDF، Excel یان Word دابەزێنە.
                </p>
              ) : (
                <div className="min-h-0 space-y-2 overflow-y-auto">
                  {tableFiles.map(file => (
                    <div key={file.id} className="glass-list-row flex items-center justify-between gap-3 rounded-xl px-3 py-2">
                      <div className="min-w-0">
                        <span className="block max-w-full truncate text-start text-sm font-bold text-brand" title={file.name}>
                          {file.name}
                        </span>
                        <p className="text-xs text-muted-foreground">
                          {new Date(file.createdAt).toLocaleString("en-GB")} · {(file.size / 1024).toFixed(0)} KB
                        </p>
                      </div>
                      <div className="flex shrink-0 flex-wrap gap-2">
                        <WhiteBtn disabled={tableFileBusyId !== null} onClick={() => void runTableFileAction(file.id, openTableFile)}>
                          {tableFileBusyId === file.id ? <LoaderCircle size={15} className="mr-1 inline-block animate-spin" aria-hidden="true" /> : <FolderOpen size={15} className="mr-1 inline-block" aria-hidden="true" />}
                          کردنەوە
                        </WhiteBtn>
                        <WhiteBtn disabled={tableFileBusyId !== null} onClick={() => void runTableFileAction(file.id, downloadTableFile)}>
                          {tableFileBusyId === file.id ? <LoaderCircle size={15} className="mr-1 inline-block animate-spin" aria-hidden="true" /> : <FileDown size={15} className="mr-1 inline-block" aria-hidden="true" />}
                          داگرتن
                        </WhiteBtn>
                        <WhiteBtn disabled={tableFileBusyId !== null} onClick={() => {
                          if (window.confirm(`ئایا دڵنیایت لە سڕینەوەی «${file.name}»؟`)) {
                            void runTableFileAction(file.id, deleteTableFile);
                          }
                        }}>
                          <Trash2 size={15} className="mr-1 inline-block" aria-hidden="true" />
                          سڕینەوە
                        </WhiteBtn>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              <div className="mt-3 grid grid-cols-2 gap-2">
                <GoldBtn
                  disabled={tableFiles.length === 0 || tableFileBusyId === "all"}
                  onClick={() => {
                    if (window.confirm("ئایا دڵنیایت لە سڕینەوەی هەموو فایلە خەزنکراوەکان؟")) {
                      void deleteAllSavedTableFiles();
                    }
                  }}
                >
                  {tableFileBusyId === "all" ? <LoaderCircle size={15} className="mr-1 inline-block animate-spin" aria-hidden="true" /> : <Trash2 size={15} className="mr-1 inline-block" aria-hidden="true" />}
                  سڕینەوەی هەموو فایلەکان
                </GoldBtn>
                <button
                  type="button"
                  onClick={() => setTableFilesOpen(false)}
                  className="glass-button rounded-xl border border-white/60 py-2 text-sm font-bold"
                >
                  {t("btn.close")}
                </button>
              </div>
            </section>
          </div>
        )}

        {saveOpen && createPortal(
          <div dir={rtl ? "rtl" : "ltr"} className="sheet-fullscreen-overlay fixed inset-0 z-50 flex items-center justify-center glass-overlay p-4">
            <div
              className="distribution-modal-content sheet-fullscreen-content weekly-sheet-preview-dialog max-h-[92vh] w-full max-w-[96vw] overflow-y-auto glass-dialog sheet-preview-dialog rounded-2xl p-4"
              style={{
                "--weekly-preview-title-size": `${Math.min(40, typography.titleSize * 2)}px`,
                "--weekly-preview-day-size": `${Math.min(40, typography.daySize * 3)}px`,
                "--weekly-preview-body-size": `${Math.min(40, typography.bodySize * 3)}px`,
                "--weekly-preview-metadata-size": `${Math.min(40, (typography.metadataSize ?? typography.bodySize) * 3)}px`,
              } as React.CSSProperties}
            >
              <div className="sticky top-0 z-10 mb-2 flex items-start justify-between gap-3 bg-white/95 py-1 backdrop-blur relative pr-36">
                <div>
                  <h3 className="text-base font-bold text-brand">
                    خشتەی هەفتانە
                  </h3>
                  <p className="mt-1 text-xs text-muted-foreground">
                    پێشبینینی خشتەی هەفتانە و هەناردەکردنی بە PDF یان Excel
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setSaveOpen(false)}
                  aria-label={t("btn.close")}
                  title={t("btn.close")}
                  className="glass-button shrink-0 rounded-xl border border-white/60 px-4 py-1.5 text-sm font-bold absolute right-0 top-1/2 -translate-y-1/2"
                >
                  ✕ {t("btn.close")}
                </button>
              </div>
              <div className="mb-3 grid gap-2 sm:grid-cols-2">
                <label className="block text-xs font-bold text-brand">
                  {t("print.paper")}
                  <select
                    className={`${inputCls} mt-1 min-h-0 py-2 text-sm`}
                    value={printPaper}
                    onChange={event => setPrintPaper(event.target.value as "A4" | "A3")}
                  >
                    <option value="A4">A4</option>
                    <option value="A3">A3</option>
                  </select>
                </label>
                <label className="block text-xs font-bold text-brand">
                  {t("print.orientation")}
                  <select
                    className={`${inputCls} mt-1 min-h-0 py-2 text-sm`}
                    value={printOrientation}
                    onChange={event => setPrintOrientation(event.target.value as "landscape" | "portrait")}
                  >
                    <option value="landscape">{t("print.landscape")}</option>
                    <option value="portrait">{t("print.portrait")}</option>
                  </select>
                </label>
              </div>
              <div className="glass-inset mb-3 rounded-xl p-3">
                <h4 className="mb-2 text-sm font-bold text-brand">فۆنت و قەبارەی خشتەی هەفتانە</h4>
                <div className="mb-2 grid gap-2 sm:grid-cols-2">
                  <SheetFontPicker
                    label="فۆنتی خشتە"
                    value={typography.font}
                    onChange={font => setTypography(current => ({ ...current, font }))}
                  />
                </div>
                <SheetSizePicker
                  value={typography}
                  onChange={(field, size) => setTypography(current => ({ ...current, [field]: size }))}
                />
              </div>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                <GoldBtn
                  onClick={() => {
                    setSaveOpen(false);
                    void exportExcel(state, printPaper, lang, typography, printOrientation);
                  }}
                >
                  <ExportIcon format="excel" />
                </GoldBtn>
                <GoldBtn onClick={() => exportWord(printPaper, t("sheet.title"), "timetable-pages", lang, printOrientation)}>
                  <ExportIcon format="word" />
                </GoldBtn>
                <GoldBtn
                  onClick={() => {
                    setSaveOpen(false);
                    void exportPdf(printPaper, t("sheet.title"), "timetable-pages", printOrientation);
                  }}
                >
                  <ExportIcon format="pdf" />
                </GoldBtn>
                <GoldBtn onClick={() => printSheet(printPaper, lang, "timetable-pages", printOrientation)}>
                  <Printer size={16} className="mr-1 inline-block" aria-hidden="true" />
                  {t("btn.print")}
                </GoldBtn>
              </div>
              <div className="glass-recess timetable-typography mt-3 overflow-x-auto rounded-xl p-2">
                <TimetableSheet
                  state={state}
                  lang={lang}
                  typography={typography}
                />
              </div>
              <button
                type="button"
                onClick={() => setSaveOpen(false)}
                className="mt-3 w-full glass-button rounded-xl border border-white/60 py-2 text-sm font-bold"
              >
                {t("btn.close")}
              </button>
            </div>
          </div>,
          document.body
        )}

        {savedSchedulesOpen && (
          <div className="fixed inset-0 z-[60] flex items-center justify-center glass-overlay p-4">
            <section
              role="dialog"
              aria-modal="true"
              aria-labelledby="saved-schedules-title"
              dir={rtl ? "rtl" : "ltr"}
              className="glass-dialog flex max-h-[86vh] w-full max-w-2xl flex-col rounded-2xl p-4"
            >
              <div className="mb-3 flex items-center justify-between gap-3">
                <div>
                  <h3 id="saved-schedules-title" className="text-base font-bold text-brand">
                    خشتە هەڵگیراوەکان ({savedSchedules.length})
                  </h3>
                  <p className="mt-1 text-xs text-muted-foreground">
                    هەموو داتاکانی خشتە، دابەشکردن، پۆل و مامۆستا لەگەڵ یەکدا دەپارێزرێن.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setSavedSchedulesOpen(false)}
                  aria-label={t("btn.close")}
                  className="glass-button shrink-0 rounded-xl border border-white/60 px-3 py-1.5 text-sm font-bold"
                >
                  ✕
                </button>
              </div>

              {savedSchedules.length === 0 ? (
                <div className="rounded-xl border border-white/60 bg-white/55 p-6 text-center text-sm">
                  هێشتا هیچ خشتەیەک هەڵنەگیراوە. دوگمەی «هەڵگرتنی خشتە» دابگرە بۆ پاشەکەوتکردنی وەشانێکی نوێ.
                </div>
              ) : (
                <div className="min-h-0 space-y-2 overflow-y-auto pe-1">
                  {savedSchedules.map(snapshot => (
                    <article key={snapshot.id} className="glass-list-row flex flex-wrap items-center justify-between gap-3 rounded-xl p-3">
                      <div className="min-w-0 flex-1">
                        <h4 className="break-words text-sm font-bold">{snapshot.name}</h4>
                        <p className="mt-1 text-xs text-muted-foreground">
                          {new Date(snapshot.savedAt).toLocaleString("en-GB")} · {snapshot.state.year}
                        </p>
                        <p className="mt-1 text-xs text-muted-foreground">
                          {snapshot.state.classes.length} پۆل · {snapshot.state.teachers.length} مامۆستا · {snapshot.state.subjects.length} بابەت · {snapshot.state.assignments.length} دابەشکردن
                        </p>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        <GoldBtn onClick={() => restoreSavedSchedule(snapshot)}>
                          <RotateCcw size={15} className="mr-1 inline-block" aria-hidden="true" />
                          گەڕاندنەوە و بەردەوامبوون
                        </GoldBtn>
                        <WhiteBtn onClick={() => deleteSavedSchedule(snapshot)}>
                          <Trash2 size={15} className="mr-1 inline-block" aria-hidden="true" />
                          سڕینەوە
                        </WhiteBtn>
                      </div>
                    </article>
                  ))}
                </div>
              )}

              <p className="mt-3 text-xs text-muted-foreground">
                لە کاتی گەڕاندنەوە، وەشانی ئێستاتیش بە خۆکار دەپارێزرێت بۆ ئەوەی بتوانیت دووبارە بگەڕێیتەوە.
              </p>
              <button
                type="button"
                onClick={() => setSavedSchedulesOpen(false)}
                className="mt-3 w-full glass-button rounded-xl border border-white/60 py-2 text-sm font-bold"
              >
                {t("btn.close")}
              </button>
            </section>
          </div>
        )}

        {teacherSheetsOpen && createPortal(
          <div className="sheet-fullscreen-overlay distribution-modal-overlay fixed inset-0 z-50 flex items-center justify-center glass-overlay p-4">
            <div className="sheet-fullscreen-content distribution-modal-content max-h-[92vh] w-full max-w-[96vw] overflow-y-auto glass-dialog sheet-preview-dialog rounded-2xl p-4">
              <div className="sticky top-0 z-10 mb-1 flex items-center justify-between gap-2 bg-white/95 py-1 backdrop-blur relative pr-36">
                <div>
                  <h3 className="text-base font-bold text-brand">
                    {t("ts.title")}
                  </h3>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {t("ts.hint")}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setTeacherSheetsOpen(false)}
                  aria-label={t("btn.close")}
                  title={t("btn.close")}
                  className="glass-button shrink-0 rounded-xl border border-white/60 px-4 py-1.5 text-sm font-bold absolute right-0 top-1/2 -translate-y-1/2"
                >
                  ✕ {t("btn.close")}
                </button>
              </div>
              <div className="mb-3 grid gap-2 sm:grid-cols-2">
                <label className="block text-xs font-bold text-brand">
                  {t("print.paper")}
                  <select className={`${inputCls} mt-1 min-h-0 py-2 text-sm`} value={printPaper} onChange={event => setPrintPaper(event.target.value as "A4" | "A3")}>
                    <option value="A4">A4</option>
                    <option value="A3">A3</option>
                  </select>
                </label>
                <label className="block text-xs font-bold text-brand">
                  {t("print.orientation")}
                  <select className={`${inputCls} mt-1 min-h-0 py-2 text-sm`} value={printOrientation} onChange={event => setPrintOrientation(event.target.value as "landscape" | "portrait")}>
                    <option value="landscape">{t("print.landscape")}</option>
                    <option value="portrait">{t("print.portrait")}</option>
                  </select>
                </label>
              </div>
              <div className="glass-inset mb-3 rounded-xl p-3">
                <h4 className="mb-2 text-sm font-bold text-brand">فۆنت و قەبارەی خشتەی مامۆستایان</h4>
                <div className="mb-2 grid gap-2 sm:grid-cols-2">
                  <SheetFontPicker label="فۆنتی خشتە" value={teacherSheetsFont} onChange={setTeacherSheetsFont} />
                </div>
                <SheetSizePicker
                  value={teacherSheetsSizes}
                  onChange={(field, size) => setTeacherSheetsSizes(current => ({ ...current, [field]: size }))}
                />
              </div>
              <div className="mb-3 flex flex-wrap gap-2">
                <GoldBtn
                  onClick={() =>
                    void exportTeacherSheetsExcel(state, printPaper, lang, { ...typography, ...teacherSheetsSizes, font: teacherSheetsFont }, printOrientation)
                  }
                >
                  <ExportIcon format="excel" />
                </GoldBtn>
                <GoldBtn onClick={() => exportWord(printPaper, t("ts.title"), TEACHER_SHEETS_ROOT, lang, printOrientation)}>
                  <ExportIcon format="word" />
                </GoldBtn>
                <GoldBtn
                  onClick={() =>
                    void exportPdf(printPaper, t("ts.title"), TEACHER_SHEETS_ROOT, printOrientation)
                  }
                >
                  <ExportIcon format="pdf" />
                </GoldBtn>
                <GoldBtn onClick={() => printSheet(printPaper, lang, TEACHER_SHEETS_ROOT, printOrientation)}>
                  <Printer size={16} className="mr-1 inline-block" aria-hidden="true" />
                  {t("btn.print")}
                </GoldBtn>
              </div>
              <div className="glass-recess timetable-typography overflow-x-auto rounded-xl p-2">
                <TeacherSheets state={state} lang={lang} typography={{ ...typography, ...teacherSheetsSizes, font: teacherSheetsFont }} />
              </div>
            </div>
          </div>,
          document.body
        )}

        {distributionOpen && createPortal(
          <div className="sheet-fullscreen-overlay distribution-modal-overlay fixed inset-0 z-50 flex items-center justify-center glass-overlay p-4">
            <div className="sheet-fullscreen-content distribution-modal-content max-h-[92vh] w-full max-w-[96vw] overflow-y-auto glass-dialog sheet-preview-dialog rounded-2xl p-4">
              <div className="sticky top-0 z-10 mb-2 flex items-start justify-between gap-3 bg-white/95 py-1 backdrop-blur relative pr-36">
                <div>
                  <h3 className="text-base font-bold text-brand">
                    {t("ds.title")}
                  </h3>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {t("ds.hint")}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setDistributionOpen(false)}
                  aria-label={t("btn.close")}
                  title={t("btn.close")}
                  className="glass-button shrink-0 rounded-xl border border-white/60 px-4 py-1.5 text-sm font-bold absolute right-0 top-1/2 -translate-y-1/2"
                >
                  ✕ {t("btn.close")}
                </button>
              </div>
              <div className="glass-inset mb-3 rounded-xl p-3">
                <label className="mb-3 flex items-center gap-2 text-sm font-bold">
                  <input
                    type="checkbox"
                    checked={distributionSplit}
                    onChange={e => setDistributionSplit(e.target.checked)}
                  />
                  دابەشکردنی خشتە بۆ دوو پەڕە
                </label>
                <div
                  className={`grid gap-2 sm:grid-cols-2 ${distributionSplit ? "" : "opacity-50"}`}
                >
                  <Field label="ژمارەی مامۆستا لە هەر پەڕەیەک">
                    <select
                      disabled={!distributionSplit}
                      className={inputCls}
                      value={distributionTeachers}
                      onChange={e =>
                        setDistributionTeachers(Number(e.target.value))
                      }
                    >
                      {Array.from(
                        { length: Math.max(1, state.teachers.length || 1) },
                        (_, i) => i + 1
                      ).map(n => (
                        <option key={n} value={n}>
                          {n}
                        </option>
                      ))}
                    </select>
                  </Field>
                  <Field label="ژمارەی پۆل لە هەر پەڕەیەک">
                    <select
                      disabled={!distributionSplit}
                      className={inputCls}
                      value={distributionClasses}
                      onChange={e =>
                        setDistributionClasses(Number(e.target.value))
                      }
                    >
                      {Array.from(
                        { length: Math.max(1, state.classes.length || 1) },
                        (_, i) => i + 1
                      ).map(n => (
                        <option key={n} value={n}>
                          {n}
                        </option>
                      ))}
                    </select>
                  </Field>
                </div>
              </div>
              <div className="mb-3 grid gap-2 sm:grid-cols-2">
                <label className="block text-xs font-bold text-brand">
                  {t("print.paper")}
                  <select className={`${inputCls} mt-1 min-h-0 py-2 text-sm`} value={printPaper} onChange={event => setPrintPaper(event.target.value as "A4" | "A3")}>
                    <option value="A4">A4</option>
                    <option value="A3">A3</option>
                  </select>
                </label>
                <label className="block text-xs font-bold text-brand">
                  {t("print.orientation")}
                  <select className={`${inputCls} mt-1 min-h-0 py-2 text-sm`} value={distributionPrintOrientation} onChange={event => setDistributionPrintOrientation(event.target.value as "landscape" | "portrait")}>
                    <option value="landscape">{t("print.landscape")}</option>
                    <option value="portrait">{t("print.portrait")}</option>
                  </select>
                </label>
              </div>
              <div className="glass-inset mb-3 rounded-xl p-3">
                <h4 className="mb-2 text-sm font-bold text-brand">فۆنت و قەبارەی خشتەی دابەشکردنی وانەکان</h4>
                <div className="mb-2 grid gap-2 sm:grid-cols-2">
                  <SheetFontPicker
                    label="فۆنتی خشتە"
                    value={distributionTypography.font}
                    onChange={font => setDistributionTypography(current => ({ ...current, font }))}
                  />
                </div>
                <DistributionSizePicker
                  value={distributionTypography}
                  onChange={(field, size) => setDistributionTypography(current => ({ ...current, [field]: size }))}
                />
              </div>
              <div className="mb-3 grid grid-cols-2 gap-2 sm:grid-cols-3">
                <GoldBtn
                  onClick={() =>
                    void exportDistributionExcel(
                      state,
                      printPaper,
                      lang,
                      distributionSplit
                        ? distributionTeachers
                        : state.teachers.length,
                      distributionSplit
                        ? distributionClasses
                        : state.classes.length,
                      distributionTypography,
                      distributionPrintOrientation
                    )
                  }
                >
                  <ExportIcon format="excel" />
                </GoldBtn>
                <GoldBtn onClick={() => exportWord(printPaper, t("ds.title"), DISTRIBUTION_ROOT, lang, distributionPrintOrientation)}>
                  <ExportIcon format="word" />
                </GoldBtn>
                <GoldBtn
                  onClick={() =>
                    void exportPdf(
                      printPaper,
                      t("ds.title"),
                      DISTRIBUTION_ROOT,
                      distributionPrintOrientation
                    )
                  }
                >
                  <ExportIcon format="pdf" />
                </GoldBtn>
                <WhiteBtn onClick={() => printSheet(printPaper, lang, DISTRIBUTION_ROOT, distributionPrintOrientation)}>
                  <Printer size={16} className="mr-1 inline-block" aria-hidden="true" />
                  {t("print.now")}
                </WhiteBtn>
              </div>
              <div className="glass-recess overflow-x-auto rounded-xl p-2">
                <DistributionSheets
                  state={state}
                  lang={lang}
                  teachersPerPage={
                    distributionSplit
                      ? distributionTeachers
                      : state.teachers.length || 1
                  }
                  classesPerPage={
                    distributionSplit
                      ? distributionClasses
                      : state.classes.length || 1
                  }
                  typography={typography}
                  distributionTypography={distributionTypography}
                />
              </div>
            </div>
          </div>,
          document.body
        )}

        {classSheetsOpen && createPortal(
          <div className="sheet-fullscreen-overlay distribution-modal-overlay fixed inset-0 z-50 flex items-center justify-center glass-overlay p-4">
            <div className="sheet-fullscreen-content distribution-modal-content max-h-[92vh] w-full max-w-[96vw] overflow-y-auto glass-dialog sheet-preview-dialog rounded-2xl p-4">
              <div className="sticky top-0 z-10 mb-1 flex items-center justify-between gap-2 bg-white/95 py-1 backdrop-blur relative pr-36">
                <h3 className="text-base font-bold text-brand">
                  {t("cs.title")}
                </h3>
                <button
                  type="button"
                  onClick={() => setClassSheetsOpen(false)}
                  aria-label={t("btn.close")}
                  title={t("btn.close")}
                  className="glass-button shrink-0 rounded-xl border border-white/60 px-4 py-1.5 text-sm font-bold absolute right-0 top-1/2 -translate-y-1/2"
                >
                  ✕ {t("btn.close")}
                </button>
              </div>
              <p className="mb-3 text-xs text-muted-foreground">
                {t("cs.hint")}
              </p>
              <div className="mb-3 flex flex-wrap items-center gap-2">
                <span className="text-xs font-bold">{t("cs.perPage")}:</span>
                {([1, 2, 3, 4] as const).map(n => (
                  <button
                    key={n}
                    type="button"
                    onClick={() => setCsPerPage(n)}
                    className={`rounded-md border px-3 py-1 text-sm font-bold ${
                      csPerPage === n
                        ? "glass-selected-control border-white/45 bg-brand/75 text-white backdrop-blur-xl"
                        : "glass-button border-white/60 bg-white/35"
                    }`}
                  >
                    {n}
                  </button>
                ))}
                <span className="ms-2 text-xs font-bold">
                  {t("cs.copies")}:
                </span>
                {([1, 2, 3, 4, 5, 6] as const).map(n => (
                  <button
                    key={n}
                    type="button"
                    onClick={() => setCsCopies(n)}
                    className={`rounded-md border px-3 py-1 text-sm font-bold ${
                      csCopies === n
                        ? "glass-selected-control border-white/45 bg-brand/75 text-white backdrop-blur-xl"
                        : "glass-button border-white/60 bg-white/35"
                    }`}
                  >
                    {n}
                  </button>
                ))}
              </div>
              <div className="mb-3 grid gap-2 sm:grid-cols-2">
                <label className="block text-xs font-bold text-brand">
                  {t("print.paper")}
                  <select className={`${inputCls} mt-1 min-h-0 py-2 text-sm`} value={printPaper} onChange={event => setPrintPaper(event.target.value as "A4" | "A3")}>
                    <option value="A4">A4</option>
                    <option value="A3">A3</option>
                  </select>
                </label>
                <label className="block text-xs font-bold text-brand">
                  {t("print.orientation")}
                  <select className={`${inputCls} mt-1 min-h-0 py-2 text-sm`} value={printOrientation} onChange={event => setPrintOrientation(event.target.value as "landscape" | "portrait")}>
                    <option value="landscape">{t("print.landscape")}</option>
                    <option value="portrait">{t("print.portrait")}</option>
                  </select>
                </label>
              </div>

              <div className="glass-inset mb-3 rounded-xl p-3">
                <h4 className="mb-2 text-sm font-bold text-brand">فۆنت و قەبارەی خشتەی پۆلەکان</h4>
                <div className="mb-2 grid gap-2 sm:grid-cols-2">
                  <SheetFontPicker label="فۆنتی خشتە" value={classSheetsFont} onChange={setClassSheetsFont} />
                </div>
                <SheetSizePicker
                  value={classSheetsSizes}
                  onChange={(field, size) => setClassSheetsSizes(current => ({ ...current, [field]: size }))}
                />
              </div>
              <div className="mb-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
                <GoldBtn
                  onClick={() => void exportClassSheetsExcel(state, printPaper, lang, { ...typography, ...classSheetsSizes, font: classSheetsFont }, printOrientation)}
                >
                  <ExportIcon format="excel" />
                </GoldBtn>
                <GoldBtn onClick={() => exportWord(printPaper, t("cs.title"), CLASS_SHEETS_ROOT, lang, printOrientation)}>
                  <ExportIcon format="word" />
                </GoldBtn>
                <GoldBtn
                  onClick={() =>
                    void exportPdf(printPaper, t("cs.title"), CLASS_SHEETS_ROOT, printOrientation)
                  }
                >
                  <ExportIcon format="pdf" />
                </GoldBtn>
                <GoldBtn onClick={() => printSheet(printPaper, lang, CLASS_SHEETS_ROOT, printOrientation)}>
                  <Printer size={16} className="mr-1 inline-block" aria-hidden="true" />
                  {t("btn.print")}
                </GoldBtn>
              </div>
              <div className="glass-recess timetable-typography overflow-x-auto rounded-xl p-2">
                <ClassSheets
                  state={state}
                  lang={lang}
                  perPage={csPerPage}
                  copiesPerSheet={csCopies}
                  typography={{ ...typography, ...classSheetsSizes, font: classSheetsFont }}
                />
              </div>
            </div>
          </div>,
          document.body
        )}
      </main>
    </div>
  );
}

/* ---------- forms ---------- */

type SetState = (fn: (s: TimetableState) => TimetableState) => void;

const KU_LETTERS = "ا ب پ ت ج چ ح خ د ر ز س ش ع غ ف ق ک گ ل م ن ھ و ی".split(
  " "
);
const EN_LETTERS = Array.from({ length: 26 }, (_, i) =>
  String.fromCharCode(65 + i)
);

function ClassAdder({
  items,
  onAdd,
  onRemove,
}: {
  items: { id: string; name: string }[];
  onAdd: (name: string) => void;
  onRemove: (id: string) => void;
}) {
  const { t, lang } = useT();
  // stored base names are always the Kurdish (ku) canonical form; shown translated
  const [baseIdx, setBaseIdx] = useState(0);
  const [branch, setBranch] = useState("");
  const [section, setSection] = useState("");

  const base = CLASS_NAMES.ku[baseIdx]!;
  const name = [base, section, branch].filter(Boolean).join(" - ");

  return (
    <div>
      <span className="mb-2 block text-lg font-bold text-brand">
        {t("class.add")}
      </span>
      <div className="grid gap-2 sm:grid-cols-3">
        <select
          className={inputCls}
          value={baseIdx}
          onChange={e => setBaseIdx(Number(e.target.value))}
        >
          {CLASS_NAMES[lang].map((c, i) => (
            <option key={c} value={i}>
              {c}
            </option>
          ))}
        </select>
        <select
          className={inputCls}
          value={branch}
          onChange={e => setBranch(e.target.value)}
        >
          <option value="">{t("class.noBranch")}</option>
          <option value="زانستی">{t("class.sci")}</option>
          <option value="وێژەیی">{t("class.lit")}</option>
        </select>
        <select
          className={inputCls}
          value={section}
          onChange={e => setSection(e.target.value)}
        >
          <option value="">{t("class.noSection")}</option>
          <optgroup label={t("group.kurdish")}>
            {KU_LETTERS.map(l => (
              <option key={`ku-${l}`} value={l}>
                {l}
              </option>
            ))}
          </optgroup>
          <optgroup label={t("group.english")}>
            {EN_LETTERS.map(l => (
              <option key={`en-${l}`} value={l}>
                {l}
              </option>
            ))}
          </optgroup>
        </select>
      </div>
      <button
        type="button"
        onClick={() => onAdd(name)}
        className="mt-2 glass-button rounded-lg border border-white/60 px-3 py-2 text-xs font-bold"
      >
        {t("btn.add")}: {tName(name, lang)}
      </button>
      <div className="mt-2 flex flex-wrap gap-1">
        {items.map(i => (
          <Chip
            key={i.id}
            label={tName(i.name, lang)}
            removeLabel={t("common.remove")}
            onRemove={() => onRemove(i.id)}
          />
        ))}
      </div>
    </div>
  );
}

function ClassSelect({
  state,
  value,
  onChange,
}: {
  state: TimetableState;
  value: string;
  onChange: (v: string) => void;
}) {
  const { t, lang } = useT();
  return (
    <select
      className={inputCls}
      value={value}
      onChange={e => onChange(e.target.value)}
    >
      <option value="">{t("common.select")}</option>
      {state.classes.map(c => (
        <option key={c.id} value={c.id}>
          {tName(c.name, lang)}
        </option>
      ))}
    </select>
  );
}

function DaySelect({
  state,
  value,
  onChange,
}: {
  state: TimetableState;
  value: string;
  onChange: (v: string) => void;
}) {
  const { t, lang } = useT();
  return (
    <select
      className={inputCls}
      value={value}
      onChange={e => onChange(e.target.value)}
    >
      <option value="">{t("common.select")}</option>
      {state.days.map(d => (
        <option key={d.id} value={d.id}>
          {tName(d.name, lang)}
        </option>
      ))}
    </select>
  );
}

function NamedSelect({
  items,
  value,
  onChange,
}: {
  items: Named[];
  value: string;
  onChange: (v: string) => void;
}) {
  const { t } = useT();
  return (
    <select
      className={inputCls}
      value={value}
      onChange={e => onChange(e.target.value)}
    >
      <option value="">{t("common.select")}</option>
      {items.map(c => (
        <option key={c.id} value={c.id}>
          {c.name}
        </option>
      ))}
    </select>
  );
}

function PeriodSelect({
  state,
  value,
  onChange,
}: {
  state: TimetableState;
  value: number;
  onChange: (v: number) => void;
}) {
  const { t } = useT();
  return (
    <select
      className={inputCls}
      value={value}
      onChange={e => onChange(Number(e.target.value))}
    >
      <option value={0}>{t("opt.allDay")}</option>
      {Array.from({ length: state.periodsPerDay }, (_, i) => i + 1).map(n => (
        <option key={n} value={n}>
          {t("opt.period")} {n}
        </option>
      ))}
    </select>
  );
}

function ChoicePicker({
  label,
  items,
  value,
  onChange,
  display,
  colorKind,
}: {
  label: string;
  items: Pick<Named, "id" | "name" | "color">[];
  value: string;
  onChange: (id: string) => void;
  display?: (item: Pick<Named, "id" | "name" | "color">) => string;
  colorKind?: EntityColorKind;
}) {
  const { t } = useT();
  const [query, setQuery] = useState("");
  const filtered = items.filter(item =>
    (display ? display(item) : item.name)
      .toLocaleLowerCase()
      .includes(query.trim().toLocaleLowerCase())
  );
  return (
    <fieldset className="min-w-0">
      <legend className="mb-2 block text-lg font-bold text-brand">
        {label}
      </legend>
      {items.length > 6 && (
        <input
          type="search"
          className={`${inputCls} mb-1 py-1.5`}
          placeholder={t("ph.search")}
          value={query}
          onChange={e => setQuery(e.target.value)}
        />
      )}
      <div className="flex max-h-36 flex-wrap gap-1.5 overflow-y-auto rounded-xl border border-white/50 bg-white/25 p-2">
        {filtered.map(item => (
          <button
            key={item.id}
            type="button"
            aria-pressed={value === item.id}
            onClick={() => onChange(item.id)}
            className={`lesson-choice-button inline-flex items-center gap-1.5 rounded-lg border px-2.5 py-1.5 text-xs font-semibold transition ${
              value === item.id
                ? "glass-primary-button border-brand/50 text-white ring-2 ring-brand/20"
                : "glass-button border-white/60 text-foreground hover:border-brand/40"
            }`}
          >
            {colorKind && (
              <span
                aria-hidden="true"
                className="h-2.5 w-2.5 shrink-0 rounded-full border border-white/70"
                style={{
                  backgroundColor: entityPickerColor(
                    item.id,
                    colorKind,
                    item.color
                  ),
                }}
              />
            )}
            {display ? display(item) : item.name}
          </button>
        ))}
        {filtered.length === 0 && (
          <span className="px-1 py-1 text-xs text-muted-foreground">
            {t("common.none")}
          </span>
        )}
      </div>
    </fieldset>
  );
}

function RuleActions({
  editing,
  disabled,
  onSave,
  onCancel,
}: {
  editing: boolean;
  disabled: boolean;
  onSave: () => void;
  onCancel: () => void;
}) {
  const { t } = useT();
  return (
    <div className="mt-3 flex flex-wrap gap-2">
      <button
        type="button"
        onClick={onSave}
        disabled={disabled}
        className="glass-primary-button rounded-xl border border-white/40 px-4 py-2 text-sm font-bold text-white disabled:cursor-not-allowed disabled:opacity-40"
      >
        {editing ? t("btn.update") : t("btn.add")}
      </button>
      {editing && (
        <button
          type="button"
          onClick={onCancel}
          className="glass-button rounded-xl border border-white/60 px-4 py-2 text-sm font-bold text-brand"
        >
          {t("btn.cancel")}
        </button>
      )}
    </div>
  );
}

function LessonForm({
  state,
  onAdd,
  onMessage,
  collapsed,
  onToggle,
}: {
  state: TimetableState;
  onAdd: (a: {
    classId: string;
    subjectId: string;
    teacherId: string;
    count: number;
  }) => void;
  onMessage: (m: { kind: "ok" | "err"; text: string } | null) => void;
  collapsed: boolean;
  onToggle: () => void;
}) {
  const { t } = useT();
  const [classId, setClassId] = useState("");
  const [subjectId, setSubjectId] = useState("");
  const [teacherId, setTeacherId] = useState("");
  const [count, setCount] = useState(1);
  useEffect(() => {
    if (!classId && state.classes[0]) setClassId(state.classes[0].id);
    if (!subjectId && state.subjects[0]) setSubjectId(state.subjects[0].id);
    if (!teacherId && state.teachers[0]) setTeacherId(state.teachers[0].id);
  }, [classId, subjectId, teacherId, state.classes, state.subjects, state.teachers]);
  return (
    <CollapsibleCard
      sectionId="lesson-form"
      title={t("card.lesson")}
      collapsed={collapsed}
      onToggle={onToggle}
    >
      <p className="glass-hint mb-3 rounded-xl px-3 py-2 text-xs leading-6 text-brand">
        {t("msg.sixthPeriodHint")} — پۆل، بابەت و مامۆستا بە یەک کلیک هەڵبژێرە؛ پاشان زیادکردن دابگرە.
      </p>
      <div className="grid gap-3 md:grid-cols-3">
        <ChoicePicker
          label={t("label.class")}
          items={state.classes}
          value={classId}
          onChange={setClassId}
        />
        <ChoicePicker
          label={t("label.subject")}
          items={state.subjects}
          value={subjectId}
          onChange={setSubjectId}
          colorKind="subject"
        />
        <ChoicePicker
          label={t("label.teacher")}
          items={state.teachers}
          value={teacherId}
          onChange={setTeacherId}
          colorKind="teacher"
        />
        <Field label={t("label.count")}>
          <div className="flex flex-wrap gap-1.5 rounded-xl border border-white/50 bg-white/25 p-2">
            {Array.from({ length: 10 }, (_, i) => i + 1).map(n => (
              <button
                key={n}
                type="button"
                onClick={() => setCount(n)}
                aria-pressed={count === n}
                className={`lesson-count-button h-[70px] min-w-[70px] rounded-lg border px-3 text-base font-bold transition ${count === n ? "glass-primary-button text-white" : "glass-button text-brand"}`}
              >
                {n}
              </button>
            ))}
          </div>
        </Field>
      </div>
      <OkBtn
        onClick={() => {
          if (!classId || !subjectId || !teacherId) {
            onMessage({ kind: "err", text: t("msg.pickAll") });
            return;
          }
          const dup = state.assignments.find(
            a =>
              a.classId === classId &&
              a.subjectId === subjectId &&
              a.teacherId === teacherId
          );
          if (dup) {
            onMessage({ kind: "err", text: t("msg.dup") });
            return;
          }
          onAdd({ classId, subjectId, teacherId, count });
          setSubjectId("");
          setTeacherId("");
          setCount(1);
        }}
      />
    </CollapsibleCard>
  );
}

function OffForm({
  state,
  setState,
  editing,
  onEditDone,
  collapsed,
  onToggle,
}: {
  state: TimetableState;
  setState: SetState;
  editing?: TimetableState["offs"][number];
  onEditDone: () => void;
  collapsed: boolean;
  onToggle: () => void;
}) {
  const { t, lang } = useT();
  const [dayId, setDayId] = useState("");
  const [teacherId, setTeacherId] = useState("");
  const [period, setPeriod] = useState(0);
  useEffect(() => {
    if (!editing) return;
    setDayId(editing.dayId);
    setTeacherId(editing.teacherId);
    setPeriod(editing.period);
  }, [editing?.id]);
  const periodChoices = [
    { id: "0", name: t("opt.allDay") },
    ...Array.from(
      { length: Math.max(state.periodsPerDay, editing?.period ?? 0) },
      (_, i) => ({
        id: String(i + 1),
        name: `${t("opt.period")} ${i + 1}`,
      })
    ),
  ];
  return (
    <CollapsibleCard
      sectionId="off-form"
      title={editing ? `${t("card.off")} — ${t("btn.edit")}` : t("card.off")}
      collapsed={collapsed}
      onToggle={onToggle}
    >
      <div className="grid gap-3 md:grid-cols-3">
        <ChoicePicker
          label={t("label.teacher")}
          items={state.teachers}
          value={teacherId}
          onChange={setTeacherId}
          colorKind="teacher"
        />
        <ChoicePicker
          label={t("label.day")}
          items={state.days}
          value={dayId}
          onChange={setDayId}
          display={item => tName(item.name, lang)}
        />
        <ChoicePicker
          label={t("label.period")}
          items={periodChoices}
          value={String(period)}
          onChange={value => setPeriod(Number(value))}
        />
      </div>
      <RuleActions
        editing={!!editing}
        disabled={!dayId || !teacherId}
        onCancel={onEditDone}
        onSave={() => {
          if (!dayId || !teacherId) return;
          setState(s => ({
            ...s,
            offs: editing
              ? s.offs.map(x =>
                  x.id === editing.id ? { ...x, dayId, teacherId, period } : x
                )
              : [...s.offs, { id: uid(), dayId, teacherId, period }],
          }));
          if (editing) onEditDone();
        }}
      />
    </CollapsibleCard>
  );
}

function BanForm({
  state,
  setState,
  editing,
  onEditDone,
  collapsed,
  onToggle,
}: {
  state: TimetableState;
  setState: SetState;
  editing?: TimetableState["bans"][number];
  onEditDone: () => void;
  collapsed: boolean;
  onToggle: () => void;
}) {
  const { t, lang } = useT();
  const [classId, setClassId] = useState("");
  const [dayId, setDayId] = useState("");
  const [subjectId, setSubjectId] = useState("");
  const [period, setPeriod] = useState(1);
  useEffect(() => {
    if (!editing) return;
    setClassId(editing.classId);
    setDayId(editing.dayId);
    setSubjectId(editing.subjectId);
    setPeriod(editing.period);
  }, [editing?.id]);
  const periodChoices = [
    { id: "0", name: t("opt.allDay") },
    ...Array.from(
      { length: Math.max(state.periodsPerDay, editing?.period ?? 0) },
      (_, i) => ({
        id: String(i + 1),
        name: `${t("opt.period")} ${i + 1}`,
      })
    ),
  ];
  return (
    <CollapsibleCard
      sectionId="ban-form"
      title={editing ? `${t("card.ban")} — ${t("btn.edit")}` : t("card.ban")}
      collapsed={collapsed}
      onToggle={onToggle}
    >
      <div className="grid gap-3 md:grid-cols-2">
        <ChoicePicker
          label={t("label.class")}
          items={state.classes}
          value={classId}
          onChange={setClassId}
          display={item => tName(item.name, lang)}
        />
        <ChoicePicker
          label={t("label.day")}
          items={state.days}
          value={dayId}
          onChange={setDayId}
          display={item => tName(item.name, lang)}
        />
        <ChoicePicker
          label={t("label.subject")}
          items={state.subjects}
          value={subjectId}
          onChange={setSubjectId}
          colorKind="subject"
        />
        <ChoicePicker
          label={t("label.banPeriod")}
          items={periodChoices}
          value={String(period)}
          onChange={value => setPeriod(Number(value))}
        />
      </div>
      <RuleActions
        editing={!!editing}
        disabled={!classId || !dayId || !subjectId}
        onCancel={onEditDone}
        onSave={() => {
          if (!classId || !dayId || !subjectId) return;
          setState(s => ({
            ...s,
            bans: editing
              ? s.bans.map(x =>
                  x.id === editing.id
                    ? { ...x, classId, dayId, subjectId, period }
                    : x
                )
              : [...s.bans, { id: uid(), classId, dayId, subjectId, period }],
          }));
          if (editing) onEditDone();
        }}
      />
    </CollapsibleCard>
  );
}

function PairForm({
  state,
  setState,
  editing,
  onEditDone,
  collapsed,
  onToggle,
}: {
  state: TimetableState;
  setState: SetState;
  editing?: TimetableState["pairs"][number];
  onEditDone: () => void;
  collapsed: boolean;
  onToggle: () => void;
}) {
  const { t, lang } = useT();
  const [classId, setClassId] = useState("");
  const [dayId, setDayId] = useState("");
  const [subjectId, setSubjectId] = useState("");
  useEffect(() => {
    if (!editing) return;
    setClassId(editing.classId);
    setDayId(editing.dayId);
    setSubjectId(editing.subjectId);
  }, [editing?.id]);
  return (
    <CollapsibleCard
      sectionId="pair-form"
      title={editing ? `${t("card.pair")} — ${t("btn.edit")}` : t("card.pair")}
      collapsed={collapsed}
      onToggle={onToggle}
    >
      <div className="grid gap-3 md:grid-cols-3">
        <ChoicePicker
          label={t("label.class")}
          items={state.classes}
          value={classId}
          onChange={setClassId}
          display={item => tName(item.name, lang)}
        />
        <ChoicePicker
          label={t("label.day")}
          items={state.days}
          value={dayId}
          onChange={setDayId}
          display={item => tName(item.name, lang)}
        />
        <ChoicePicker
          label={t("label.subject")}
          items={state.subjects}
          value={subjectId}
          onChange={setSubjectId}
          colorKind="subject"
        />
      </div>
      <RuleActions
        editing={!!editing}
        disabled={!classId || !dayId || !subjectId}
        onCancel={onEditDone}
        onSave={() => {
          if (!classId || !dayId || !subjectId) return;
          setState(s => ({
            ...s,
            pairs: editing
              ? s.pairs.map(x =>
                  x.id === editing.id ? { ...x, classId, dayId, subjectId } : x
                )
              : [...s.pairs, { id: uid(), classId, dayId, subjectId }],
          }));
          if (editing) onEditDone();
        }}
      />
    </CollapsibleCard>
  );
}

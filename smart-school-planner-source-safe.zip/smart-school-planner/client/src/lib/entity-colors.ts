import type { CSSProperties } from "react";

export type EntityColorKind = "teacher" | "subject";

/** High-contrast presets kept visually far apart for teacher identification. */
export const TEACHER_COLOR_PALETTE = [
  "#E6194B", "#F58231", "#FFE119", "#3CB44B", "#008B45",
  "#42D4F4", "#0288D1", "#4363D8", "#3F2B96", "#911EB4",
  "#F032E6", "#C2185B", "#800000", "#9A6324", "#808000",
  "#469990", "#000075", "#7B61A8", "#B22222", "#455A64",
] as const;

type EntityStyle = CSSProperties & {
  "--entity-color": string;
  "--entity-glass": string;
  "--entity-stripe": string;
};

function normalizedHex(color?: string): string | undefined {
  return color && /^#[0-9a-f]{6}$/i.test(color)
    ? color.toUpperCase()
    : undefined;
}

function customRgb(color: string) {
  return [1, 3, 5].map(offset => parseInt(color.slice(offset, offset + 2), 16));
}

function entityHash(id: string, kind: EntityColorKind): number {
  let hash = 2166136261;
  const seed = `${kind}:${id}`;
  for (let i = 0; i < seed.length; i++) {
    hash ^= seed.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}

function entityTone(id: string, kind: EntityColorKind) {
  const hash = entityHash(id, kind);
  return {
    hue: hash % 360,
    saturation: 58 + (Math.floor(hash / 360) % 22),
    lightness: 33 + (Math.floor(hash / (360 * 22)) % 12),
  };
}

/** Stable fallback colors come from IDs; user-picked hex values override them. */
export function entityHue(id: string, kind: EntityColorKind): number {
  return entityTone(id, kind).hue;
}

export function entityColor(
  id: string,
  kind: EntityColorKind,
  preferredColor?: string
): string {
  const custom = normalizedHex(preferredColor);
  if (custom) return custom;
  if (kind === "teacher") return TEACHER_COLOR_PALETTE[entityHash(id, kind) % TEACHER_COLOR_PALETTE.length];
  const tone = entityTone(id, kind);
  return `hsl(${tone.hue}, ${tone.saturation}%, ${tone.lightness}%)`;
}

export function entityGlass(
  id: string,
  kind: EntityColorKind,
  preferredColor?: string
): string {
  const custom = normalizedHex(preferredColor);
  if (custom) {
    const [r, g, b] = customRgb(custom);
    return `rgba(${r}, ${g}, ${b}, 0.2)`;
  }
  const tone = entityTone(id, kind);
  return `hsla(${tone.hue}, ${tone.saturation}%, 84%, 0.52)`;
}

function hslToHex(hue: number, saturation: number, lightness: number): string {
  const s = saturation / 100;
  const l = lightness / 100;
  const k = (n: number) => (n + hue / 30) % 12;
  const a = s * Math.min(l, 1 - l);
  const channel = (n: number) => {
    const value =
      l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1)));
    return Math.round(255 * value)
      .toString(16)
      .padStart(2, "0");
  };
  return `FF${channel(0)}${channel(8)}${channel(4)}`.toUpperCase();
}

/** ExcelJS fill values use opaque ARGB, so custom glass tints are mixed with white. */
export function entityExcelColor(
  id: string,
  kind: EntityColorKind,
  tint = false,
  preferredColor?: string
): string {
  const custom = normalizedHex(preferredColor);
  if (custom) {
    const channels = customRgb(custom).map(value =>
      Math.round(tint ? value * 0.2 + 255 * 0.8 : value)
        .toString(16)
        .padStart(2, "0")
    );
    return `FF${channels.join("")}`.toUpperCase();
  }
  if (kind === "teacher") {
    const hex = TEACHER_COLOR_PALETTE[entityHash(id, kind) % TEACHER_COLOR_PALETTE.length];
    const channels = customRgb(hex).map(value =>
      Math.round(tint ? value * 0.2 + 255 * 0.8 : value)
        .toString(16)
        .padStart(2, "0")
    );
    return `FF${channels.join("")}`.toUpperCase();
  }
  const tone = entityTone(id, kind);
  return hslToHex(tone.hue, tone.saturation, tint ? 87 : tone.lightness);
}

export function entityPickerColor(
  id: string,
  kind: EntityColorKind,
  preferredColor?: string
): string {
  const custom = normalizedHex(preferredColor);
  return custom ?? `#${entityExcelColor(id, kind).slice(2)}`;
}

/** CSS variables and an inline edge mark also survive standalone print windows. */
export function entityStyle(
  id: string,
  kind: EntityColorKind,
  rtl = false,
  preferredColor?: string
): EntityStyle {
  const color = entityColor(id, kind, preferredColor);
  const glass = entityGlass(id, kind, preferredColor);
  const edge = rtl ? -5 : 5;
  return {
    "--entity-color": color,
    "--entity-glass": glass,
    "--entity-stripe": `inset ${edge}px 0 0 0 ${color}`,
    backgroundColor: glass,
    boxShadow: `inset ${edge}px 0 0 0 ${color}`,
  };
}

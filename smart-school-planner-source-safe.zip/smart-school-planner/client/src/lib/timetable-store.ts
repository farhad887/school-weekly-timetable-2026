import { useCallback, useEffect, useRef, useState } from "react";
import {
  defaultState,
  normalizeGrid,
  type TimetableState,
} from "./timetable-types";

const KEY = "kurdish-school-timetable-v1";

function load(): TimetableState {
  if (typeof window === "undefined") return defaultState();
  try {
    const raw = window.localStorage.getItem(KEY);
    if (!raw) return defaultState();
    const parsed = { ...defaultState(), ...JSON.parse(raw) } as TimetableState;
    parsed.grid = normalizeGrid(parsed);
    parsed.lockedCells = Array.isArray(parsed.lockedCells)
      ? parsed.lockedCells.filter((key): key is string => typeof key === "string")
      : [];
    return parsed;
  } catch {
    return defaultState();
  }
}

export function useTimetable() {
  const [state, setStateRaw] = useState<TimetableState>(() => defaultState());
  const [hydrated, setHydrated] = useState(false);
  const past = useRef<TimetableState[]>([]);
  const future = useRef<TimetableState[]>([]);
  const [, force] = useState(0);
  const [savedAt, setSavedAt] = useState<string | null>(null);

  useEffect(() => {
    setStateRaw(load());
    setHydrated(true);
  }, []);

  const setState = useCallback(
    (updater: (s: TimetableState) => TimetableState) => {
      setStateRaw((prev) => {
        const next = updater(prev);
        past.current = [...past.current.slice(-49), prev];
        future.current = [];
        return next;
      });
      force((n) => n + 1);
    },
    [],
  );

  const undo = useCallback(() => {
    setStateRaw((prev) => {
      const p = past.current.pop();
      if (!p) return prev;
      future.current = [prev, ...future.current.slice(0, 49)];
      return p;
    });
    force((n) => n + 1);
  }, []);

  const redo = useCallback(() => {
    setStateRaw((prev) => {
      const [f, ...rest] = future.current;
      if (!f) return prev;
      future.current = rest;
      past.current = [...past.current, prev];
      return f;
    });
    force((n) => n + 1);
  }, []);

  const save = useCallback(() => {
    if (typeof window === "undefined") return;
    window.localStorage.setItem(KEY, JSON.stringify(state));
    setSavedAt(new Date().toLocaleString("en-GB"));
  }, [state]);

  const restore = useCallback((next: TimetableState) => {
    setStateRaw((prev) => {
      past.current = [...past.current.slice(-49), prev];
      future.current = [];
      return next;
    });
    if (typeof window !== "undefined") {
      try {
        window.localStorage.setItem(KEY, JSON.stringify(next));
        setSavedAt(new Date().toLocaleString("en-GB"));
      } catch {
        // The regular autosave effect will retry after the restored state renders.
      }
    }
    force((n) => n + 1);
  }, []);

  // autosave
  useEffect(() => {
    if (!hydrated) return;
    const t = setTimeout(() => {
      window.localStorage.setItem(KEY, JSON.stringify(state));
    }, 400);
    return () => clearTimeout(t);
  }, [state, hydrated]);

  const reset = useCallback(() => {
    setState(() => defaultState());
  }, [setState]);

  return {
    state,
    setState,
    hydrated,
    undo,
    redo,
    canUndo: past.current.length > 0,
    canRedo: future.current.length > 0,
    save,
    restore,
    savedAt,
    reset,
  };
}

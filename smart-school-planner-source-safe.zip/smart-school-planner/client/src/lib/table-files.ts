export type TableFileMeta = {
  id: string;
  name: string;
  mime: string;
  size: number;
  createdAt: string;
};

type StoredTableFile = TableFileMeta & { blob: Blob };

const FILE_MIME_BY_EXTENSION: Record<string, string> = {
  pdf: "application/pdf",
  xls: "application/vnd.ms-excel",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  doc: "application/msword",
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
};

function mimeForFile(name: string, fallback = "") {
  const extension = name.split(".").pop()?.toLowerCase() ?? "";
  return FILE_MIME_BY_EXTENSION[extension] ?? (fallback || "application/octet-stream");
}

const DB_NAME = "smart-school-planner-files-v1";
const STORE_NAME = "table-files";
const UPDATED_EVENT = "smart-school-planner-files-updated";

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: "id" });
        store.createIndex("createdAt", "createdAt");
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("indexeddb-open-failed"));
  });
}

function notifyUpdated() {
  if (typeof window !== "undefined") window.dispatchEvent(new Event(UPDATED_EVENT));
}

export function tableFilesUpdatedEvent() {
  return UPDATED_EVENT;
}

export async function saveTableFile(file: { name: string; mime: string; blob: Blob }) {
  if (typeof indexedDB === "undefined") return;
  try {
    const db = await openDb();
    const record: StoredTableFile = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2)}`,
      name: file.name,
      mime: file.mime,
      size: file.blob.size,
      createdAt: new Date().toISOString(),
      blob: file.blob,
    };
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).put(record);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error ?? new Error("indexeddb-save-failed"));
    });
    db.close();
    notifyUpdated();
  } catch {
    // The browser download still succeeds if local file storage is unavailable.
  }
}

export async function importTableFile(file: File) {
  const mime = mimeForFile(file.name, file.type);
  await saveTableFile({ name: file.name, mime, blob: file });
}

export async function listTableFiles(): Promise<TableFileMeta[]> {
  if (typeof indexedDB === "undefined") return [];
  try {
    const db = await openDb();
    const records = await new Promise<StoredTableFile[]>((resolve, reject) => {
      const request = db.transaction(STORE_NAME, "readonly").objectStore(STORE_NAME).getAll();
      request.onsuccess = () => resolve(request.result as StoredTableFile[]);
      request.onerror = () => reject(request.error ?? new Error("indexeddb-list-failed"));
    });
    db.close();
    return records
      .map(({ id, name, mime, size, createdAt }) => ({ id, name, mime, size, createdAt }))
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  } catch {
    return [];
  }
}

export async function downloadTableFile(id: string) {
  if (typeof indexedDB === "undefined") return false;
  try {
    const db = await openDb();
    const record = await new Promise<StoredTableFile | undefined>((resolve, reject) => {
      const request = db.transaction(STORE_NAME, "readonly").objectStore(STORE_NAME).get(id);
      request.onsuccess = () => resolve(request.result as StoredTableFile | undefined);
      request.onerror = () => reject(request.error ?? new Error("indexeddb-read-failed"));
    });
    db.close();
    if (!record) return false;
    const mime = mimeForFile(record.name, record.mime || record.blob.type);
    const blob = record.blob.type === mime ? record.blob : new Blob([record.blob], { type: mime });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = record.name;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60_000);
    return true;
  } catch {
    return false;
  }
}

export async function openTableFile(id: string) {
  if (typeof indexedDB === "undefined") return false;
  // Open synchronously during the user's click so mobile browsers do not block the tab.
  const openedWindow = window.open("about:blank", "_blank");
  if (!openedWindow) return downloadTableFile(id);
  try {
    const db = await openDb();
    const record = await new Promise<StoredTableFile | undefined>((resolve, reject) => {
      const request = db.transaction(STORE_NAME, "readonly").objectStore(STORE_NAME).get(id);
      request.onsuccess = () => resolve(request.result as StoredTableFile | undefined);
      request.onerror = () => reject(request.error ?? new Error("indexeddb-read-failed"));
    });
    db.close();
    if (!record) {
      openedWindow.close();
      return false;
    }
    const mime = mimeForFile(record.name, record.mime || record.blob.type);
    const blob = record.blob.type === mime ? record.blob : new Blob([record.blob], { type: mime });
    const url = URL.createObjectURL(blob);
    openedWindow.location.replace(url);
    setTimeout(() => URL.revokeObjectURL(url), 60_000);
    return true;
  } catch {
    openedWindow.close();
    return false;
  }
}

export async function deleteTableFile(id: string) {
  if (typeof indexedDB === "undefined") return false;
  try {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).delete(id);
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error ?? new Error("indexeddb-delete-failed"));
    });
    db.close();
    notifyUpdated();
    return true;
  } catch {
    return false;
  }
}

/** Delete every locally saved PDF, Excel, and Word table file. */
export async function deleteAllTableFiles() {
  if (typeof indexedDB === "undefined") return false;
  try {
    const db = await openDb();
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).clear();
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error ?? new Error("indexeddb-clear-failed"));
    });
    db.close();
    notifyUpdated();
    return true;
  } catch {
    return false;
  }
}

export async function downloadAllTableFiles(files: TableFileMeta[]) {
  for (const file of files) {
    await downloadTableFile(file.id);
    await new Promise(resolve => setTimeout(resolve, 150));
  }
}

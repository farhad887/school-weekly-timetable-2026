import type { Named, TimetableState } from "./timetable-types";
import { pageGroups } from "./timetable-types";
import { nameOf } from "./scheduler";
import { t, tName, isRtl, getLang, type Lang } from "./i18n";
import { entityExcelColor } from "./entity-colors";
import { sheetExcelFontName, type DistributionTypographySettings, type SheetFont } from "./typography";
import { saveTableFile } from "./table-files";

const EXPORT_START_EVENT = "smart-school-planner-export-start";
const EXPORT_END_EVENT = "smart-school-planner-export-end";
function notifyExport(eventName: string) {
  if (typeof window !== "undefined") window.dispatchEvent(new Event(eventName));
}
function waitForExportIndicator() {
  return new Promise<void>(resolve => {
    if (typeof window !== "undefined" && "requestAnimationFrame" in window) {
      window.requestAnimationFrame(() => resolve());
    } else {
      setTimeout(resolve, 0);
    }
  });
}

export type PaperSize = "A4" | "A3";
export type PageOrientation = "landscape" | "portrait";
type ExportTypography = { font?: SheetFont; titleSize: number; daySize: number; bodySize: number; metadataSize?: number; bold: boolean };

/** mm sizes in landscape */
const PAPER = {
  A4: { w: 297, h: 210 },
  A3: { w: 420, h: 297 },
} as const;

const PRINT_MARGIN_MM = 5;
const MARGIN_CM = PRINT_MARGIN_MM / 10;
const PRINT_MARGIN_IN = PRINT_MARGIN_MM / 25.4;

function excelArgb(color: string | undefined, fallback: string) {
  const value = (color || fallback).replace("#", "").trim();
  return `FF${/^[0-9a-f]{6}$/i.test(value) ? value.toUpperCase() : fallback}`;
}

function titleFill(state: TimetableState) {
  return excelArgb(state.sheetTitleColor, "263577");
}

function titleText(state: TimetableState) {
  return excelArgb(state.sheetTitleTextColor, "FFFFFF");
}

function applyWorksheetFont(ws: any, font?: SheetFont) {
  const name = sheetExcelFontName(font);
  ws.eachRow({ includeEmpty: true }, (row: any) => {
    row.eachCell({ includeEmpty: true }, (cell: any) => {
      cell.font = { ...cell.font, name };
    });
  });
}

function addWorksheetMetadata(
  ws: any,
  totalCols: number,
  state: TimetableState,
  lang: Lang,
  rtl: boolean,
  fontSize: number,
  font?: SheetFont,
  includeMetadata = true
) {
  if (!includeMetadata) return;
  const border = {
    top: { style: "thin" as const, color: { argb: "FF7A3B1D" } },
    right: { style: "thin" as const, color: { argb: "FF7A3B1D" } },
    bottom: { style: "thin" as const, color: { argb: "FF7A3B1D" } },
    left: { style: "thin" as const, color: { argb: "FF7A3B1D" } },
  };
  const size = Math.max(8, Math.min(40, fontSize));
  const values = [
    `${t("sheet.noteA", lang)} ${state.startDate} ${t("sheet.noteB", lang)}`,
    `${t("sheet.principal", lang)}: ${state.principal}`,
  ];
  for (const value of values) {
    const row = ws.addRow([value]);
    ws.mergeCells(row.number, 1, row.number, totalCols);
    const cell = row.getCell(1);
    cell.alignment = {
      horizontal: rtl ? "right" : "left",
      vertical: "middle",
      wrapText: true,
    };
    cell.font = { name: sheetExcelFontName(font), bold: true, size };
    cell.fill = {
      type: "pattern",
      pattern: "solid",
      fgColor: { argb: "FFF4EAD5" },
    };
    cell.border = border;
    row.height = Math.max(20, Math.ceil(size * 1.8));
  }
}

/** every rendered page element (1 or 2) */
function sheetElements(rootId = "timetable-pages"): HTMLElement[] {
  const root = document.getElementById(rootId);
  if (!root) {
    const single = document.getElementById("timetable-sheet");
    return single ? [single] : [];
  }
  return Array.from(root.querySelectorAll<HTMLElement>(".timetable-page"));
}

/** Print each page on its own sheet with 0.5cm margins, each filling the page. */
export function printSheet(
  size: PaperSize,
  lang: Lang = getLang(),
  rootId = "timetable-pages",
  orientation: PageOrientation = "landscape"
) {
  const els = sheetElements(rootId);
  if (els.length === 0) return;

  const w = window.open("", "_blank", "width=1200,height=800");
  if (!w) return;
  const rtl = isRtl(lang);
  const land = orientation === "landscape";
  const marginCm = MARGIN_CM;
  const availWmm = (land ? PAPER[size].w : PAPER[size].h) - marginCm * 20;
  const availHmm = (land ? PAPER[size].h : PAPER[size].w) - marginCm * 20;
  const pages = els
    .map((el, i) => {
      const targetWpx = availWmm * 3.779527559;
      const targetHpx = availHmm * 3.779527559;
      return `<div class="print-outer"${i < els.length - 1 ? ' style="page-break-after:always;break-after:page"' : ""}><div class="print-sheet" style="width:${targetWpx}px;height:${targetHpx}px">${el.outerHTML}</div></div>`;
    })
    .join("");
  w.document
    .write(`<!doctype html><html dir="${rtl ? "rtl" : "ltr"}" lang="${lang}"><head><meta charset="utf-8" />
<style>
  @font-face { font-family: "Unikurd Jino"; src: url("/fonts/kjino.ttf") format("truetype"); font-style: normal; font-weight: 400; }
  @font-face { font-family: "Unikurd Goran"; src: url("/fonts/kgoran.ttf") format("truetype"); font-style: normal; font-weight: 400; }
  @page { size: ${size} ${orientation}; margin: ${marginCm}cm; }
  * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; color-adjust: exact !important; box-sizing: border-box; }
  html, body { margin:0; padding:0; background:#fff; font-family: system-ui, "Segoe UI", Tahoma, sans-serif; }
  .print-outer { width: ${availWmm}mm; height: ${availHmm}mm; overflow: hidden; page-break-inside: avoid; break-inside: avoid; position: relative; }
  .print-sheet { transform-origin: top left; position: absolute; inset: 0; width: 100% !important; height: 100% !important; transform: none; }
  .print-sheet > .timetable-page {
    width: 100% !important;
    height: 100% !important;
    padding: 0 !important;
    margin: 0 !important;
    gap: 0 !important;
    min-height: 0 !important;
    max-height: none !important;
    aspect-ratio: auto !important;
    overflow: visible !important;
    position: static !important;
    box-sizing: border-box !important;
  }
  .print-sheet > .timetable-page:not(.class-sheets-page) {
    display: flex !important;
    flex-direction: column !important;
  }
  #timetable-pages .timetable-page,
  #teacher-sheets-pages .timetable-page,
  #distribution-sheets-pages .timetable-page {
    display: flex !important;
    flex-direction: column !important;
  }
  .sheet-footer {
    position: static !important;
    width: 100% !important;
    margin-top: auto !important;
    flex: 0 0 auto !important;
    z-index: 20 !important;
    display: flex !important;
    visibility: visible !important;
    opacity: 1 !important;
    background: rgba(255, 255, 255, 0.86) !important;
    backdrop-filter: blur(12px);
  }
  .timetable-page > div:last-child {
    display: flex !important;
    visibility: visible !important;
    opacity: 1 !important;
  }
  .timetable-page > div:last-child * {
    visibility: visible !important;
  }
  .print-sheet > .timetable-page > .sheet-glass-frame {
    flex: 1 1 0px !important;
    display: flex !important;
    flex-direction: column !important;
    height: 0 !important;
    min-height: 0 !important;
    overflow: visible !important;
  }
  .print-sheet > .timetable-page > .sheet-glass-frame > table {
    flex: 1 1 0px !important;
    height: 0 !important;
    min-height: 0 !important;
  }
  .print-sheet > .timetable-page[id^="timetable-sheet"] .sheet-glass-frame > table th {
    font-size: 12px !important;
    line-height: 1 !important;
    padding-top: 0 !important;
    padding-bottom: 0 !important;
  }
  .print-sheet > .timetable-page[id^="timetable-sheet"] .sheet-glass-frame > table td {
    font-size: 10px !important;
    line-height: 1 !important;
    padding-top: 0 !important;
    padding-bottom: 0 !important;
  }
  .print-sheet > .timetable-page[id^="timetable-sheet"] .sheet-glass-frame > table td.sheet-day-cell,
  .print-sheet > .timetable-page[id^="timetable-sheet"] .sheet-glass-frame > table td.sheet-period-cell {
    font-size: 11px !important;
  }
  .print-sheet > .timetable-page > div {
    min-height: 0 !important;
    display: flex !important;
  }
  .print-sheet > .timetable-page > div > .sheet-glass-frame {
    flex: 1 1 auto !important;
  }
  .print-sheet > .class-sheets-page {
    display: grid !important;
    height: 100% !important;
    aspect-ratio: auto !important;
    grid-auto-flow: row !important;
    align-items: stretch !important;
    align-content: stretch !important;
  }
  .print-sheet > .class-sheets-page > div {
    width: 100% !important;
    height: 100% !important;
    min-height: 0 !important;
    align-self: stretch !important;
  }
  .print-sheet > .class-sheets-page .sheet-glass-frame {
    width: 100% !important;
    height: 100% !important;
    display: flex !important;
    flex-direction: column !important;
  }
  .print-sheet > .class-sheets-page table { flex: 1 1 auto !important; height: 100% !important; }
  /* Keep all six periods of every day inside the A4 printable area. */
  .timetable-page:not(.distribution-page) > div:first-child { overflow: visible !important; }
  .timetable-page > div > .sheet-footer {
    position: static !important;
    margin-top: auto !important;
  }
  table { width: 100% !important; table-layout: fixed !important; }
  .print-sheet > .timetable-page.distribution-page > table {
    height: 0 !important;
    min-height: 0 !important;
    flex: 1 1 0px !important;
  }
  .print-sheet > .timetable-page.distribution-page > .sheet-title-band { flex: 0 0 auto !important; }
  .print-sheet > .timetable-page.distribution-page > .sheet-footer {
    margin-top: auto !important;
    margin-bottom: 18px !important;
    color: #263577 !important;
    background: #fff !important;
  }
  table, tr, td, th { page-break-inside: avoid; break-inside: avoid; }
  .timetable-page {
    background: rgba(255, 255, 255, 0.54) !important;
    border: 1px solid rgba(255, 255, 255, 0.78) !important;
    border-radius: 5mm;
    box-shadow: 0 3mm 8mm rgba(39, 48, 116, 0.15), inset 0 0.3mm 0 rgba(255, 255, 255, 0.8);
    backdrop-filter: blur(14px) saturate(150%);
  }
  .sheet-glass-frame {
    border-color: rgba(96, 105, 164, 0.25) !important;
    border-radius: 4mm;
    overflow: hidden;
    background: rgba(255, 255, 255, 0.32);
  }
  .sheet-title-band {
    border-color: rgba(255, 255, 255, 0.35) !important;
    backdrop-filter: blur(16px) saturate(150%);
  }
  .sheet-title-band.vip-title-band {
    border-bottom: 1px solid rgba(238, 203, 134, 0.88) !important;
  }
  .vip-title-band::after {
    position: absolute;
    right: 4%;
    bottom: 2px;
    left: 4%;
    height: 1px;
    content: "";
    background: linear-gradient(90deg, transparent, rgba(250, 226, 173, 0.92), transparent);
  }
  .timetable-page table thead th {
    background: linear-gradient(138deg, rgba(224, 230, 251, 0.96), rgba(248, 248, 255, 0.88)) !important;
    border-color: rgba(95, 105, 164, 0.24) !important;
  }
  .timetable-page table tbody td {
    background: linear-gradient(140deg, rgba(251, 252, 255, 0.88), rgba(238, 241, 252, 0.75)) !important;
    border-color: rgba(95, 105, 164, 0.24) !important;
  }
  .timetable-page .sheet-day-cell {
    background: linear-gradient(140deg, rgba(249, 239, 218, 0.90), rgba(255, 252, 243, 0.82)) !important;
  }
  .timetable-page .sheet-period-cell {
    background: linear-gradient(140deg, rgba(218, 233, 252, 0.90), rgba(245, 249, 255, 0.82)) !important;
  }
  .timetable-page td.entity-color-cell {
    background: var(--entity-glass) !important;
    box-shadow: var(--entity-stripe) !important;
  }
  .timetable-page td.sheet-conflict-cell.entity-color-cell {
    background: rgba(255, 100, 100, 0.82) !important;
    box-shadow: var(--entity-stripe) !important;
  }
  .sheet-note-cell { background: rgba(241, 235, 253, 0.78) !important; }
</style></head><body>${pages}
<script>
  window.addEventListener('load', function () {
    var fitSheets = function () {
      document.querySelectorAll('.print-sheet > .timetable-page').forEach(function (page) {
        var sheet = page.parentElement;
        if (!sheet) return;
        var naturalHeight = page.scrollHeight;
        var naturalWidth = page.scrollWidth;
        var scaleX = sheet.clientWidth / Math.max(naturalWidth, 1);
        var scaleY = sheet.clientHeight / Math.max(naturalHeight, 1);
        page.style.transformOrigin = 'top left';
        page.style.transform = 'scale(' + scaleX + ',' + scaleY + ')';
        page.style.width = (100 / scaleX) + '%';
        page.style.height = (100 / scaleY) + '%';
      });
    };
    var go = function(){ setTimeout(function(){ fitSheets(); window.print(); window.close(); }, 300); };
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(go); else go();
  });
<\/script></body></html>`);
  w.document.close();
}

function createPdfCaptureStage(source: HTMLElement, width: number, height: number) {
  const stage = document.createElement("div");
  Object.assign(stage.style, {
    position: "fixed",
    left: "-100000px",
    top: "0",
    width: `${width}px`,
    height: `${height}px`,
    overflow: "hidden",
    pointerEvents: "none",
    backgroundColor: "#fff",
    direction: getComputedStyle(source).direction,
  });

  const page = source.cloneNode(true) as HTMLElement;
  const force = (element: HTMLElement, property: string, value: string) =>
    element.style.setProperty(property, value, "important");
  for (const [property, value] of [
    ["width", `${width}px`],
    ["min-width", `${width}px`],
    ["max-width", `${width}px`],
    ["height", `${height}px`],
    ["min-height", `${height}px`],
    ["max-height", `${height}px`],
    ["aspect-ratio", "auto"],
    ["box-sizing", "border-box"],
    ["zoom", "1"],
    ["transform", "none"],
    ["margin", "0"],
    ["overflow", "hidden"],
    ["background-color", "#fff"],
  ]) force(page, property, value);

  const fitTableAndFooter =
    page.classList.contains("distribution-page") ||
    page.id === "timetable-sheet" ||
    /^timetable-sheet-\d+$/.test(page.id);

  page.querySelectorAll<HTMLElement>(".sheet-glass-frame").forEach(frame => {
    force(frame, "width", "100%");
    force(frame, "height", fitTableAndFooter ? "0px" : "100%");
    force(frame, "min-height", "0");
    force(frame, "flex", fitTableAndFooter ? "1 1 0px" : "1 1 auto");
    force(frame, "display", "flex");
    force(frame, "flex-direction", "column");
    force(frame, "box-sizing", "border-box");
  });
  page.querySelectorAll<HTMLTableElement>("table").forEach(table => {
    force(table, "width", "100%");
    force(table, "max-width", "100%");
    force(table, "height", fitTableAndFooter ? "0px" : "100%");
    force(table, "min-height", "0");
    force(table, "flex", fitTableAndFooter ? "1 1 0px" : "1 1 auto");
    force(table, "table-layout", "fixed");
  });
  page.querySelectorAll<HTMLElement>(".sheet-footer").forEach(footer => {
    force(footer, "position", "static");
    force(footer, "width", "100%");
    force(footer, "margin-top", "auto");
    force(footer, "flex", "0 0 auto");
    if (page.classList.contains("distribution-page")) {
      force(footer, "color", "#263577");
      force(footer, "margin-bottom", "18px");
      force(footer, "background-color", "#fff");
    }
  });
  if (page.classList.contains("class-sheets-page")) {
    force(page, "display", "grid");
    Array.from(page.children).forEach(child => {
      if (!(child instanceof HTMLElement)) return;
      force(child, "width", "100%");
      force(child, "height", "100%");
      force(child, "min-height", "0");
    });
  }

  stage.appendChild(page);
  document.body.appendChild(stage);

  if (fitTableAndFooter) {
    const table = page.querySelector<HTMLTableElement>("table");
    const title = page.querySelector<HTMLElement>(".sheet-title-band");
    const footer = page.querySelector<HTMLElement>(".sheet-footer");
    const frame = page.querySelector<HTMLElement>(".sheet-glass-frame");
    if (table && title) {
      const number = (value: string) => Number.parseFloat(value) || 0;
      const titleStyle = getComputedStyle(title);
      let availableHeight: number;
      if (page.classList.contains("distribution-page")) {
        const pageStyle = getComputedStyle(page);
        availableHeight =
          page.clientHeight -
          number(pageStyle.paddingTop) -
          number(pageStyle.paddingBottom) -
          title.getBoundingClientRect().height -
          number(titleStyle.marginBottom) -
          (footer?.getBoundingClientRect().height ?? 0);
      } else {
        availableHeight =
          (frame?.clientHeight ?? 0) - title.getBoundingClientRect().height;
      }

      const cells = Array.from(
        table.querySelectorAll<HTMLElement>("th, td")
      ).map(cell => {
        const style = getComputedStyle(cell);
        return {
          cell,
          fontSize: number(style.fontSize),
          paddingTop: number(style.paddingTop),
          paddingBottom: number(style.paddingBottom),
          minFontSize: cell.tagName === "TH"
            ? 9
            : cell.classList.contains("sheet-day-cell") ||
                cell.classList.contains("sheet-period-cell")
              ? 9
              : 8,
        };
      });

      let scale = 1;
      for (let attempt = 0; attempt < 3; attempt++) {
        const naturalHeight = table.scrollHeight;
        if (naturalHeight <= availableHeight - 2) break;
        const ratio = Math.max(
          0.1,
          Math.min(1, (availableHeight - 2) / Math.max(naturalHeight, 1))
        );
        if (ratio >= 0.999) break;
        scale *= ratio;
        cells.forEach(({ cell, fontSize, paddingTop, paddingBottom, minFontSize }) => {
          force(cell, "font-size", `${Math.max(minFontSize, fontSize * scale)}px`);
          force(cell, "padding-top", `${paddingTop * scale}px`);
          force(cell, "padding-bottom", `${paddingBottom * scale}px`);
          force(cell, "line-height", "1");
        });
        void table.offsetHeight;
      }
    }
  }

  return { stage, page };
}

export async function exportPdf(
  size: PaperSize,
  fileName = "خشتەی-هەفتانە",
  rootId = "timetable-pages",
  orientation: PageOrientation = "landscape"
) {
  notifyExport(EXPORT_START_EVENT);
  await waitForExportIndicator();
  const els = sheetElements(rootId);
  if (els.length === 0) throw new Error("no-sheet");
  const [{ toCanvas }, { jsPDF }] = await Promise.all([
    import("html-to-image"),
    import("jspdf"),
  ]);

  const pdf = new jsPDF({
    orientation,
    unit: "mm",
    format: size.toLowerCase(),
  });
  const m = PRINT_MARGIN_MM;
  const land = orientation === "landscape";
  const pageW = land ? PAPER[size].w : PAPER[size].h;
  const pageH = land ? PAPER[size].h : PAPER[size].w;
  const availW = pageW - m * 2;
  const availH = pageH - m * 2;
  const pxPerMm = 96 / 25.4;
  const renderW = Math.round(availW * pxPerMm);
  const renderH = Math.round(availH * pxPerMm);
  if (document.fonts?.ready) await document.fonts.ready;
  for (let i = 0; i < els.length; i++) {
    const { stage, page } = createPdfCaptureStage(els[i]!, renderW, renderH);
    try {
      const canvas = await toCanvas(page, {
        pixelRatio: 2,
        backgroundColor: "#ffffff",
        skipFonts: false,
        cacheBust: false,
        width: renderW,
        height: renderH,
        style: {
          width: `${renderW}px`,
          minWidth: `${renderW}px`,
          maxWidth: `${renderW}px`,
          height: `${renderH}px`,
          minHeight: `${renderH}px`,
          maxHeight: `${renderH}px`,
          aspectRatio: "auto",
          boxSizing: "border-box",
          zoom: "1",
          transform: "none",
          transformOrigin: "top left",
          overflow: "hidden",
          margin: "0",
        },
      });
      if (i > 0) pdf.addPage();
      pdf.addImage(canvas, "PNG", m, m, availW, availH, undefined, "FAST");
    } finally {
      stage.remove();
    }
  }
  const pdfName = `${fileName}.pdf`;
  const pdfBlob = pdf.output("blob");
  void saveTableFile({ name: pdfName, mime: "application/pdf", blob: pdfBlob });
  pdf.save(pdfName);
  notifyExport(EXPORT_END_EVENT);
}

export async function exportExcel(
  state: TimetableState,
  size: PaperSize = "A4",
  lang: Lang = getLang(),
  typography: ExportTypography = { titleSize: 23, daySize: 15, bodySize: 11, bold: true },
  orientation: PageOrientation = "landscape"
) {
  notifyExport(EXPORT_START_EVENT);
  await waitForExportIndicator();
  const rtl = isRtl(lang);
  const ExcelJS = (await import("exceljs")).default;
  const wb = new ExcelJS.Workbook();
  const groups = pageGroups(state);
  groups.forEach((classes, gi) => {
    const sheetName =
      groups.length > 1
        ? `${t("sheet.title", lang)} ${gi + 1}`
        : t("sheet.title", lang);
    const ws = wb.addWorksheet(sheetName, {
      views: [{ rightToLeft: rtl }],
      pageSetup: {
        orientation,
        paperSize: (size === "A3" ? 8 : 9) as never,
        fitToPage: true,
        fitToWidth: 1,
        fitToHeight: 1,
        horizontalCentered: true,
        verticalCentered: true,
        margins: {
          left: PRINT_MARGIN_IN,
          right: PRINT_MARGIN_IN,
          top: PRINT_MARGIN_IN,
          bottom: PRINT_MARGIN_IN,
          header: PRINT_MARGIN_IN,
          footer: PRINT_MARGIN_IN,
        },
      },
    });

    const totalCols = 2 + classes.length * 2;
    const thin = { style: "thin" as const, color: { argb: "FF7A3B1D" } };
    const medium = { style: "medium" as const, color: { argb: "FF7A3B1D" } };
    const border = { top: thin, left: thin, bottom: thin, right: thin };
    const fill = (argb: string) =>
      ({ type: "pattern", pattern: "solid", fgColor: { argb } }) as const;

    const headerLine = [state.directorate, state.schoolName]
      .filter(Boolean)
      .join(" — ");
    if (headerLine) {
      const hl = ws.addRow([headerLine]);
      ws.mergeCells(hl.number, 1, hl.number, totalCols);
      hl.getCell(1).alignment = { horizontal: "center", vertical: "middle" };
      hl.getCell(1).font = {
        bold: true,
        size: 12,
        color: { argb: titleText(state) },
      };
      hl.getCell(1).fill = fill(titleFill(state));
    }
    const title = ws.addRow([t("sheet.title", lang)]);
    ws.mergeCells(title.number, 1, title.number, totalCols);
    title.getCell(1).alignment = { horizontal: "center", vertical: "middle" };
    title.getCell(1).font = {
      bold: true,
      size: 15,
      color: { argb: titleText(state) },
    };
    title.getCell(1).fill = fill(titleFill(state));
    title.height = 22;

    const sub = ws.addRow([`${t("sheet.year", lang)} ${state.year}`]);
    ws.mergeCells(sub.number, 1, sub.number, totalCols);
    sub.getCell(1).alignment = { horizontal: "center", vertical: "middle" };
    sub.getCell(1).font = { bold: true, size: 12, color: { argb: titleText(state) } };
    sub.getCell(1).fill = fill(titleFill(state));

    const h1: string[] = [t("sheet.days", lang), t("sheet.period", lang)];
    const h2: string[] = ["", ""];
    for (const c of classes) {
      h1.push(tName(c.name, lang), "");
      h2.push(t("sheet.subject", lang), t("sheet.teacher", lang));
    }
    const r1 = ws.addRow(h1);
    const r2 = ws.addRow(h2);
    ws.mergeCells(r1.number, 1, r2.number, 1);
    ws.mergeCells(r1.number, 2, r2.number, 2);
    classes.forEach((_, i) => {
      ws.mergeCells(r1.number, 3 + i * 2, r1.number, 4 + i * 2);
    });
    for (const r of [r1, r2]) {
      r.eachCell({ includeEmpty: true }, (cellRef, col) => {
        cellRef.border = {
          ...border,
          left: col >= 2 && col % 2 === 0 ? medium : thin,
        };
        cellRef.font = { bold: true, size: 9 };
        cellRef.alignment = { horizontal: "center", vertical: "middle" };
        cellRef.fill = fill(r === r1 ? "FFDCECE7" : "FFE4EEF0");
      });
    }

    state.days.forEach((d, dIdx) => {
      const firstRow = ws.rowCount + 1;
      for (let p = 0; p < state.periodsPerDay; p++) {
        const values: string[] = [
          p === 0 ? tName(d.name, lang) : "",
          String(p + 1),
        ];
        for (const c of classes) {
          const item = state.grid[c.id]?.[d.id]?.[p] ?? null;
          values.push(
            item ? nameOf(state.subjects, item.subjectId) : "",
            item ? nameOf(state.teachers, item.teacherId) : ""
          );
        }
        const row = ws.addRow(values);
        const lastOfDay =
          p === state.periodsPerDay - 1 && dIdx < state.days.length - 1;
        row.eachCell({ includeEmpty: true }, (cellRef: any, col: number) => {
          cellRef.border = {
            top: thin,
            right: thin,
            left: col >= 2 && col % 2 === 0 ? medium : thin,
            bottom: lastOfDay ? medium : thin,
          };
          cellRef.alignment = {
            horizontal: "center",
            vertical: "middle",
            wrapText: true,
          };
          cellRef.font = { size: 11, bold: true };
          if (col > 2) {
            const classIndex = Math.floor((col - 3) / 2);
            const item =
              state.grid[classes[classIndex]?.id ?? ""]?.[d.id]?.[p] ?? null;
            cellRef.fill = item
              ? fill(
                  entityExcelColor(
                    item.teacherId,
                    "teacher",
                    true,
                    state.teachers.find(t => t.id === item.teacherId)?.color
                  )
                )
              : fill(col % 2 === 1 ? "FFDCEAFB" : "FFF9EFD9");
          }
          if (col === 1) {
            cellRef.fill = fill("FFF9EFD9");
            cellRef.font = { size: 13, bold: true };
          }
          if (col === 2) {
            cellRef.fill = fill("FFDCEAFB");
            cellRef.font = { size: 13, bold: true };
          }
        });
      }
      ws.mergeCells(firstRow, 1, firstRow + state.periodsPerDay - 1, 1);
    });

    addWorksheetMetadata(
      ws,
      totalCols,
      state,
      lang,
      rtl,
      typography.metadataSize ?? typography.bodySize,
      typography.font
    );

    // repeat title + header rows on every page
    ws.pageSetup.printTitlesRow = `1:${r2.number}`;

    ws.getColumn(1).width = 12;
    ws.getColumn(2).width = 5;
    for (let i = 3; i <= totalCols; i++) ws.getColumn(i).width = 11;
    applyWorksheetFont(ws, typography.font);
  });

  const buf = await wb.xlsx.writeBuffer();
  const blob = new Blob([buf], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  const fileName = `${t("sheet.title", lang)}-${size}.xlsx`;
  void saveTableFile({ name: fileName, mime: blob.type, blob });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1_000);
  notifyExport(EXPORT_END_EVENT);
}

/** Excel export of the per-class sheets (subjects only, with effective date and principal). */
export async function exportClassSheetsExcel(
  state: TimetableState,
  size: PaperSize = "A4",
  lang: Lang = getLang(),
  typography: ExportTypography = { titleSize: 23, daySize: 15, bodySize: 11, bold: true },
  orientation: PageOrientation = "landscape"
) {
  notifyExport(EXPORT_START_EVENT);
  await waitForExportIndicator();
  const rtl = isRtl(lang);
  const ExcelJS = (await import("exceljs")).default;
  const wb = new ExcelJS.Workbook();

  const thin = { style: "thin" as const, color: { argb: "FF7A3B1D" } };
  const border = { top: thin, left: thin, bottom: thin, right: thin };
  const fill = (argb: string) =>
    ({ type: "pattern", pattern: "solid", fgColor: { argb } }) as const;
  const big = size === "A3";
  const scale = 1;
  const titleScale = Math.max(8, Math.min(40, typography.titleSize)) / 23;
  const dayScale = Math.max(8, Math.min(40, typography.daySize)) / 15;
  const bodyScale = Math.max(8, Math.min(40, typography.bodySize)) / 11;
  const weight = typography.bold;

  state.classes.forEach((klass: Named, idx: number) => {
    const raw = tName(klass.name, lang) || `${idx + 1}`;
    const safe = raw.replace(/[\\/*?:[\]]/g, " ").slice(0, 28) || `${idx + 1}`;
    const ws = wb.addWorksheet(safe, {
      views: [{ rightToLeft: rtl }],
      pageSetup: {
        orientation,
        paperSize: (size === "A3" ? 8 : 9) as never,
        fitToPage: true,
        fitToWidth: 1,
        fitToHeight: 1,
        horizontalCentered: true,
        verticalCentered: true,
        margins: {
          left: PRINT_MARGIN_IN,
          right: PRINT_MARGIN_IN,
          top: PRINT_MARGIN_IN,
          bottom: PRINT_MARGIN_IN,
          header: PRINT_MARGIN_IN,
          footer: PRINT_MARGIN_IN,
        },
      },
    });

    const totalCols = 1 + state.periodsPerDay;

    const title = ws.addRow([tName(klass.name, lang)]);
    ws.mergeCells(title.number, 1, title.number, totalCols);
    title.getCell(1).alignment = { horizontal: "center", vertical: "middle" };
    title.getCell(1).font = {
      bold: true,
      size: big ? 30 : 24,
      color: { argb: titleText(state) },
    };
    title.getCell(1).fill = fill(titleFill(state));
    title.height = big ? 50 : 40;

    const head = ws.addRow([
      t("sheet.days", lang),
      ...Array.from(
        { length: state.periodsPerDay },
        (_, p) => `${t("sheet.period", lang)} ${p + 1}`
      ),
    ]);
    head.height = big ? 44 : 36;
    head.eachCell({ includeEmpty: true }, (cell: any) => {
      cell.border = border;
      cell.font = { bold: weight, size: Math.round((big ? 18 : 14) * titleScale) };
      cell.alignment = {
        horizontal: "center",
        vertical: "middle",
        wrapText: true,
      };
      cell.fill = fill("FFDCECE7");
    });

    state.days.forEach(d => {
      const values = [
        tName(d.name, lang),
        ...Array.from({ length: state.periodsPerDay }, (_, p) => {
          const item = state.grid[klass.id]?.[d.id]?.[p] ?? null;
          return item ? nameOf(state.subjects, item.subjectId) : "";
        }),
      ];
      const row = ws.addRow(values);
      row.height = big ? 58 : 46;
      row.eachCell({ includeEmpty: true }, (cell: any, col: number) => {
        cell.border = border;
        cell.alignment = {
          horizontal: "center",
          vertical: "middle",
          wrapText: true,
        };
        cell.font = { bold: weight, size: Math.round((big ? 18 : 14) * titleScale) };
        if (col === 1) {
          cell.fill = fill("FFF9EFD9");
        } else {
          const item = state.grid[klass.id]?.[d.id]?.[col - 2] ?? null;
          cell.fill = item
            ? fill(
                entityExcelColor(
                  item.teacherId,
                  "teacher",
                  true,
                  state.teachers.find(t => t.id === item.teacherId)?.color
                )
              )
            : fill("FFDCEAFB");
        }
      });
    });

    addWorksheetMetadata(
      ws,
      totalCols,
      state,
      lang,
      rtl,
      typography.metadataSize ?? typography.bodySize,
      typography.font,
      false
    );
    applyWorksheetFont(ws, typography.font);
    ws.getColumn(1).width = big ? 24 : 20;
    for (let i = 2; i <= totalCols; i++) ws.getColumn(i).width = big ? 22 : 18;
  });

  const buf = await wb.xlsx.writeBuffer();
  const blob = new Blob([buf], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  const fileName = `${t("cs.title", lang)}-${size}.xlsx`;
  void saveTableFile({ name: fileName, mime: blob.type, blob });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1_000);
  notifyExport(EXPORT_END_EVENT);
}

/** Export one polished worksheet per teacher, with class and subject in separate columns. */
export async function exportTeacherSheetsExcel(
  state: TimetableState,
  size: PaperSize = "A4",
  lang: Lang = getLang(),
  typography: ExportTypography = { titleSize: 23, daySize: 15, bodySize: 11, bold: true },
  orientation: PageOrientation = "landscape"
) {
  notifyExport(EXPORT_START_EVENT);
  await waitForExportIndicator();
  const rtl = isRtl(lang);
  const ExcelJS = (await import("exceljs")).default;
  const wb = new ExcelJS.Workbook();
  const thin = { style: "thin" as const, color: { argb: "FF7A3B1D" } };
  const border = { top: thin, left: thin, bottom: thin, right: thin };
  const fill = (argb: string) =>
    ({ type: "pattern", pattern: "solid", fgColor: { argb } }) as const;
  const big = size === "A3";
  const scale = 1;
  const titleScale = Math.max(8, Math.min(40, typography.titleSize)) / 23;
  const dayScale = Math.max(8, Math.min(40, typography.daySize)) / 15;
  const bodyScale = Math.max(8, Math.min(40, typography.bodySize)) / 11;
  const weight = typography.bold;
  state.teachers.forEach((teacher, idx) => {
    const raw = tName(teacher.name, lang) || `${idx + 1}`;
    const safe = raw.replace(/[\\/*?:[\]]/g, " ").slice(0, 28) || `${idx + 1}`;
    const totalCols = 1 + state.periodsPerDay * 2;
    const ws = wb.addWorksheet(safe, {
      views: [{ rightToLeft: rtl }],
      pageSetup: {
        orientation,
        paperSize: (big ? 8 : 9) as never,
        fitToPage: true,
        fitToWidth: 1,
        fitToHeight: 1,
        horizontalCentered: true,
        verticalCentered: true,
        margins: {
          left: PRINT_MARGIN_IN,
          right: PRINT_MARGIN_IN,
          top: PRINT_MARGIN_IN,
          bottom: PRINT_MARGIN_IN,
          header: PRINT_MARGIN_IN,
          footer: PRINT_MARGIN_IN,
        },
      },
    });

    const addMerged = (value: string, height: number, fontSize: number) => {
      const row = ws.addRow([value]);
      ws.mergeCells(row.number, 1, row.number, totalCols);
      const cell: any = row.getCell(1);
      cell.alignment = {
        horizontal: "center",
        vertical: "middle",
        wrapText: true,
      };
      cell.font = { bold: true, size: fontSize, color: { argb: titleText(state) } };
      cell.fill = fill(titleFill(state));
      row.height = height;
    };
    addMerged(
      tName(teacher.name, lang),
      big ? 48 : 38,
      Math.round((big ? 30 : 25) * scale)
    );

    const periods = ws.addRow([t("sheet.days", lang)]);
    for (let p = 0; p < state.periodsPerDay; p++) {
      const start = 2 + p * 2;
      ws.mergeCells(periods.number, start, periods.number, start + 1);
      periods.getCell(start).value = `${t("sheet.period", lang)} ${p + 1}`;
    }
    periods.height = big ? 34 : 28;
    periods.eachCell({ includeEmpty: true }, (cell: any) => {
      cell.border = border;
      cell.font = { bold: weight, size: Math.round((big ? 16 : 13) * titleScale) };
      cell.alignment = {
        horizontal: "center",
        vertical: "middle",
        wrapText: true,
      };
      cell.fill = fill("FFDCECE7");
    });

    const labels = ws.addRow([""]);
    for (let p = 0; p < state.periodsPerDay; p++) {
      labels.getCell(2 + p * 2).value = t("ts.class", lang);
      labels.getCell(3 + p * 2).value = t("sheet.subject", lang);
    }
    labels.height = big ? 30 : 24;
    labels.eachCell({ includeEmpty: true }, (cell: any) => {
      cell.border = border;
      cell.font = { bold: weight, size: Math.round((big ? 14 : 11) * bodyScale) };
      cell.alignment = {
        horizontal: "center",
        vertical: "middle",
        wrapText: true,
      };
      cell.fill = fill("FF EFB59B".replace(" ", ""));
    });

    state.days.forEach(day => {
      const values: string[] = [tName(day.name, lang)];
      for (let p = 0; p < state.periodsPerDay; p++) {
        let className = "";
        let subject = "";
        for (const klass of state.classes) {
          const item = state.grid[klass.id]?.[day.id]?.[p] ?? null;
          if (item?.teacherId === teacher.id) {
            className = tName(klass.name, lang);
            subject = nameOf(state.subjects, item.subjectId);
            break;
          }
        }
        values.push(className, subject);
      }
      const row = ws.addRow(values);
      row.height = big ? 48 : 38;
      row.eachCell({ includeEmpty: true }, (cell: any, col: number) => {
        cell.border = border;
        cell.alignment = {
          horizontal: "center",
          vertical: "middle",
          wrapText: true,
        };
        cell.font = { bold: weight, size: Math.round((big ? 16 : 12) * bodyScale) };
        if (col === 1) {
          cell.fill = fill("FFF9EFD9");
        } else {
          const period = Math.floor((col - 2) / 2);
          let item = null;
          for (const klass of state.classes) {
            const candidate = state.grid[klass.id]?.[day.id]?.[period] ?? null;
            if (candidate?.teacherId === teacher.id) {
              item = candidate;
              break;
            }
          }
          cell.fill = item
            ? fill(entityExcelColor(teacher.id, "teacher", true, teacher.color))
            : fill(col % 2 === 0 ? "FFDCEAFB" : "FFEEF1FC");
        }
      });
    });
    addWorksheetMetadata(
      ws,
      totalCols,
      state,
      lang,
      rtl,
      typography.metadataSize ?? typography.bodySize,
      typography.font,
      false
    );
    applyWorksheetFont(ws, typography.font);
    ws.getColumn(1).width = big ? 22 : 18;
    for (let i = 2; i <= totalCols; i++) ws.getColumn(i).width = big ? 19 : 15;
  });

  const buf = await wb.xlsx.writeBuffer();
  const blob = new Blob([buf], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  const fileName = `${t("ts.title", lang)}-${size}.xlsx`;
  void saveTableFile({ name: fileName, mime: blob.type, blob });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1_000);
  notifyExport(EXPORT_END_EVENT);
}

export async function exportDistributionExcel(
  state: TimetableState,
  size: PaperSize = "A4",
  lang: Lang = getLang(),
  teachersPerPage = 6,
  classesPerPage = 6,
  typography: DistributionTypographySettings = {
    font: "jino",
    titleSize: 25,
    contentSize: 12,
    headerSize: 12,
    teacherSize: 12,
    classSize: 12,
    metadataSize: 12,
    bold: true,
  },
  orientation: PageOrientation = "landscape"
) {
  notifyExport(EXPORT_START_EVENT);
  await waitForExportIndicator();
  const rtl = isRtl(lang);
  const ExcelJS = (await import("exceljs")).default;
  const wb = new ExcelJS.Workbook();
  const thin = { style: "medium" as const, color: { argb: "FF111111" } };
  const groupEdge = { style: "medium" as const, color: { argb: "FF111111" } };
  const border = { top: thin, left: thin, bottom: thin, right: thin };
  const fill = (argb: string) =>
    ({ type: "pattern", pattern: "solid", fgColor: { argb } }) as const;
  const teacherGroups: Named[][] = [];
  const classGroups: Named[][] = [];
  for (let i = 0; i < state.teachers.length; i += Math.max(1, teachersPerPage))
    teacherGroups.push(
      state.teachers.slice(i, i + Math.max(1, teachersPerPage))
    );
  for (let i = 0; i < state.classes.length; i += Math.max(1, classesPerPage))
    classGroups.push(state.classes.slice(i, i + Math.max(1, classesPerPage)));
  if (!teacherGroups.length) teacherGroups.push([]);
  if (!classGroups.length) classGroups.push([]);
  const big = size === "A3";
  const fontName = sheetExcelFontName(typography.font);
  const titleSize = Math.max(8, Math.min(40, typography.titleSize));
  const titleScale = titleSize / 25;
  const contentSize = Math.max(8, Math.min(40, typography.contentSize));
  const headerSize = Math.max(8, Math.min(40, typography.headerSize));
  const teacherSize = Math.max(8, Math.min(40, typography.teacherSize));
  const classSize = Math.max(8, Math.min(40, typography.classSize));
  const headerLine = [state.directorate, state.schoolName]
    .filter(Boolean)
    .join(" — ");
  let pageNo = 0;
  for (const teachers of teacherGroups)
    for (const classes of classGroups) {
      pageNo++;
      const totalCols = 6 + classes.length;
      const name = `${t("ds.title", lang)} ${pageNo}`
        .replace(/[\\/*?:[\]]/g, " ")
        .slice(0, 31);
      const ws = wb.addWorksheet(name || `${pageNo}`, {
        views: [{ rightToLeft: rtl }],
        pageSetup: {
          orientation,
          paperSize: (big ? 8 : 9) as never,
          fitToPage: true,
          fitToWidth: 1,
          fitToHeight: 1,
          horizontalCentered: true,
          verticalCentered: true,
          margins: {
            left: PRINT_MARGIN_IN,
            right: PRINT_MARGIN_IN,
            top: PRINT_MARGIN_IN,
            bottom: PRINT_MARGIN_IN,
            header: PRINT_MARGIN_IN,
            footer: PRINT_MARGIN_IN,
          },
        },
      });
      const mergedTitle = (value: string, fontSize: number, height: number) => {
        const row = ws.addRow([value]);
        ws.mergeCells(row.number, 1, row.number, totalCols);
        const c: any = row.getCell(1);
        c.value = value;
        c.fill = fill(titleFill(state));
        c.font = { name: fontName, bold: typography.bold, size: fontSize, color: { argb: titleText(state) } };
        c.alignment = {
          horizontal: "center",
          vertical: "middle",
          wrapText: true,
        };
        row.height = height;
      };
      if (headerLine) mergedTitle(headerLine, Math.round((big ? 15 : 12) * titleScale), big ? 28 : 22);
      mergedTitle(t("ds.title", lang), Math.round((big ? 19 : 15) * titleScale), big ? 34 : 28);
      mergedTitle(
        `${t("sheet.year", lang)} ${state.year}${pageNo > 1 ? ` — ${t("sheet.page", lang)} ${pageNo}` : ""}`,
        Math.round((big ? 14 : 11) * titleScale),
        big ? 26 : 22
      );
      const head = ws.addRow([
        "#",
        t("ds.teacher", lang),
        t("ds.specialty", lang),
        t("ds.subject", lang),
        ...classes.map(c => tName(c.name, lang)),
        t("ds.quota", lang),
        t("ds.notes", lang),
      ]);
      head.height = big ? 42 : 34;
      head.eachCell({ includeEmpty: true }, (c: any, col: number) => {
        c.border = border;
        c.fill = fill("FFF9EFD9");
        const isClassHeader = col >= 5 && col <= 4 + classes.length;
        c.font = { name: fontName, bold: typography.bold, size: isClassHeader ? classSize : headerSize };
        c.alignment = {
          horizontal: "center",
          vertical: "middle",
          wrapText: true,
        };
      });
      let rowNo = 0;
      let grand = 0;
      const classIds = new Set(classes.map(c => c.id));
      for (const teacher of teachers) {
        const assignments = state.assignments.filter(
          a => a.teacherId === teacher.id && classIds.has(a.classId)
        );
        const subjectRows = Array.from(
          assignments
            .reduce((map, assignment) => {
              const current = map.get(assignment.subjectId) ?? {
                subjectId: assignment.subjectId,
                counts: new Map<string, number>(),
                total: 0,
              };
              current.counts.set(
                assignment.classId,
                (current.counts.get(assignment.classId) ?? 0) + assignment.count
              );
              current.total += assignment.count;
              map.set(assignment.subjectId, current);
              return map;
            }, new Map<string, { subjectId: string; counts: Map<string, number>; total: number }>())
            .values()
        );
        const teacherRows = subjectRows.length
          ? subjectRows
          : [{ subjectId: "", counts: new Map<string, number>(), total: 0 }];
        const startRow = ws.rowCount + 1;
        const teacherTotal = subjectRows.reduce(
          (sum, row) => sum + row.total,
          0
        );
        teacherRows.forEach((rowData, rowIndex) => {
          if (rowIndex === 0) rowNo++;
          grand += rowData.total;
          const values = [
            rowIndex === 0 ? rowNo : "",
            rowIndex === 0 ? tName(teacher.name, lang) : "",
            rowIndex === 0 ? (teacher.specialty ?? "") : "",
            rowData.subjectId ? nameOf(state.subjects, rowData.subjectId) : "",
            ...classes.map(c => rowData.counts.get(c.id) || ""),
            rowIndex === 0 ? teacherTotal || "" : "",
            "",
          ];
          const row = ws.addRow(values);
          row.height = big ? 34 : 27;
          row.eachCell({ includeEmpty: true }, (c: any, col: number) => {
            c.border = border;
            if (col === 2 && rowIndex === 0) {
              c.fill = fill(
                entityExcelColor(teacher.id, "teacher", true, teacher.color)
              );
            } else if (
              rowData.subjectId &&
              (col === 4 || (col >= 5 && col <= 4 + classes.length))
            ) {
              c.fill = fill(
                entityExcelColor(teacher.id, "teacher", true, teacher.color)
              );
            } else {
              c.fill = fill(
                col <= 3 || col === totalCols ? "FFF9EFD9" : "FFEEF1FC"
              );
            }
            c.font = {
              name: fontName,
              bold: typography.bold,
              size: col === 2 && rowIndex === 0 ? teacherSize : contentSize,
            };
            c.alignment = {
              horizontal: "center",
              vertical: "middle",
              wrapText: true,
            };
          });
        });
        if (teacherRows.length > 1) {
          ws.mergeCells(startRow, 1, startRow + teacherRows.length - 1, 1);
          ws.mergeCells(startRow, 2, startRow + teacherRows.length - 1, 2);
          ws.mergeCells(startRow, 3, startRow + teacherRows.length - 1, 3);
          ws.mergeCells(
            startRow,
            5 + classes.length,
            startRow + teacherRows.length - 1,
            5 + classes.length
          );
        }
        for (let r = startRow; r < startRow + teacherRows.length; r++) {
          for (let c = 1; c <= totalCols; c++) {
            const current = ws.getCell(r, c);
            current.border = {
              ...border,
              top: r === startRow ? groupEdge : thin,
              bottom:
                r === startRow + teacherRows.length - 1 ? groupEdge : thin,
            };
          }
        }
      }
      const totalRow = ws.addRow([
        "",
        "",
        "",
        t("ds.lessonsTotal", lang),
        ...classes.map(c =>
          state.assignments
            .filter(
              a =>
                a.classId === c.id &&
                teachers.some(teacher => teacher.id === a.teacherId)
            )
            .reduce((s, a) => s + a.count, 0)
        ),
        grand,
        "",
      ]);
      totalRow.eachCell({ includeEmpty: true }, (c: any) => {
        c.border = border;
        c.fill = fill("FFF9EFD9");
        c.font = { name: fontName, bold: typography.bold, size: contentSize };
        c.alignment = {
          horizontal: "center",
          vertical: "middle",
          wrapText: true,
        };
      });
      addWorksheetMetadata(
        ws,
        totalCols,
        state,
        lang,
        rtl,
        typography.metadataSize,
        typography.font
      );
      ws.getColumn(1).width = 5;
      ws.getColumn(2).width = big ? 25 : 21;
      ws.getColumn(3).width = big ? 18 : 14;
      ws.getColumn(4).width = big ? 20 : 16;
      for (let i = 5; i <= 4 + classes.length; i++)
        ws.getColumn(i).width = big ? 15 : 12;
      ws.getColumn(5 + classes.length).width = 10;
      ws.getColumn(6 + classes.length).width = big ? 18 : 12;
      ws.pageSetup.printTitlesRow = "1:4";
    }
  const buf = await wb.xlsx.writeBuffer();
  const blob = new Blob([buf], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
  const fileName = `${t("ds.title", lang)}-${size}.xlsx`;
  void saveTableFile({ name: fileName, mime: blob.type, blob });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1_000);
  notifyExport(EXPORT_END_EVENT);
}

/** Export all four reports into one workbook with A4/A3 print settings. */
export async function exportAllSheetsExcel(
  state: TimetableState,
  size: PaperSize = "A4",
  lang: Lang = getLang(),
  orientation: PageOrientation = "landscape"
) {
  notifyExport(EXPORT_START_EVENT);
  await waitForExportIndicator();
  const rtl = isRtl(lang);
  const ExcelJS = (await import("exceljs")).default;
  const wb = new ExcelJS.Workbook();
  const big = size === "A3";
  const thin = { style: "thin" as const, color: { argb: "FF7A3B1D" } };
  const border = { top: thin, left: thin, bottom: thin, right: thin };
  const fill = (argb: string) => ({ type: "pattern", pattern: "solid", fgColor: { argb } }) as const;
  const usedNames = new Set<string>();
  const uniqueName = (raw: string) => {
    const base = (raw.replace(/[\\/*?:\[\]]/g, " ").trim() || "Sheet").slice(0, 28);
    let value = base;
    let n = 2;
    while (usedNames.has(value)) value = `${base.slice(0, 28 - String(n).length - 1)}-${n++}`;
    usedNames.add(value);
    return value;
  };
  const makeSheet = (name: string, columns: number) => {
    const ws = wb.addWorksheet(uniqueName(name), {
      views: [{ rightToLeft: rtl }],
      pageSetup: {
        orientation,
        paperSize: (big ? 8 : 9) as never,
        fitToPage: true,
        fitToWidth: 1,
        fitToHeight: 1,
        horizontalCentered: true,
        margins: { left: PRINT_MARGIN_IN, right: PRINT_MARGIN_IN, top: PRINT_MARGIN_IN, bottom: PRINT_MARGIN_IN, header: PRINT_MARGIN_IN, footer: PRINT_MARGIN_IN },
      },
    });
    ws.columns = Array.from({ length: columns }, () => ({ width: big ? 22 : 16 }));
    return ws;
  };
  const addTitle = (ws: any, value: string, columns: number) => {
    const row = ws.addRow([value]);
    ws.mergeCells(row.number, 1, row.number, columns);
    const cell = row.getCell(1);
    cell.font = { bold: true, size: big ? 18 : 14, color: { argb: titleText(state) } };
    cell.fill = fill(titleFill(state));
    cell.alignment = { horizontal: "center", vertical: "middle" };
    row.height = big ? 30 : 24;
  };
  const addHeader = (ws: any, values: string[]) => {
    const row = ws.addRow(values);
    row.eachCell({ includeEmpty: true }, (cell: any) => {
      cell.font = { bold: true, size: big ? 13 : 11 };
      cell.fill = fill("FFDCECE7");
      cell.border = border;
      cell.alignment = { horizontal: "center", vertical: "middle", wrapText: true };
    });
    row.height = big ? 28 : 22;
  };
  const addData = (ws: any, values: string[]) => {
    const row = ws.addRow(values);
    row.eachCell({ includeEmpty: true }, (cell: any) => {
      cell.border = border;
      cell.alignment = { horizontal: "center", vertical: "middle", wrapText: true };
      cell.font = { size: big ? 12 : 10 };
    });
  };
  const schoolLine = [state.directorate, state.schoolName].filter(Boolean).join(" — ");

  const weekly = makeSheet("خشتەی هەفتانە", 5);
  addTitle(weekly, schoolLine ? `${schoolLine} — ${t("sheet.title", lang)}` : t("sheet.title", lang), 5);
  addHeader(weekly, [t("sheet.days", lang), t("sheet.period", lang), t("label.classes", lang), t("sheet.subject", lang), t("sheet.teacher", lang)]);
  state.days.forEach(day => {
    for (let p = 0; p < state.periodsPerDay; p++) state.classes.forEach(klass => {
      const item = state.grid[klass.id]?.[day.id]?.[p] ?? null;
      addData(weekly, [tName(day.name, lang), String(p + 1), tName(klass.name, lang), item ? nameOf(state.subjects, item.subjectId) : "", item ? nameOf(state.teachers, item.teacherId) : ""]);
    });
  });
  addWorksheetMetadata(weekly, 5, state, lang, rtl, 10);
  weekly.pageSetup.printTitlesRow = "1:2";

  const distribution = makeSheet("دابەشکردنی وانە", 6);
  addTitle(distribution, t("ds.title", lang), 6);
  addHeader(distribution, [t("ts.title", lang), t("label.classes", lang), t("sheet.subject", lang), t("label.count", lang), t("label.specialty", lang), t("sheet.year", lang)]);
  state.assignments.forEach(assignment => {
    const teacher = state.teachers.find(x => x.id === assignment.teacherId);
    addData(distribution, [nameOf(state.teachers, assignment.teacherId), nameOf(state.classes, assignment.classId), nameOf(state.subjects, assignment.subjectId), String(assignment.count), teacher?.specialty ?? "", state.year]);
  });
  addWorksheetMetadata(distribution, 6, state, lang, rtl, 10);
  distribution.pageSetup.printTitlesRow = "1:2";

  for (const klass of state.classes) {
    const columns = 1 + state.periodsPerDay;
    const ws = makeSheet(`پۆل - ${tName(klass.name, lang)}`, columns);
    addTitle(ws, tName(klass.name, lang), columns);
    addHeader(ws, [t("sheet.days", lang), ...Array.from({ length: state.periodsPerDay }, (_, i) => `${t("sheet.period", lang)} ${i + 1}`)]);
    state.days.forEach(day => addData(ws, [tName(day.name, lang), ...Array.from({ length: state.periodsPerDay }, (_, p) => {
      const item = state.grid[klass.id]?.[day.id]?.[p] ?? null;
      return item ? nameOf(state.subjects, item.subjectId) : "";
    })]));
    addWorksheetMetadata(ws, columns, state, lang, rtl, 10);
    ws.pageSetup.printTitlesRow = "1:2";
  }

  for (const teacher of state.teachers) {
    const columns = 1 + state.periodsPerDay;
    const ws = makeSheet(`مامۆستا - ${tName(teacher.name, lang)}`, columns);
    addTitle(ws, `${t("ts.title", lang)} — ${tName(teacher.name, lang)}`, columns);
    addHeader(ws, [t("sheet.days", lang), ...Array.from({ length: state.periodsPerDay }, (_, i) => `${t("sheet.period", lang)} ${i + 1}`)]);
    state.days.forEach(day => addData(ws, [tName(day.name, lang), ...Array.from({ length: state.periodsPerDay }, (_, p) => {
      for (const klass of state.classes) {
        const item = state.grid[klass.id]?.[day.id]?.[p] ?? null;
        if (item?.teacherId === teacher.id) return `${tName(klass.name, lang)} — ${nameOf(state.subjects, item.subjectId)}`;
      }
      return "";
    })]));
    addWorksheetMetadata(ws, columns, state, lang, rtl, 10);
    ws.pageSetup.printTitlesRow = "1:2";
  }

  for (const ws of wb.worksheets) applyWorksheetFont(ws, "jino");
  const buf = await wb.xlsx.writeBuffer();
  const blob = new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
  const fileName = `هەموو-خشتەکان-${size}.xlsx`;
  void saveTableFile({ name: fileName, mime: blob.type, blob });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1_000);
  notifyExport(EXPORT_END_EVENT);
}

/** Export all four reports as a Word-compatible document with A4/A3 page styling. */
export function exportAllSheetsWord(state: TimetableState, size: PaperSize = "A4", lang: Lang = getLang(), orientation: PageOrientation = "landscape") {
  const esc = (value: string) => value.replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "\"": "&quot;", "'": "&#39;" }[char] ?? char));
  const table = (headers: string[], rows: string[][]) => `<table><thead><tr>${headers.map(h => `<th>${esc(h)}</th>`).join("")}</tr></thead><tbody>${rows.map(row => `<tr>${row.map(cell => `<td>${esc(cell)}</td>`).join("")}</tr>`).join("")}</tbody></table>`;
  const sections: string[] = [];
  const weeklyRows: string[][] = [];
  state.days.forEach(day => {
    for (let p = 0; p < state.periodsPerDay; p++) state.classes.forEach(klass => {
      const item = state.grid[klass.id]?.[day.id]?.[p] ?? null;
      weeklyRows.push([tName(day.name, lang), String(p + 1), tName(klass.name, lang), item ? nameOf(state.subjects, item.subjectId) : "", item ? nameOf(state.teachers, item.teacherId) : ""]);
    });
  });
  sections.push(`<h2>${esc(t("sheet.title", lang))}</h2>${table([t("sheet.days", lang), t("sheet.period", lang), t("label.classes", lang), t("sheet.subject", lang), t("sheet.teacher", lang)], weeklyRows)}`);
  sections.push(`<h2>${esc(t("ds.title", lang))}</h2>${table([t("ts.title", lang), t("label.classes", lang), t("sheet.subject", lang), t("label.count", lang), t("label.specialty", lang)], state.assignments.map(a => { const teacher = state.teachers.find(x => x.id === a.teacherId); return [nameOf(state.teachers, a.teacherId), nameOf(state.classes, a.classId), nameOf(state.subjects, a.subjectId), String(a.count), teacher?.specialty ?? ""]; }))}`);
  for (const klass of state.classes) sections.push(`<h2>${esc(tName(klass.name, lang))}</h2>${table([t("sheet.days", lang), ...Array.from({ length: state.periodsPerDay }, (_, i) => `${t("sheet.period", lang)} ${i + 1}`)], state.days.map(day => [tName(day.name, lang), ...Array.from({ length: state.periodsPerDay }, (_, p) => { const item = state.grid[klass.id]?.[day.id]?.[p] ?? null; return item ? nameOf(state.subjects, item.subjectId) : ""; })]))}`);
  for (const teacher of state.teachers) sections.push(`<h2>${esc(`${t("ts.title", lang)} — ${tName(teacher.name, lang)}`)}</h2>${table([t("sheet.days", lang), ...Array.from({ length: state.periodsPerDay }, (_, i) => `${t("sheet.period", lang)} ${i + 1}`)], state.days.map(day => [tName(day.name, lang), ...Array.from({ length: state.periodsPerDay }, (_, p) => { for (const klass of state.classes) { const item = state.grid[klass.id]?.[day.id]?.[p] ?? null; if (item?.teacherId === teacher.id) return `${tName(klass.name, lang)} — ${nameOf(state.subjects, item.subjectId)}`; } return ""; })]))}`);
  const html = `<!doctype html><html dir="${isRtl(lang) ? "rtl" : "ltr"}"><head><meta charset="utf-8"><style>@page{size:${size} ${orientation};margin:5mm}body{font-family:Arial,"Segoe UI",sans-serif;color:#111}h1{text-align:center;color:#263577}h2{color:#263577;border-bottom:2px solid #263577;padding-bottom:4px;page-break-before:always}h2:first-of-type{page-break-before:auto}table{border-collapse:collapse;width:100%;margin-bottom:18px}th,td{border:1px solid #777;padding:6px;text-align:center;vertical-align:middle}th{background:#dcece7;font-weight:bold}td{page-break-inside:avoid}.meta{font-weight:bold}</style></head><body><h1>${esc(state.schoolName || t("app.title", lang))}</h1><p class="meta">${esc(`${t("sheet.year", lang)} ${state.year}`)}</p>${sections.join("")}</body></html>`;
  const blob = new Blob(["\ufeff", html], { type: "application/msword" });
  const fileName = `هەموو-خشتەکان-${size}.doc`;
  void saveTableFile({ name: fileName, mime: blob.type, blob });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1_000);
}


/** Export the currently previewed timetable sheet(s) as a Word-compatible document. */
export function exportWord(
  size: PaperSize,
  fileName: string,
  rootId: string,
  lang: Lang = getLang(),
  orientation: PageOrientation = "landscape"
) {
  const els = sheetElements(rootId);
  if (els.length === 0) return;
  const rtl = isRtl(lang);
  const landscape = orientation === "landscape";
  const pageW = landscape ? PAPER[size].w : PAPER[size].h;
  const pageH = landscape ? PAPER[size].h : PAPER[size].w;
  const contentW = pageW - PRINT_MARGIN_MM * 2;
  const contentH = pageH - PRINT_MARGIN_MM * 2;
  const html = `<!doctype html><html dir="${rtl ? "rtl" : "ltr"}" lang="${lang}"><head><meta charset="utf-8"><style>
    @page { size: ${size} ${orientation}; margin: 5mm; }
    * { box-sizing: border-box; }
    html, body { width: 100%; margin: 0; padding: 0; }
    body { font-family: Arial, "Segoe UI", sans-serif; color: #111; }
    .timetable-page {
      width: ${contentW}mm !important; height: ${contentH}mm !important;
      min-height: 0 !important; max-height: none !important; aspect-ratio: auto !important;
      margin: 0 !important; padding: 2mm !important; overflow: hidden !important;
      box-sizing: border-box !important; page-break-after: always; break-after: page;
    }
    .timetable-page:not(.class-sheets-page) { display: flex !important; flex-direction: column !important; }
    .timetable-page:last-child { page-break-after: auto; break-after: auto; }
    .sheet-glass-frame { flex: 1 1 auto !important; min-height: 0 !important; display: flex !important; flex-direction: column !important; overflow: visible !important; }
    .sheet-glass-frame > table { flex: 1 1 auto !important; width: 100% !important; height: 100% !important; table-layout: fixed; }
    .class-sheets-page { display: grid !important; grid-auto-flow: row !important; align-items: stretch !important; align-content: stretch !important; }
    .class-sheets-page > div { width: 100% !important; height: 100% !important; min-height: 0 !important; }
    .class-sheets-page .sheet-glass-frame { width: 100% !important; height: 100% !important; }
    .class-sheets-page table { flex: 1 1 auto !important; width: 100% !important; height: 100% !important; }
    .distribution-page > table { flex: 1 1 auto !important; width: 100% !important; height: 100% !important; min-height: 0 !important; }
    .sheet-footer { position: static !important; margin-top: auto !important; }
    table { border-collapse: collapse; width: 100%; table-layout: fixed; }
    th, td { border: 1px solid #888; padding: 5px; text-align: center; vertical-align: middle; word-wrap: break-word; }
    th { background: #dcece7; font-weight: bold; }
    h1, h2, h3 { color: #263577; text-align: center; }
  </style></head><body>${els.map(el => el.outerHTML).join("")}</body></html>`;
  const blob = new Blob(["\ufeff", html], { type: "application/msword" });
  const downloadName = `${fileName}-${size}.doc`;
  void saveTableFile({ name: downloadName, mime: blob.type, blob });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = downloadName;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1_000);
}

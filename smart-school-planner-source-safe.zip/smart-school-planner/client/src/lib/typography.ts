export type DistributionFont = "system" | "goran" | "jino";

export type SheetFont = DistributionFont;

export const SHEET_FONT_FAMILIES: Record<SheetFont, string> = {
  system: '"Noto Sans Arabic", "Noto Kufi Arabic", "Segoe UI", Tahoma, Arial, sans-serif',
  goran: '"Unikurd Goran", "Noto Sans Arabic", "Segoe UI", Tahoma, Arial, sans-serif',
  jino: '"Unikurd Jino", "Noto Sans Arabic", "Segoe UI", Tahoma, Arial, sans-serif',
};

export function sheetFontFamily(font: SheetFont = "jino"): string {
  return SHEET_FONT_FAMILIES[font];
}

export function sheetExcelFontName(font: SheetFont = "jino"): string {
  if (font === "goran") return "Unikurd Goran";
  if (font === "jino") return "Unikurd Jino";
  return "Arial";
}

export type DistributionTypographySettings = {
  font: DistributionFont;
  titleSize: number;
  contentSize: number;
  headerSize: number;
  teacherSize: number;
  classSize: number;
  metadataSize: number;
  bold: boolean;
};

export const DEFAULT_DISTRIBUTION_TYPOGRAPHY: DistributionTypographySettings = {
  font: "jino",
  titleSize: 25,
  contentSize: 12,
  headerSize: 12,
  teacherSize: 12,
  classSize: 12,
  metadataSize: 12,
  bold: true,
};

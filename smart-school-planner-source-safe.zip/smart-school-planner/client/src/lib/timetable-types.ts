export type Id = string;

export interface Named {
  id: Id;
  name: string;
  /** Optional user-selected teacher/subject color, persisted with the timetable. */
  color?: string;
  /** Optional teacher specialization shown in distribution reports. */
  specialty?: string;
}

export interface Assignment {
  id: Id;
  classId: Id;
  subjectId: Id;
  teacherId: Id;
  count: number;
}

/** period = 0 means the whole day */
export interface TeacherOff {
  id: Id;
  dayId: Id;
  teacherId: Id;
  period: number;
}

export interface Ban {
  id: Id;
  classId: Id;
  dayId: Id;
  subjectId: Id;
  period: number;
}

/** two lessons of this subject must sit side by side on this day */
export interface PairRule {
  id: Id;
  classId: Id;
  subjectId: Id;
  dayId: Id;
}

export interface Cell {
  subjectId: Id;
  teacherId: Id;
}

/** grid[classId][dayId][periodIndex] */
export type Grid = Record<Id, Record<Id, (Cell | null)[]>>;

export interface TimetableState {
  teachers: Named[];
  subjects: Named[];
  days: Named[];
  classes: Named[];
  assignments: Assignment[];
  offs: TeacherOff[];
  bans: Ban[];
  pairs: PairRule[];
  periodsPerDay: number;
  year: string;
  startDate: string;
  principal: string;
  schoolName: string;
  directorate: string;
  schoolNote: string;
  /** custom title-band colors used by every timetable/export */
  sheetTitleColor?: string;
  sheetTitleTextColor?: string;
  /** split the sheet into two pages */
  splitPages: boolean;
  /** how many classes go on page one when split */
  firstPageClasses: number;
  grid: Grid;
  /** class/day/period keys that cannot be edited or used as swap targets */
  lockedCells: string[];
}

/** Keep the complete timetable together so PDF and print use one page. */
export function pageGroups(state: TimetableState): Named[][] {
  return [state.classes];
}

export const uid = () => Math.random().toString(36).slice(2, 10);

export function emptyGrid(state: {
  classes: Named[];
  days: Named[];
  periodsPerDay: number;
}): Grid {
  const grid: Grid = {};
  for (const c of state.classes) {
    const row: Record<Id, (Cell | null)[]> = {};
    for (const d of state.days) {
      row[d.id] = Array.from({ length: state.periodsPerDay }, () => null);
    }
    grid[c.id] = row;
  }
  return grid;
}

export function normalizeGrid(state: TimetableState): Grid {
  const grid: Grid = {};
  for (const c of state.classes) {
    const byDay: Record<Id, (Cell | null)[]> = {};
    for (const d of state.days) {
      const row = state.grid?.[c.id]?.[d.id] ?? [];
      byDay[d.id] = Array.from(
        { length: state.periodsPerDay },
        (_, i) => row[i] ?? null
      );
    }
    grid[c.id] = byDay;
  }
  return grid;
}

export const defaultState = (): TimetableState => {
  const days = [
    { id: uid(), name: "یەکشەممە" },
    { id: uid(), name: "دووشەممە" },
    { id: uid(), name: "سێشەممە" },
    { id: uid(), name: "چوارشەممە" },
    { id: uid(), name: "پێنجشەممە" },
    { id: uid(), name: "شەممە" },
  ];
  const classes = [
    "پۆلی یەکەم",
    "پۆلی دووەم",
    "پۆلی سێیەم",
    "پۆلی چوارەم",
    "پۆلی پێنجەم",
    "پۆلی شەشەم",
  ].map(name => ({ id: uid(), name }));

  const base: TimetableState = {
    teachers: [],
    subjects: [],
    days,
    classes,
    assignments: [],
    offs: [],
    bans: [],
    pairs: [],
    periodsPerDay: 6,
    year: "2026_2027",
    startDate: "1/10/2026",
    principal: "",
    schoolName: "",
    directorate: "",
    schoolNote: "",
    sheetTitleColor: "#263577",
    sheetTitleTextColor: "#ffffff",
    splitPages: false,
    firstPageClasses: 3,
    grid: {},
    lockedCells: [],
  };
  base.grid = emptyGrid(base);
  return base;
};

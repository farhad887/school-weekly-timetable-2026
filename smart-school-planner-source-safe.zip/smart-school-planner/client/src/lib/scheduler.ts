import type { Cell, Grid, Id, Named, TimetableState } from "./timetable-types";

export interface SolveResult {
  grid: Grid;
  unplaced: { classId: Id; subjectId: Id; teacherId: Id; count: number }[];
  /** 4/5/8-per-week assignments that could not be given a sixth-period lesson. */
  missingSix?: { classId: Id; subjectId: Id; teacherId: Id }[];
  ok: boolean;
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function shuffle<T>(arr: T[], rnd: () => number): T[] {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    const t = a[i]!;
    a[i] = a[j]!;
    a[j] = t;
  }
  return a;
}

/**
 * How many lessons per day:
 * - counts up to 5 are kept on distinct days whenever the timetable has
 *   enough available days; an unavailable day leaves the lesson unplaced
 *   instead of repeating it on another day
 * - counts above 5 may repeat a day when necessary
 */
export function dayDistribution(
  count: number,
  dayCount: number,
  rnd: () => number
): number[] {
  const res = new Array<number>(dayCount).fill(0);
  if (dayCount === 0) return res;
  const order = shuffle(
    Array.from({ length: dayCount }, (_, i) => i),
    rnd
  );
  // Eight weekly lessons are intentionally spread as 2,2,2,1,1.
  // The active days are shuffled, so the school does not always get the
  // same weekdays, while the three double-days remain predictable.
  if (count === 8 && dayCount >= 5) {
    order.slice(0, 3).forEach(i => {
      res[i] = 2;
    });
    order.slice(3, 5).forEach(i => {
      res[i] = 1;
    });
    return res;
  }
  let left = count;
  let round = 0;
  while (left > 0) {
    for (const i of order) {
      if (left === 0) break;
      if (res[i]! <= round) {
        res[i]! += 1;
        left -= 1;
      }
    }
    round += 1;
  }
  return res;
}

interface Lesson {
  ci: number;
  ti: number;
  assignmentId: Id;
  subjectId: Id;
  teacherId: Id;
}

/** Bipartite edge coloring: always succeeds with P colors when all degrees <= P. */
function edgeColor(
  edges: { u: number; v: number }[],
  nU: number,
  nV: number,
  P: number
): number[] | null {
  const colorAtU: number[][] = Array.from({ length: nU }, () =>
    new Array<number>(P).fill(-1)
  );
  const colorAtV: number[][] = Array.from({ length: nV }, () =>
    new Array<number>(P).fill(-1)
  );
  const result = new Array<number>(edges.length).fill(-1);

  const freeColor = (row: number[]) => row.findIndex(x => x === -1);

  for (let e = 0; e < edges.length; e++) {
    const { u, v } = edges[e]!;
    const a = freeColor(colorAtU[u]!);
    const b = freeColor(colorAtV[v]!);
    if (a < 0 || b < 0) return null;
    if (a === b) {
      result[e] = a;
      colorAtU[u]![a] = e;
      colorAtV[v]![a] = e;
      continue;
    }
    // flip alternating (a,b) path starting from v
    let cur = v;
    let side: "v" | "u" = "v";
    let want = a; // at v we look for edge colored a
    const path: { e: number; from: "v" | "u" }[] = [];
    let guard = 0;
    while (guard++ < 10000) {
      const edgeIdx =
        side === "v" ? colorAtV[cur]![want]! : colorAtU[cur]![want]!;
      if (edgeIdx === -1) break;
      path.push({ e: edgeIdx, from: side });
      const ed = edges[edgeIdx]!;
      if (side === "v") {
        cur = ed.u;
        side = "u";
      } else {
        cur = ed.v;
        side = "v";
      }
      want = want === a ? b : a;
    }
    for (const step of path) {
      const ed = edges[step.e]!;
      const old = result[step.e]!;
      const nw = old === a ? b : a;
      colorAtU[ed.u]![old] = -1;
      colorAtV[ed.v]![old] = -1;
      result[step.e] = nw;
    }
    for (const step of path) {
      const ed = edges[step.e]!;
      colorAtU[ed.u]![result[step.e]!] = step.e;
      colorAtV[ed.v]![result[step.e]!] = step.e;
    }
    if (colorAtU[u]![a] === -1 && colorAtV[v]![a] === -1) {
      result[e] = a;
      colorAtU[u]![a] = e;
      colorAtV[v]![a] = e;
    } else if (colorAtU[u]![b] === -1 && colorAtV[v]![b] === -1) {
      result[e] = b;
      colorAtU[u]![b] = e;
      colorAtV[v]![b] = e;
    } else {
      return null;
    }
  }
  return result;
}

export function solveTimetable(
  state: TimetableState,
  seedBase = 1,
  maxAttempts = 12
): SolveResult {
  const { classes, days, periodsPerDay: P, assignments } = state;
  const D = days.length;

  const emptyResult = (): Grid => {
    const g: Grid = {};
    for (const c of classes) {
      const byDay: Record<Id, (Cell | null)[]> = {};
      for (const d of days) byDay[d.id] = Array.from({ length: P }, () => null);
      g[c.id] = byDay;
    }
    return g;
  };

  if (D === 0 || P === 0 || classes.length === 0) {
    const missingSix = assignments
      .filter(a => a.count === 4 || a.count === 5 || a.count === 8)
      .map(({ classId, subjectId, teacherId }) => ({
        classId,
        subjectId,
        teacherId,
      }));
    return {
      grid: emptyResult(),
      unplaced: [],
      missingSix,
      ok: assignments.length === 0 && missingSix.length === 0,
    };
  }

  const classIdx = new Map(classes.map((c, i) => [c.id, i]));
  const teachers = state.teachers;
  const teacherIdx = new Map(teachers.map((t, i) => [t.id, i]));
  const valid = assignments.filter(
    a =>
      classIdx.has(a.classId) &&
      teacherIdx.has(a.teacherId) &&
      a.count > 0 &&
      a.subjectId
  );
  const requiredSix = valid.filter(
    a => a.count === 4 || a.count === 5 || a.count === 8
  );

  // off / ban lookups
  const offSet = new Set<string>();
  const offDayFull = new Set<string>(); // teacherId|dayIdx whole day
  for (const o of state.offs) {
    const di = days.findIndex(d => d.id === o.dayId);
    if (di < 0) continue;
    if (o.period === 0) {
      offDayFull.add(`${o.teacherId}|${di}`);
      for (let p = 0; p < P; p++) offSet.add(`${o.teacherId}|${di}|${p}`);
    } else offSet.add(`${o.teacherId}|${di}|${o.period - 1}`);
  }
  const banSet = new Set<string>();
  for (const b of state.bans) {
    const di = days.findIndex(d => d.id === b.dayId);
    if (di < 0) continue;
    if (b.period === 0)
      for (let p = 0; p < P; p++)
        banSet.add(`${b.classId}|${di}|${p}|${b.subjectId}`);
    else banSet.add(`${b.classId}|${di}|${b.period - 1}|${b.subjectId}`);
  }

  const totals = new Map<Id, number>();
  for (const a of valid)
    totals.set(a.classId, (totals.get(a.classId) ?? 0) + a.count);
  const overloaded = classes.filter(c => (totals.get(c.id) ?? 0) > D * P);
  let fallbackOverflow: SolveResult["unplaced"] = [];

  let best: {
    grid: Grid;
    score: number;
    unplaced: SolveResult["unplaced"];
    unplacedCount: number;
  } | null = null;

  const attemptLimit = Math.max(1, Math.min(100, Math.floor(maxAttempts)));
  for (let attempt = 0; attempt < attemptLimit; attempt++) {
    const rnd = mulberry32(seedBase * 7919 + attempt * 104729 + 17);
    const attemptOverflow: SolveResult["unplaced"] = [];

    // ---- Step 1: spread lessons across days ----
    const perDay: Lesson[][][] = classes.map(() => days.map(() => []));
    const teacherDayLoad = teachers.map(() => new Array<number>(D).fill(0));
    const classDayLoad = classes.map(() => new Array<number>(D).fill(0));

    const list = shuffle(valid, rnd).sort((a, b) => b.count - a.count);
    for (const a of list) {
      const ci = classIdx.get(a.classId)!;
      const ti = teacherIdx.get(a.teacherId)!;
      const distinctDaysOnly = a.count <= 5;
      const target = dayDistribution(a.count, D, rnd);
      let placedCount = 0;
      const order = Array.from({ length: D }, (_, i) => i).sort(
        (x, y) =>
          target[y]! - target[x]! ||
          classDayLoad[ci]![x]! - classDayLoad[ci]![y]!
      );
      let need = a.count;
      // first pass: respect target and off days
      for (const di of order) {
        let want = target[di]!;
        while (
          want > 0 &&
          need > 0 &&
          classDayLoad[ci]![di]! < P &&
          (!distinctDaysOnly ||
            !perDay[ci]![di]!.some(l => l.assignmentId === a.id)) &&
          teacherDayLoad[ti]![di]! < P &&
          !offDayFull.has(`${a.teacherId}|${di}`)
        ) {
          perDay[ci]![di]!.push({
            ci,
            ti,
            assignmentId: a.id,
            subjectId: a.subjectId,
            teacherId: a.teacherId,
          });
          classDayLoad[ci]![di]!++;
          teacherDayLoad[ti]![di]!++;
          want--;
          need--;
          placedCount++;
        }
      }
      // second pass: compensate (off days / full days) on any other day
      while (need > 0) {
        const cand = Array.from({ length: D }, (_, i) => i)
          .filter(
            di =>
              classDayLoad[ci]![di]! < P &&
              (!distinctDaysOnly ||
                !perDay[ci]![di]!.some(l => l.assignmentId === a.id)) &&
              teacherDayLoad[ti]![di]! < P &&
              !offDayFull.has(`${a.teacherId}|${di}`)
          )
          .sort((x, y) => perDay[ci]![x]!.length - perDay[ci]![y]!.length);
        const di = cand[0];
        if (di === undefined) {
          attemptOverflow.push({
            classId: a.classId,
            subjectId: a.subjectId,
            teacherId: a.teacherId,
            count: need,
          });
          break;
        }
        perDay[ci]![di]!.push({
          ci,
          ti,
          assignmentId: a.id,
          subjectId: a.subjectId,
          teacherId: a.teacherId,
        });
        classDayLoad[ci]![di]!++;
        teacherDayLoad[ti]![di]!++;
        need--;
        placedCount++;
      }
      void placedCount;
    }
    fallbackOverflow = attemptOverflow;

    // ---- Step 2: per-day bipartite edge coloring -> periods ----
    const grid: (Cell | null)[][][] = classes.map(() =>
      days.map(() => Array.from({ length: P }, () => null as Cell | null))
    );
    let feasible = true;
    for (let di = 0; di < D; di++) {
      const edges: { u: number; v: number }[] = [];
      const lessons: Lesson[] = [];
      for (let ci = 0; ci < classes.length; ci++)
        for (const l of perDay[ci]![di]!) {
          edges.push({ u: ci, v: l.ti });
          lessons.push(l);
        }
      const colors = edgeColor(edges, classes.length, teachers.length, P);
      if (!colors) {
        feasible = false;
        break;
      }
      colors.forEach((p, i) => {
        const l = lessons[i]!;
        grid[l.ci]![di]![p] = {
          subjectId: l.subjectId,
          teacherId: l.teacherId,
        };
      });
    }
    if (!feasible) continue;

    // ---- Step 3: local repair for off / ban / spacing (keeps zero conflicts) ----
    const pairSet = new Set(
      (state.pairs ?? []).map(r => {
        const di = days.findIndex(d => d.id === r.dayId);
        return `${r.classId}|${r.subjectId}|${di}`;
      })
    );
    // Eight-lesson assignments automatically require adjacent lessons on
    // every day where their 2,2,2,1,1 distribution places a double lesson.
    for (const rule of valid.filter(a => a.count === 8)) {
      const ci = classIdx.get(rule.classId)!;
      for (let di = 0; di < D; di++) {
        const n = grid[ci]![di]!.filter(
          cell =>
            cell?.subjectId === rule.subjectId &&
            cell.teacherId === rule.teacherId
        ).length;
        if (n >= 2) pairSet.add(`${rule.classId}|${rule.subjectId}|${di}`);
      }
    }
    const penalty = (ci: number, di: number, p: number, cell: Cell | null) => {
      if (!cell) return 0;
      let s = 0;
      if (offSet.has(`${cell.teacherId}|${di}|${p}`)) s += 100;
      if (banSet.has(`${classes[ci]!.id}|${di}|${p}|${cell.subjectId}`))
        s += 100;
      const wantPair = pairSet.has(
        `${classes[ci]!.id}|${cell.subjectId}|${di}`
      );
      const prev = grid[ci]![di]![p - 1];
      const next = grid[ci]![di]![p + 1];
      const touching =
        (prev && prev.subjectId === cell.subjectId) ||
        (next && next.subjectId === cell.subjectId);
      if (wantPair) {
        let n = 0;
        for (let q = 0; q < P; q++)
          if (grid[ci]![di]![q]?.subjectId === cell.subjectId) n++;
        if (n >= 2 && !touching) s += 30;
      } else {
        if (prev && prev.subjectId === cell.subjectId) s += 20;
        if (next && next.subjectId === cell.subjectId) s += 20;
      }
      return s;
    };

    const rowScore = (ci: number, di: number) => {
      let s = 0;
      for (let p = 0; p < P; p++) s += penalty(ci, di, p, grid[ci]![di]![p]!);
      return s;
    };
    const hardRuleScore = (ci: number, di: number) => {
      let s = 0;
      const classId = classes[ci]!.id;
      for (let p = 0; p < P; p++) {
        const cell = grid[ci]![di]![p];
        if (!cell) continue;
        if (offSet.has(`${cell.teacherId}|${di}|${p}`)) s++;
        if (banSet.has(`${classId}|${di}|${p}|${cell.subjectId}`)) s++;
      }
      return s;
    };
    const sixthPenalty = () => {
      if (P < 6) return requiredSix.length * 1000;
      let deviation = 0;
      for (const rule of requiredSix) {
        const ci = classIdx.get(rule.classId)!;
        let sixthCount = 0;
        days.forEach((_, di) => {
          const cell = grid[ci]![di]![5];
          if (
            cell?.subjectId === rule.subjectId &&
            cell.teacherId === rule.teacherId
          )
            sixthCount++;
        });
        deviation += Math.abs(sixthCount - 1);
      }
      return deviation * 1000;
    };
    const teacherFree = (
      teacherId: Id,
      di: number,
      p: number,
      exceptCi: number
    ) => {
      for (let ci = 0; ci < classes.length; ci++) {
        if (ci === exceptCi) continue;
        if (grid[ci]![di]![p]?.teacherId === teacherId) return false;
      }
      return true;
    };

    const rnd2 = mulberry32(seedBase + attempt * 31 + 7);
    for (let iter = 0; iter < 4000; iter++) {
      const ci = Math.floor(rnd2() * classes.length);
      const di = Math.floor(rnd2() * D);
      const p1 = Math.floor(rnd2() * P);
      const p2 = Math.floor(rnd2() * P);
      if (p1 === p2) continue;
      const A = grid[ci]![di]![p1]!;
      const B = grid[ci]![di]![p2]!;
      if (!A && !B) continue;
      if (A && !teacherFree(A.teacherId, di, p2, ci)) continue;
      if (B && !teacherFree(B.teacherId, di, p1, ci)) continue;
      const before = rowScore(ci, di) + sixthPenalty();
      const hardBefore = hardRuleScore(ci, di);
      grid[ci]![di]![p1] = B;
      grid[ci]![di]![p2] = A;
      const after = rowScore(ci, di) + sixthPenalty();
      const hardAfter = hardRuleScore(ci, di);
      if (hardAfter > hardBefore || after > before) {
        grid[ci]![di]![p1] = A;
        grid[ci]![di]![p2] = B;
      }
    }

    let score = 0;
    for (let ci = 0; ci < classes.length; ci++)
      for (let di = 0; di < D; di++) score += rowScore(ci, di);
    score += sixthPenalty();

    const out = emptyResult();
    classes.forEach((c, ci) => {
      days.forEach((d, di) => {
        out[c.id]![d.id] = grid[ci]![di]!.slice();
      });
    });
    const unplacedCount = attemptOverflow.reduce((total, item) => total + item.count, 0);
    if (
      !best ||
      unplacedCount < best.unplacedCount ||
      (unplacedCount === best.unplacedCount && score < best.score)
    ) {
      best = { grid: out, score, unplaced: attemptOverflow, unplacedCount };
    }
    if (score === 0 && unplacedCount === 0) break;
  }

  if (!best)
    return {
      grid: emptyResult(),
      unplaced: fallbackOverflow,
      missingSix: requiredSix.map(({ classId, subjectId, teacherId }) => ({
        classId,
        subjectId,
        teacherId,
      })),
      ok: false,
    };
  const missingSix = requiredSix
    .filter(
      rule =>
        P < 6 ||
        days.filter(day => {
          const cell = best!.grid[rule.classId]?.[day.id]?.[5] ?? null;
          return (
            cell?.subjectId === rule.subjectId &&
            cell.teacherId === rule.teacherId
          );
        }).length !== 1
    )
    .map(({ classId, subjectId, teacherId }) => ({
      classId,
      subjectId,
      teacherId,
    }));
  return {
    grid: best.grid,
    unplaced: best.unplaced,
    missingSix,
    ok:
      best.unplaced.length === 0 &&
      overloaded.length === 0 &&
      missingSix.length === 0,
  };
}

/** All teacher double-bookings currently in the grid. */
export function findConflicts(state: TimetableState) {
  const conflicts: {
    dayId: Id;
    period: number;
    teacherId: Id;
    classIds: Id[];
  }[] = [];
  for (const d of state.days) {
    for (let p = 0; p < state.periodsPerDay; p++) {
      const byTeacher = new Map<Id, Id[]>();
      for (const c of state.classes) {
        const cell = state.grid[c.id]?.[d.id]?.[p];
        if (!cell) continue;
        const arr = byTeacher.get(cell.teacherId) ?? [];
        arr.push(c.id);
        byTeacher.set(cell.teacherId, arr);
      }
      byTeacher.forEach((classIds, teacherId) => {
        if (classIds.length > 1)
          conflicts.push({ dayId: d.id, period: p, teacherId, classIds });
      });
    }
  }
  return conflicts;
}

export interface LessonLocation {
  classId: Id;
  dayId: Id;
  /** Zero-based period index. */
  period: number;
}

export type SwapResult =
  | { ok: true; grid: Grid }
  | {
      ok: false;
      reason:
        | "same"
        | "empty"
        | "class"
        | "off"
        | "ban"
        | "conflict"
        | "pair"
        | "sixth";
    };

/** Exchange two occupied lesson cells without changing either assignment. */
export function swapLessons(
  state: TimetableState,
  from: LessonLocation,
  to: LessonLocation
): SwapResult {
  if (
    from.classId === to.classId &&
    from.dayId === to.dayId &&
    from.period === to.period
  )
    return { ok: false, reason: "same" };
  if (from.classId !== to.classId) return { ok: false, reason: "class" };

  const fromCell =
    state.grid[from.classId]?.[from.dayId]?.[from.period] ?? null;
  const toCell = state.grid[to.classId]?.[to.dayId]?.[to.period] ?? null;
  if (!fromCell) return { ok: false, reason: "empty" };

  const grid: Grid = { ...state.grid };
  const rows = new Map<string, (Cell | null)[]>();
  const rowFor = (location: LessonLocation) => {
    const key = JSON.stringify([location.classId, location.dayId]);
    let row = rows.get(key);
    if (!row) {
      row = [...(state.grid[location.classId]?.[location.dayId] ?? [])];
      rows.set(key, row);
      grid[location.classId] = { ...grid[location.classId] };
      grid[location.classId]![location.dayId] = row;
    }
    return row;
  };
  rowFor(from)[from.period] = toCell;
  rowFor(to)[to.period] = fromCell;

  const isOff = (cell: Cell, location: LessonLocation) =>
    state.offs.some(
      off =>
        off.teacherId === cell.teacherId &&
        off.dayId === location.dayId &&
        (off.period === 0 || off.period === location.period + 1)
    );
  const isBanned = (cell: Cell, location: LessonLocation) =>
    state.bans.some(
      ban =>
        ban.classId === location.classId &&
        ban.dayId === location.dayId &&
        ban.subjectId === cell.subjectId &&
        (ban.period === 0 || ban.period === location.period + 1)
    );
  if ((toCell && isOff(toCell, from)) || isOff(fromCell, to))
    return { ok: false, reason: "off" };
  if ((toCell && isBanned(toCell, from)) || isBanned(fromCell, to))
    return { ok: false, reason: "ban" };

  const nextState = { ...state, grid };
  const oldConflicts = new Set(findConflicts(state).map(conflictKey));
  if (
    findConflicts(nextState).some(
      conflict => !oldConflicts.has(conflictKey(conflict))
    )
  )
    return { ok: false, reason: "conflict" };

  const affected = new Set(
    [fromCell, toCell]
      .filter((cell): cell is NonNullable<typeof cell> => !!cell)
      .map(cell => JSON.stringify([from.classId, cell.subjectId, cell.teacherId]))
  );
  const sixthCountFor = (
    candidateGrid: Grid,
    assignment: TimetableState["assignments"][number]
  ) =>
    state.days.reduce(
      (count, day) =>
        count +
        (candidateGrid[assignment.classId]?.[day.id]?.[5]?.subjectId ===
          assignment.subjectId &&
        candidateGrid[assignment.classId]?.[day.id]?.[5]?.teacherId ===
          assignment.teacherId
          ? 1
          : 0),
      0
    );
  for (const assignment of state.assignments) {
    if (assignment.count !== 4 && assignment.count !== 5 && assignment.count !== 8)
      continue;
    if (
      !affected.has(
        JSON.stringify([
          assignment.classId,
          assignment.subjectId,
          assignment.teacherId,
        ])
      )
    )
      continue;
    const before = sixthCountFor(state.grid, assignment);
    const after = sixthCountFor(grid, assignment);
    if (Math.abs(after - 1) > Math.abs(before - 1))
      return { ok: false, reason: "sixth" };
  }

  const hasPairedLessons = (
    candidateGrid: Grid,
    rule: TimetableState["pairs"][number]
  ) => {
    const row = candidateGrid[rule.classId]?.[rule.dayId] ?? [];
    return row.some(
      (cell, period) =>
        period < row.length - 1 &&
        cell?.subjectId === rule.subjectId &&
        row[period + 1]?.subjectId === rule.subjectId
    );
  };
  for (const rule of state.pairs) {
    if (rule.classId !== from.classId) continue;
    if (hasPairedLessons(state.grid, rule) && !hasPairedLessons(grid, rule))
      return { ok: false, reason: "pair" };
  }

  return { ok: true, grid };
}

function conflictKey(conflict: {
  dayId: Id;
  period: number;
  teacherId: Id;
  classIds: Id[];
}) {
  return `${conflict.dayId}|${conflict.period}|${conflict.teacherId}|${[...conflict.classIds].sort().join(",")}`;
}

export function nameOf(list: Named[], id: Id) {
  return list.find(x => x.id === id)?.name ?? "";
}

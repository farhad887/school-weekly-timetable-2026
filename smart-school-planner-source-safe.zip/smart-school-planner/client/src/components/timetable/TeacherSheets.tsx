import { Fragment } from "react";
import type { Lang } from "@/lib/i18n";
import { isRtl, t, tName, getLang } from "@/lib/i18n";
import { nameOf } from "@/lib/scheduler";
import type { Named, TimetableState } from "@/lib/timetable-types";
import { entityStyle } from "@/lib/entity-colors";
import { fitCellFont, type SheetTypography } from "./TimetableSheet";
import { sheetFontFamily } from "@/lib/typography";

export const TEACHER_SHEETS_ROOT = "teacher-sheets-pages";
const LINE = "0.3mm solid #8994b8";
const COLORS = {
  title: "#263577",
  head: "#e0e6fb",
  day: "#f9efd9",
  cell: "#eef1fc",
};

export function TeacherSheets({
  state,
  lang = getLang(),
  typography,
}: {
  state: TimetableState;
  lang?: Lang;
  typography?: SheetTypography;
}) {
  return (
    <div
      id={TEACHER_SHEETS_ROOT}
      style={{ display: "flex", flexDirection: "column", gap: 12 }}
    >
      {state.teachers.map(teacher => (
        <TeacherSheet
          key={teacher.id}
          state={state}
          teacher={teacher}
          lang={lang}
          typography={typography}
        />
      ))}
      {state.teachers.length === 0 && (
        <div className="rounded-lg border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
          {t("ts.empty", lang)}
        </div>
      )}
    </div>
  );
}

function TeacherSheet({
  state,
  teacher,
  lang,
  typography,
}: {
  state: TimetableState;
  teacher: Named;
  lang: Lang;
  typography?: SheetTypography;
}) {
  const rtl = isRtl(lang);
  const titleSize = Math.max(8, Math.min(40, typography?.titleSize ?? 27));
  const daySize = Math.max(8, Math.min(40, typography?.daySize ?? 18));
  const bodySize = Math.max(8, Math.min(40, typography?.bodySize ?? 14));
  const typeWeight = 700;
  const text = (id: string) => nameOf(state.subjects, id);
  const cellFor = (dayId: string, period: number) => {
    for (const klass of state.classes) {
      const cell = state.grid[klass.id]?.[dayId]?.[period] ?? null;
      if (cell?.teacherId === teacher.id)
        return {
          className: tName(klass.name, lang),
          subject: text(cell.subjectId),
          subjectId: cell.subjectId,
        };
    }
    return { className: "", subject: "", subjectId: "" };
  };
  const border: React.CSSProperties = {
    borderTop: LINE,
    borderBottom: LINE,
    borderLeft: LINE,
    borderRight: LINE,
  };
  const base: React.CSSProperties = {
    ...border,
    padding: "5px 4px",
    textAlign: "center",
    verticalAlign: "middle",
    fontSize: `${bodySize}px`,
    fontWeight: typeWeight,
    lineHeight: 1.2,
    color: "#000",
    wordBreak: "break-word",
    overflowWrap: "anywhere",
  };
  return (
    <div
      className="timetable-page"
      style={{
        ...({
          "--sheet-title-color": state.sheetTitleColor || COLORS.title,
          "--sheet-title-text": state.sheetTitleTextColor || "#fff",
          "--sheet-font-family": sheetFontFamily(typography?.font),
        } as React.CSSProperties),
        fontFamily: sheetFontFamily(typography?.font),
        background: "#fff",
        padding: 6,
        color: "#000",
        width: "100%",
        aspectRatio: "297 / 210",
        display: "flex",
        flexDirection: "column",
        direction: rtl ? "rtl" : "ltr",
      }}
    >
      <div
        className="sheet-glass-frame"
        style={{
          ...border,
          flex: 1,
          minHeight: 0,
          display: "flex",
          flexDirection: "column",
        }}
      >
        <div
          className="sheet-title-band vip-title-band"
          style={{
            ...({
              "--sheet-title-color": state.sheetTitleColor || COLORS.title,
              "--sheet-title-text": state.sheetTitleTextColor || "#fff",
            } as React.CSSProperties),
            ...entityStyle(teacher.id, "teacher", rtl, teacher.color),
            background: state.sheetTitleColor || COLORS.title,
            color: state.sheetTitleTextColor || "#fff",
            borderBottom: LINE,
            padding: "8px 4px",
            textAlign: "center",
          }}
        >
          <div style={{ fontSize: Math.round(titleSize * 1.25), fontWeight: typeWeight }}>
            <span
              className="teacher-color-name"
              style={entityStyle(teacher.id, "teacher", rtl, teacher.color)}
            >
              {tName(teacher.name, lang)}
            </span>
          </div>
        </div>
        <table
          style={{
            width: "100%",
            height: "100%",
            minHeight: 0,
            flex: "1 1 auto",
            borderCollapse: "collapse",
            tableLayout: "fixed",
          }}
        >
          <thead>
            <tr>
              <th style={{ ...base, fontSize: titleSize, background: COLORS.head, width: "16%" }}>
                {t("sheet.days", lang)}
              </th>
              {Array.from({ length: state.periodsPerDay }, (_, p) => (
                <th
                  key={p}
                  colSpan={2}
                  style={{ ...base, fontSize: titleSize, background: COLORS.head }}
                >
                  {t("sheet.period", lang)} {p + 1}
                </th>
              ))}
            </tr>
            <tr>
              <th style={{ ...base, background: COLORS.head }}></th>
              {Array.from({ length: state.periodsPerDay }, (_, p) => (
                <Fragment key={p}>
                  <th
                    style={{ ...base, background: COLORS.head, fontSize: Math.round(titleSize * .65) }}
                  >
                    {t("ts.class", lang)}
                  </th>
                  <th
                    style={{ ...base, background: COLORS.head, fontSize: Math.round(titleSize * .65) }}
                  >
                    {t("sheet.subject", lang)}
                  </th>
                </Fragment>
              ))}
            </tr>
          </thead>
          <tbody>
            {state.days.map(day => (
              <tr key={day.id}>
                <td
                  className="sheet-day-cell"
                  style={{ ...base, background: COLORS.day, fontSize: daySize }}
                >
                  {tName(day.name, lang)}
                </td>
                {Array.from({ length: state.periodsPerDay }, (_, p) => {
                  const entry = cellFor(day.id, p);
                  return (
                    <Fragment key={p}>
                      <td
                        className={
                          entry.className ? "entity-color-cell" : undefined
                        }
                        style={{
                          ...base,
                          fontSize: entry.className
                          ? Math.max(11, fitCellFont(entry.className, state.classes.length, bodySize))
                            : bodySize,
                          background: COLORS.cell,
                          minHeight: 34,
                          ...(entry.className
                            ? entityStyle(
                                teacher.id,
                                "teacher",
                                rtl,
                                teacher.color
                              )
                            : {}),
                        }}
                      >
                        {entry.className}
                      </td>
                      <td
                        className={
                          entry.subjectId ? "entity-color-cell" : undefined
                        }
                        style={{
                          ...base,
                          fontSize: entry.subject
                            ? Math.max(11, fitCellFont(entry.subject, state.classes.length, bodySize))
                            : bodySize,
                          background: COLORS.cell,
                          minHeight: 34,
                          ...(entry.subjectId
                            ? entityStyle(
                                teacher.id,
                                "teacher",
                                rtl,
                                teacher.color
                              )
                            : {}),
                        }}
                      >
                        {entry.subject}
                      </td>
                    </Fragment>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

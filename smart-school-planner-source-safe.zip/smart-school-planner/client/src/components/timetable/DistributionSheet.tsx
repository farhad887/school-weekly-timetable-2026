import type { Lang } from "@/lib/i18n";
import { getLang, isRtl, t, tName } from "@/lib/i18n";
import { nameOf } from "@/lib/scheduler";
import type { Assignment, Named, TimetableState } from "@/lib/timetable-types";
import { entityStyle } from "@/lib/entity-colors";
import type { SheetTypography } from "./TimetableSheet";
import { DEFAULT_DISTRIBUTION_TYPOGRAPHY, sheetFontFamily, type DistributionTypographySettings } from "@/lib/typography";

export const DISTRIBUTION_ROOT = "distribution-sheets-pages";
export type DistributionPageSize = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10;
export type DistributionClassSize =
  | 1
  | 2
  | 3
  | 4
  | 5
  | 6
  | 7
  | 8
  | 9
  | 10
  | 11
  | 12;

const COLORS = { yellow: "#f9efd9", blue: "#dceafb", line: "#8994b8" };
const border = `0.6mm solid ${COLORS.line}`;

export function distributionGroups<T>(items: T[], size: number): T[][] {
  const safe = Math.max(1, size);
  const groups: T[][] = [];
  for (let i = 0; i < items.length; i += safe)
    groups.push(items.slice(i, i + safe));
  return groups.length ? groups : [[]];
}

function rowsFor(
  state: TimetableState,
  teachers: Named[]
): { teacher: Named; assignment: Assignment }[] {
  const out: { teacher: Named; assignment: Assignment }[] = [];
  for (const teacher of teachers) {
    state.assignments
      .filter(a => a.teacherId === teacher.id)
      .forEach(assignment => out.push({ teacher, assignment }));
  }
  return out;
}

function groupedRows(
  state: TimetableState,
  teachers: Named[],
  classes: Named[]
) {
  const classIds = new Set(classes.map(c => c.id));
  return teachers.map(teacher => ({
    teacher,
    rows: Array.from(
      state.assignments
        .filter(a => a.teacherId === teacher.id && classIds.has(a.classId))
        .reduce((map, assignment) => {
          const current = map.get(assignment.subjectId) ?? {
            subjectId: assignment.subjectId,
            counts: new Map<string, number>(),
            total: 0,
          };
          current.counts.set(
            assignment.classId,
            (current.counts.get(assignment.classId) ?? 0) + assignment.count
          );
          current.total += assignment.count;
          map.set(assignment.subjectId, current);
          return map;
        }, new Map<string, { subjectId: string; counts: Map<string, number>; total: number }>())
        .values()
    ),
  }));
}

export function DistributionSheets({
  state,
  lang = getLang(),
  teachersPerPage = 6,
  classesPerPage = 6,
  typography,
  distributionTypography = DEFAULT_DISTRIBUTION_TYPOGRAPHY,
}: {
  state: TimetableState;
  lang?: Lang;
  teachersPerPage?: number;
  classesPerPage?: number;
  typography?: SheetTypography;
  distributionTypography?: DistributionTypographySettings;
}) {
  const teacherGroups = distributionGroups(state.teachers, teachersPerPage);
  const classGroups = distributionGroups(state.classes, classesPerPage);
  return (
    <div
      id={DISTRIBUTION_ROOT}
      style={{ display: "flex", flexDirection: "column", gap: 12 }}
    >
      {teacherGroups.flatMap((teachers, ti) =>
        classGroups.map((classes, ci) => (
          <DistributionPage
            key={`${ti}-${ci}`}
            state={state}
            teachers={teachers}
            classes={classes}
            lang={lang}
            pageNo={
              teacherGroups.length * classGroups.length > 1
                ? ti * classGroups.length + ci + 1
                : undefined
            }
            typography={typography}
            distributionTypography={distributionTypography}
          />
        ))
      )}
      {state.teachers.length === 0 && (
        <div className="rounded-lg border border-dashed p-8 text-center text-sm">
          {t("ds.empty", lang)}
        </div>
      )}
    </div>
  );
}

function DistributionPage({
  state,
  teachers,
  classes,
  lang,
  pageNo,
  typography,
  distributionTypography,
}: {
  state: TimetableState;
  teachers: Named[];
  classes: Named[];
  lang: Lang;
  pageNo?: number;
  typography?: SheetTypography;
  distributionTypography: DistributionTypographySettings;
}) {
  const rtl = isRtl(lang);
  const classIds = new Set(classes.map(c => c.id));
  const rows = rowsFor(state, teachers).filter(row =>
    classIds.has(row.assignment.classId)
  );
  const groups = groupedRows(state, teachers, classes);
  const total = rows.reduce((sum, row) => sum + row.assignment.count, 0);
  const contentSize = Math.max(8, Math.min(40, distributionTypography.contentSize));
  const headerSize = Math.max(8, Math.min(40, distributionTypography.headerSize));
  const teacherSize = Math.max(8, Math.min(40, distributionTypography.teacherSize));
  const classSize = Math.max(8, Math.min(40, distributionTypography.classSize));
  const fontWeight = 700;
  const fontFamily = sheetFontFamily(distributionTypography.font);
  const metadataSize = Math.max(8, Math.min(40, distributionTypography.metadataSize));
  const cell: React.CSSProperties = {
    border,
    textAlign: "center",
    verticalAlign: "middle",
    padding: "3px 2px",
    fontSize: contentSize,
    fontWeight,
    color: "#000",
    wordBreak: "break-word",
    overflowWrap: "anywhere",
    lineHeight: 1.1,
  };
  const teacherCell: React.CSSProperties = {
    ...cell,
    border: "1mm solid #111",
  };
  const headCell: React.CSSProperties = { ...cell, fontSize: headerSize };
  const titleSize = Math.max(8, Math.min(40, distributionTypography.titleSize));
  return (
    <div
      className="timetable-page distribution-page"
      style={{
        ...({
          "--sheet-title-color": state.sheetTitleColor || "#263577",
          "--sheet-title-text": state.sheetTitleTextColor || "#fff",
          "--sheet-font-family": fontFamily,
        } as React.CSSProperties),
        background: "#fff",
        color: "#000",
        direction: rtl ? "rtl" : "ltr",
        padding: "2mm",
        display: "flex",
        flexDirection: "column",
        fontFamily,
      }}
    >
      <div
        className="sheet-title-band vip-title-band"
        style={{
          ...({
            "--sheet-title-color": state.sheetTitleColor || "#263577",
            "--sheet-title-text": state.sheetTitleTextColor || "#fff",
          } as React.CSSProperties),
          flex: "0 0 auto",
          background: state.sheetTitleColor || "#263577",
          fontWeight,
          fontSize: titleSize,
          lineHeight: 1.35,
          marginBottom: 8,
          padding: "10px 12px",
          borderRadius: 12,
          color: state.sheetTitleTextColor || "#fff",
          textAlign: "center",
          position: "relative",
          overflow: "hidden",
        }}
      >
        <div style={{ textAlign: "right", fontSize: Math.round(titleSize * .7), marginBottom: 2 }}>
          <div>{state.directorate}</div>
          <div>{state.schoolName}</div>
        </div>
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: titleSize }}>{t("ds.title", lang)}</div>
          <div>
            {t("sheet.year", lang)} {state.year}
          </div>
          {pageNo && (
            <div style={{ fontSize: Math.round(titleSize * .6) }}>
              {t("sheet.page", lang)} {pageNo}
            </div>
          )}
        </div>
      </div>
      <table
        style={{
          width: "100%",
          flex: "1 1 auto",
          height: "100%",
          minHeight: 0,
          borderCollapse: "collapse",
          tableLayout: "fixed",
          fontSize: contentSize,
        }}
      >
        <thead>
          <tr>
            <th
              style={{ ...headCell, background: COLORS.yellow, width: "4%" }}
              rowSpan={2}
            >
              #
            </th>
            <th
              style={{ ...headCell, background: COLORS.yellow, width: "16%" }}
              rowSpan={2}
            >
              {t("ds.teacher", lang)}
            </th>
            <th
              style={{ ...headCell, background: COLORS.yellow, width: "12%" }}
              rowSpan={2}
            >
              {t("ds.specialty", lang)}
            </th>
            <th
              style={{ ...headCell, background: COLORS.yellow, width: "12%" }}
              rowSpan={2}
            >
              {t("ds.subject", lang)}
            </th>
            {classes.map(klass => (
              <th
                key={klass.id}
                className="distribution-class-cell"
                style={{ ...headCell, fontSize: classSize, background: COLORS.yellow }}
                rowSpan={2}
              >
                {tName(klass.name, lang)}
              </th>
            ))}
            <th
              style={{ ...headCell, background: COLORS.yellow, width: "8%" }}
              rowSpan={2}
            >
              {t("ds.quota", lang)}
            </th>
            <th
              style={{ ...headCell, background: COLORS.yellow, width: "10%" }}
              rowSpan={2}
            >
              {t("ds.notes", lang)}
            </th>
          </tr>
          <tr />
        </thead>
        <tbody>
          {groups.map(({ teacher, rows: subjectRows }, teacherIndex) => {
            const teacherRows = subjectRows.length
              ? subjectRows
              : [
                  {
                    subjectId: "",
                    counts: new Map<string, number>(),
                    total: 0,
                  },
                ];
            const teacherTotal = subjectRows.reduce(
              (sum, row) => sum + row.total,
              0
            );
            return teacherRows.map((row, rowIndex) => (
              <tr key={`${teacher.id}-${row.subjectId || "empty"}`}>
                {rowIndex === 0 && (
                  <td
                    rowSpan={teacherRows.length}
                    style={{ ...teacherCell, background: COLORS.yellow }}
                  >
                    {teacherIndex + 1}
                  </td>
                )}
                {rowIndex === 0 && (
                  <td
                    rowSpan={teacherRows.length}
                    className="entity-color-cell"
                    style={{
                      ...teacherCell,
                      background: COLORS.yellow,
                      fontSize: teacherSize,
                      ...entityStyle(teacher.id, "teacher", rtl, teacher.color),
                    }}
                  >
                    {tName(teacher.name, lang)}
                  </td>
                )}
                {rowIndex === 0 && (
                  <td
                    rowSpan={teacherRows.length}
                    style={{ ...teacherCell, background: COLORS.yellow }}
                  >
                    {teacher.specialty || ""}
                  </td>
                )}
                <td
                  className={row.subjectId ? "entity-color-cell" : undefined}
                  style={{
                    ...cell,
                    background: COLORS.blue,
                    ...(row.subjectId
                      ? entityStyle(teacher.id, "teacher", rtl, teacher.color)
                      : {}),
                  }}
                >
                  {row.subjectId ? nameOf(state.subjects, row.subjectId) : ""}
                </td>
                {classes.map(klass => (
                  <td
                    key={klass.id}
                    className={`distribution-class-cell${row.subjectId ? " entity-color-cell" : ""}`}
                    style={{
                      ...cell,
                      background: COLORS.blue,
                      ...(row.subjectId
                        ? entityStyle(teacher.id, "teacher", rtl, teacher.color)
                        : {}),
                    }}
                  >
                    {row.counts.get(klass.id) || ""}
                  </td>
                ))}
                {rowIndex === 0 && (
                  <td
                    rowSpan={teacherRows.length}
                    style={{ ...teacherCell, background: COLORS.blue }}
                  >
                    {teacherTotal || ""}
                  </td>
                )}
                {rowIndex === 0 && (
                  <td
                    rowSpan={teacherRows.length}
                    style={{ ...teacherCell, background: COLORS.yellow }}
                  />
                )}
              </tr>
            ));
          })}
          <tr>
            <td style={{ ...cell, background: COLORS.yellow }} colSpan={4}>
              {t("ds.lessonsTotal", lang)}
            </td>
            {classes.map(klass => (
              <td key={klass.id} className="distribution-class-cell" style={{ ...cell, background: COLORS.yellow }}>
                {rows
                  .filter(r => r.assignment.classId === klass.id)
                  .reduce((s, r) => s + r.assignment.count, 0)}
              </td>
            ))}
            <td style={{ ...cell, background: COLORS.yellow }}>{total}</td>
            <td style={{ ...cell, background: COLORS.yellow }} />
          </tr>
        </tbody>
      </table>
      <div
        className="sheet-footer"
        style={{
          display: "flex",
          justifyContent: "space-between",
          marginTop: "auto",
          fontWeight,
          fontSize: metadataSize,
        }}
      >
        <span>
          {t("sheet.noteA", lang)} {state.startDate} {t("sheet.noteB", lang)}
        </span>
        <span>
          {t("sheet.principal", lang)}
          <br />
          {state.principal}
        </span>
      </div>
    </div>
  );
}

export function distributionRowsForExport(
  state: TimetableState,
  teachers: Named[],
  classes: Named[]
) {
  return rowsFor(state, teachers).map(({ teacher, assignment }, index) => ({
    index: index + 1,
    teacher,
    assignment,
    classes,
  }));
}

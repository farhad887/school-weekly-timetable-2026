import type { Named, TimetableState } from "@/lib/timetable-types";
import { nameOf } from "@/lib/scheduler";
import { t, tName, isRtl, getLang, type Lang } from "@/lib/i18n";
import { fitCellFont, SHEET_COLORS, type SheetTypography } from "./TimetableSheet";
import { entityStyle } from "@/lib/entity-colors";
import { sheetFontFamily } from "@/lib/typography";

const THIN = `0.3mm solid ${SHEET_COLORS.line}`;
const THIN_BOX: React.CSSProperties = {
  borderTop: THIN,
  borderBottom: THIN,
  borderLeft: THIN,
  borderRight: THIN,
};

export const CLASS_SHEETS_ROOT = "class-sheets-pages";

export type PerPage = 1 | 2 | 3 | 4;
export type CopiesPerSheet = 1 | 2 | 3 | 4 | 5 | 6;

/* one column => every class table uses the full page width */
const COLS: Record<PerPage, number> = { 1: 1, 2: 1, 3: 1, 4: 1 };

function chunk<T>(arr: T[], size: number): T[][] {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

/** printable pages of class timetables — subjects only, no teacher names */
export function ClassSheets({
  state,
  lang = getLang(),
  perPage = 1,
  copiesPerSheet = 1,
  typography,
}: {
  state: TimetableState;
  lang?: Lang;
  perPage?: PerPage;
  copiesPerSheet?: CopiesPerSheet;
  typography?: SheetTypography;
}) {
  const copies = Math.max(1, Math.min(6, copiesPerSheet)) as CopiesPerSheet;
  const pages = chunk(state.classes, perPage);
  return (
    <div
      id={CLASS_SHEETS_ROOT}
      style={{ display: "flex", flexDirection: "column", gap: "12px" }}
    >
      {pages.map((group, i) => (
        <div
          key={i}
          className="timetable-page class-sheets-page"
          style={{
            ...({
              "--sheet-title-color": state.sheetTitleColor || SHEET_COLORS.title,
              "--sheet-title-text": state.sheetTitleTextColor || SHEET_COLORS.titleText,
              "--sheet-font-family": sheetFontFamily(typography?.font),
            } as React.CSSProperties),
            fontFamily: sheetFontFamily(typography?.font),
            background: "#fff",
            padding: "2mm",
            color: "#000",
            display: "grid",
            gridTemplateColumns: `repeat(${COLS[perPage]}, minmax(0, 1fr))`,
            gridTemplateRows: `repeat(${group.length}, minmax(0, 1fr))`,
            gap: "3mm",
            alignItems: "stretch",
            width: "100%",
            aspectRatio: "210 / 297",
            boxSizing: "border-box",
            direction: isRtl(lang) ? "rtl" : "ltr",
          }}
        >
          {group.map(c => (
            <div
              key={c.id}
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "8px",
                minHeight: 0,
              }}
            >
              {Array.from({ length: copies }, (_, idx) => (
                <ClassSheetCard
                  key={`${c.id}-${idx}`}
                  state={state}
                  klass={c}
                  lang={lang}
                  perPage={perPage}
                  copiesPerSheet={copies}
                  typography={typography}
                />
              ))}
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}

function ClassSheetCard({
  state,
  klass,
  lang,
  perPage,
  copiesPerSheet,
  typography,
}: {
  state: TimetableState;
  klass: Named;
  lang: Lang;
  perPage: PerPage;
  copiesPerSheet: CopiesPerSheet;
  typography?: SheetTypography;
}) {
  const rtl = isRtl(lang);
  const { days, periodsPerDay } = state;
  /* larger cells/type: each table spans the full page width */
  const baseS =
    perPage === 1 ? 1.7 : perPage === 2 ? 1.45 : perPage === 3 ? 1.15 : 0.95;
  const s = baseS / (copiesPerSheet === 1 ? 1 : copiesPerSheet * 0.85);
  const fontScale = s / 1.7;
  const titleSize = Math.max(8, Math.min(40, typography?.titleSize ?? 27));
  const daySize = Math.max(8, Math.min(40, typography?.daySize ?? 18));
  const bodySize = Math.max(8, Math.min(40, typography?.bodySize ?? 14));
  const typeWeight = 700;
  const px = (n: number) => `${Math.round(n * fontScale)}px`;
  const fontPx = (n: number, minimum: number) => `${Math.max(minimum, Math.round(n * fontScale))}px`;

  const base: React.CSSProperties = {
    borderTop: THIN,
    borderBottom: THIN,
    borderLeft: THIN,
    borderRight: THIN,
    padding: `${px(6)} ${px(4)}`,
    textAlign: "center",
    verticalAlign: "middle",
    fontSize: fontPx(bodySize, 11),
    fontWeight: typeWeight,
    lineHeight: 1.2,
    color: "#000",
    wordBreak: "break-word",
    overflowWrap: "anywhere",
  };

  return (
    <div
      style={{
        direction: rtl ? "rtl" : "ltr",
        fontFamily: "inherit",
        flex: 1,
        display: "flex",
        minHeight: 0,
      }}
    >
      <div
        className="sheet-glass-frame"
        style={{
          ...THIN_BOX,
          flex: 1,
          display: "flex",
          flexDirection: "column",
        }}
      >
        <div
          className="sheet-title-band vip-title-band"
          style={{
            ...({
              "--sheet-title-color": state.sheetTitleColor || SHEET_COLORS.title,
              "--sheet-title-text": state.sheetTitleTextColor || SHEET_COLORS.titleText,
            } as React.CSSProperties),
            background: state.sheetTitleColor || SHEET_COLORS.title,
            color: state.sheetTitleTextColor || SHEET_COLORS.titleText,
            borderBottom: THIN,
            padding: `${px(8)} ${px(4)}`,
            textAlign: "center",
          }}
        >
          <div style={{ fontSize: fontPx(titleSize * 1.25, 17), fontWeight: 700 }}>
            {tName(klass.name, lang)}
          </div>
        </div>

        <table
          style={{
            width: "100%",
            flex: 1,
            height: "100%",
            borderCollapse: "collapse",
            tableLayout: "fixed",
          }}
        >
          <thead style={{ height: "auto" }}>
            <tr>
                <th
                  style={{ ...base, fontSize: fontPx(titleSize, 14), background: SHEET_COLORS.head, width: "14%" }}
                >
                {t("sheet.days", lang)}
              </th>
              {Array.from({ length: periodsPerDay }, (_, p) => (
                  <th key={p} style={{ ...base, fontSize: fontPx(titleSize, 14), background: SHEET_COLORS.head }}>
                  {t("sheet.period", lang)} {p + 1}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {days.map(d => (
              <tr key={d.id}>
                <td
                  className="sheet-day-cell"
                  style={{ ...base, fontSize: fontPx(daySize, 13), background: SHEET_COLORS.day }}
                >
                  {tName(d.name, lang)}
                </td>
                {Array.from({ length: periodsPerDay }, (_, p) => {
                  const item = state.grid[klass.id]?.[d.id]?.[p] ?? null;
                  const subject = item ? nameOf(state.subjects, item.subjectId) : "";
                  return (
                    <td
                      key={p}
                      className={item ? "entity-color-cell" : undefined}
                      style={{
                        ...base,
                        fontSize: subject
                          ? `${Math.max(11, fitCellFont(subject, periodsPerDay, bodySize * fontScale))}px`
                          : fontPx(bodySize, 11),
                        background: SHEET_COLORS.subject,
                        ...(item
                          ? entityStyle(
                              item.teacherId,
                              "teacher",
                              rtl,
                              state.teachers.find(t => t.id === item.teacherId)
                                ?.color
                            )
                          : {}),
                      }}
                    >
                      {subject}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

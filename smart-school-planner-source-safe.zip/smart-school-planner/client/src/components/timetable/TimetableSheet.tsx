import { Fragment, useMemo } from "react";
import type { Named, TimetableState } from "@/lib/timetable-types";
import { pageGroups } from "@/lib/timetable-types";
import { nameOf, findConflicts } from "@/lib/scheduler";
import { t, tName, isRtl, getLang, type Lang } from "@/lib/i18n";
import { entityStyle } from "@/lib/entity-colors";
import type { LessonLocation } from "@/lib/scheduler";
import { sheetFontFamily, type SheetFont } from "@/lib/typography";

/* plain hex colors only — this markup is reused for print / PDF / canvas */
export const SHEET_COLORS = {
  line: "#8994b8",
  head: "#e0e6fb",
  head2: "#e9e6f8",
  day: "#f9efd9",
  period: "#dceafb",
  subject: "#eef1fc",
  teacher: "#eef1fc",
  note: "#f1ebfd",
  title: "#263577",
  titleText: "#ffffff",
  conflict: "#ff4d4d",
};

const THIN = `0.3mm solid ${SHEET_COLORS.line}`;
const THIN_BOX: React.CSSProperties = {
  borderTop: THIN,
  borderBottom: THIN,
  borderLeft: THIN,
  borderRight: THIN,
};
const THICK = `1.5mm solid ${SHEET_COLORS.line}`;

/** header-like bold text, shrinking with length so it never leaves the cell */
function fitFont(text: string, cols: number): number {
  const len = text.trim().length;
  const max = cols > 8 ? 13 : 16;
  if (len <= 8) return max;
  if (len <= 12) return Math.max(11, max - 2);
  if (len <= 18) return Math.max(10, max - 4);
  return 10;
}

/** Keep timetable content sizing consistent across weekly, class and teacher sheets. */
export function fitCellFont(text: string, cols: number, bodySize: number): number {
  // The user's body-size choice is the minimum size; long labels may still
  // receive a small readability adjustment, but never become smaller than it.
  return Math.max(bodySize, Math.round(fitFont(text, cols) * bodySize / 11));
}

export const SHEET_ID = "timetable-sheet";
export type SheetTypography = { font?: SheetFont; titleSize: number; daySize: number; bodySize: number; metadataSize?: number; bold: boolean };
export const cellKey = (location: LessonLocation) =>
  `${location.classId}|${location.dayId}|${location.period}`;
export const sheetPageId = (i: number) =>
  i === 0 ? SHEET_ID : `${SHEET_ID}-${i + 1}`;

/** all pages (1 or 2) stacked; each page is a full standalone sheet */
export function TimetableSheet({
  state,
  lang = getLang(),
  onLessonClick,
  onLessonDragStart,
  onLessonDrop,
  selectedLocation,
  lockedCells = [],
  lockMode = false,
  onToggleLock,
  typography,
}: {
  state: TimetableState;
  lang?: Lang;
  onLessonClick?: (location: LessonLocation) => void;
  onLessonDragStart?: (location: LessonLocation) => void;
  onLessonDrop?: (location: LessonLocation) => void;
  selectedLocation?: LessonLocation | null;
  lockedCells?: string[];
  lockMode?: boolean;
  onToggleLock?: (location: LessonLocation) => void;
  typography?: SheetTypography;
}) {
  const groups = pageGroups(state);
  return (
    <div
      id="timetable-pages"
      style={{ display: "flex", flexDirection: "column", gap: "12px" }}
    >
      {groups.map((classes, i) => (
        <TimetablePage
          key={i}
          state={state}
          classes={classes}
          id={sheetPageId(i)}
          lang={lang}
          pageNo={groups.length > 1 ? i + 1 : undefined}
          onLessonClick={onLessonClick}
          onLessonDragStart={onLessonDragStart}
          onLessonDrop={onLessonDrop}
          selectedLocation={selectedLocation}
          lockedCells={lockedCells}
          lockMode={lockMode}
          onToggleLock={onToggleLock}
          typography={typography}
        />
      ))}
    </div>
  );
}

export function TimetablePage({
  state,
  classes,
  id,
  lang = getLang(),
  pageNo,
  onLessonClick,
  onLessonDragStart,
  onLessonDrop,
  selectedLocation,
  lockedCells = [],
  lockMode = false,
  onToggleLock,
  typography,
}: {
  state: TimetableState;
  classes: Named[];
  id: string;
  lang?: Lang;
  pageNo?: number | undefined;
  onLessonClick?: (location: LessonLocation) => void;
  onLessonDragStart?: (location: LessonLocation) => void;
  onLessonDrop?: (location: LessonLocation) => void;
  selectedLocation?: LessonLocation | null;
  lockedCells?: string[];
  lockMode?: boolean;
  onToggleLock?: (location: LessonLocation) => void;
  typography?: SheetTypography;
}) {
  const rtl = isRtl(lang);
  const sideEdge = rtl ? "borderLeft" : "borderRight";
  const { days, periodsPerDay } = state;
  const titleSize = Math.max(8, Math.min(40, typography?.titleSize ?? 23));
  const daySize = Math.max(8, Math.min(40, typography?.daySize ?? 15));
  const bodySize = Math.max(8, Math.min(40, typography?.bodySize ?? 11));
  const metadataSize = Math.max(8, Math.min(40, typography?.metadataSize ?? bodySize));
  const typeWeight = 700;

  const conflictKeys = useMemo(() => {
    const set = new Set<string>();
    for (const c of findConflicts(state))
      for (const cid of c.classIds) set.add(`${cid}|${c.dayId}|${c.period}`);
    return set;
  }, [state]);

  const base: React.CSSProperties = {
    borderTop: THIN,
    borderBottom: THIN,
    borderLeft: THIN,
    borderRight: THIN,
    padding: "2px 3px",
    textAlign: "center",
    verticalAlign: "middle",
    fontSize: `${bodySize}px`,
    fontWeight: typeWeight,
    lineHeight: 1.15,
    color: "#000",
    wordBreak: "break-word",
    overflowWrap: "anywhere",
    whiteSpace: "normal",
    overflow: "hidden",
  };

  const headCell: React.CSSProperties = {
    ...base,
    fontSize: `${titleSize}px`,
    fontWeight: typeWeight,
  };
  const nCols = classes.length;

  return (
    <div
      id={id}
      className="timetable-page"
      style={{
        ...({
          "--sheet-title-color": state.sheetTitleColor || SHEET_COLORS.title,
          "--sheet-title-text": state.sheetTitleTextColor || SHEET_COLORS.titleText,
          "--sheet-font-family": sheetFontFamily(typography?.font),
        } as React.CSSProperties),
        background: "#fff",
        padding: "6px",
        color: "#000",
        fontFamily: sheetFontFamily(typography?.font),
        direction: rtl ? "rtl" : "ltr",
        width: "100%",
        minHeight: 0,
        display: "flex",
        flexDirection: "column",
      }}
    >
      <div
        className="sheet-glass-frame"
        style={{
          ...THIN_BOX,
          flex: "1 1 auto",
          minHeight: 0,
          display: "flex",
          flexDirection: "column",
        }}
      >
        <div
          className="sheet-title-band vip-title-band"
          style={{
            ...({
              "--sheet-title-color": state.sheetTitleColor || SHEET_COLORS.title,
              "--sheet-title-text": state.sheetTitleTextColor || SHEET_COLORS.titleText,
            } as React.CSSProperties),
            background: state.sheetTitleColor || SHEET_COLORS.title,
            color: state.sheetTitleTextColor || SHEET_COLORS.titleText,
            borderBottom: THIN,
            padding: "6px 4px",
            textAlign: "center",
            position: "relative",
          }}
        >
          <div
            style={{
              position: "absolute",
              top: "6px",
              right: "8px",
              textAlign: "right",
              fontSize: `${Math.round(titleSize * .7)}px`,
              fontWeight: typeWeight,
              lineHeight: 1.25,
            }}
          >
            <div>{state.directorate}</div>
            <div>{state.schoolName}</div>
          </div>
              <div style={{ fontSize: `${titleSize}px`, fontWeight: typeWeight }}>
            {t("sheet.title", lang)}
          </div>
              <div style={{ fontSize: `${Math.round(titleSize * .78)}px`, fontWeight: typeWeight }}>
            {t("sheet.year", lang)} {state.year}
          </div>
          {pageNo && (
            <div
              style={{
                position: "absolute",
                top: "4px",
                [rtl ? "left" : "right"]: "8px",
                fontSize: "11px",
                fontWeight: 700,
                opacity: 0.9,
              }}
            >
              {t("sheet.page", lang)} {pageNo}
            </div>
          )}
        </div>

        <table
          style={{
            width: "100%",
            flex: "1 1 auto",
            height: "100%",
            minHeight: 0,
            borderCollapse: "collapse",
            tableLayout: "fixed",
          }}
        >
          <thead>
            <tr>
              <th
                className="sheet-head-primary"
                style={{
                  ...headCell,
                  background: SHEET_COLORS.head,
                  width: "7%",
                }}
                rowSpan={2}
              >
                {t("sheet.days", lang)}
              </th>
              <th
                className="sheet-head-primary"
                style={{
                  ...headCell,
                  background: SHEET_COLORS.head,
                  width: "5%",
                  [sideEdge]: THICK,
                }}
                rowSpan={2}
              >
                {t("sheet.period", lang)}
              </th>
              {classes.map(c => (
                <th
                  key={c.id}
                  className="sheet-head-primary"
                  style={{
                    ...headCell,
                    background: SHEET_COLORS.head,
                    [sideEdge]: THICK,
                  }}
                  colSpan={2}
                >
                  {tName(c.name, lang)}
                </th>
              ))}
            </tr>
            <tr>
              {classes.map(c => (
                <Fragment key={c.id}>
                  <th
                    className="sheet-head-secondary"
                    style={{ ...headCell, background: SHEET_COLORS.head2 }}
                  >
                    {t("sheet.subject", lang)}
                  </th>
                  <th
                    className="sheet-head-secondary"
                    style={{
                      ...headCell,
                      background: SHEET_COLORS.head2,
                      [sideEdge]: THICK,
                    }}
                  >
                    {t("sheet.teacher", lang)}
                  </th>
                </Fragment>
              ))}
            </tr>
          </thead>
          <tbody>
            {days.map((d, dIdx) =>
              Array.from({ length: periodsPerDay }, (_, p) => {
                const lastOfDay =
                  p === periodsPerDay - 1 && dIdx < days.length - 1;
                const rowEdge: React.CSSProperties = lastOfDay
                  ? { borderBottom: THICK }
                  : {};
                return (
                  <tr key={`${d.id}-${p}`}>
                    {p === 0 && (
                      <td
                        className="sheet-day-cell"
                        style={{
                          ...base,
                          fontSize: `${daySize}px`,
                          background: SHEET_COLORS.day,
                          fontWeight: 700,
                          ...(dIdx < days.length - 1
                            ? { borderBottom: THICK }
                            : {}),
                        }}
                        rowSpan={periodsPerDay}
                      >
                        {tName(d.name, lang)}
                      </td>
                    )}
                    <td
                      className="sheet-period-cell"
                      style={{
                        ...base,
                        fontSize: `${daySize}px`,
                        background: SHEET_COLORS.period,
                        fontWeight: 700,
                        [sideEdge]: THICK,
                        ...rowEdge,
                      }}
                    >
                      {p + 1}
                    </td>
                    {classes.map(c => {
                      const item = state.grid[c.id]?.[d.id]?.[p] ?? null;
                      const location = {
                        classId: c.id,
                        dayId: d.id,
                        period: p,
                      };
                      const isSelected =
                        selectedLocation?.classId === c.id &&
                        selectedLocation.dayId === d.id &&
                        selectedLocation.period === p;
                      const isLocked = lockedCells.includes(cellKey(location));
                      const isInteractive = !!item && !!onLessonClick && !isLocked;
                      const canActivate = lockMode
                        ? !!onToggleLock
                        : isInteractive || (!!selectedLocation && !!onLessonClick && !isLocked);
                      const activate = () => {
                        if (lockMode) onToggleLock?.(location);
                        else if (canActivate && !isLocked) onLessonClick?.(location);
                      };
                      const keyboardActivate = (
                        event: React.KeyboardEvent<HTMLTableCellElement>
                      ) => {
                        if (event.key !== "Enter" && event.key !== " ") return;
                        event.preventDefault();
                        activate();
                      };
                      const startDrag = (
                        event: React.DragEvent<HTMLTableCellElement>
                      ) => {
                        if (lockMode || !isInteractive) return;
                        event.dataTransfer.effectAllowed = "move";
                        event.dataTransfer.setData("text/plain", "lesson-swap");
                        onLessonDragStart?.(location);
                      };
                      const allowDrop = (
                        event: React.DragEvent<HTMLTableCellElement>
                      ) => {
                        if (!onLessonDrop || isLocked) return;
                        event.preventDefault();
                        event.dataTransfer.dropEffect = "move";
                      };
                      const dropLesson = (
                        event: React.DragEvent<HTMLTableCellElement>
                      ) => {
                        if (!onLessonDrop || isLocked) return;
                        event.preventDefault();
                        onLessonDrop(location);
                      };
                      const bad = conflictKeys.has(`${c.id}|${d.id}|${p}`);
                      const subj = item
                        ? nameOf(state.subjects, item.subjectId)
                        : "";
                      const teach = item
                        ? nameOf(state.teachers, item.teacherId)
                        : "";
                      return (
                        <Fragment key={c.id}>
                          <td
                            className={
                              bad
                                ? `sheet-conflict-cell entity-color-cell${isSelected ? " lesson-swap-selected" : ""}${isInteractive ? " lesson-swap-cell" : ""}`
                                : item
                                  ? `sheet-subject-cell entity-color-cell${isSelected ? " lesson-swap-selected" : ""}${isInteractive ? " lesson-swap-cell" : ""}`
                                  : `sheet-subject-cell${canActivate ? " lesson-swap-cell" : ""}${isLocked ? " timetable-locked-cell" : ""}`
                            }
                            tabIndex={canActivate ? 0 : undefined}
                            aria-label={
                              canActivate
                                ? `${tName(c.name, lang)}, ${tName(d.name, lang)}, ${t("sheet.period", lang)} ${p + 1}: ${subj || t("common.none", lang)}, ${teach}`
                                : undefined
                            }
                            aria-pressed={canActivate ? isSelected : undefined}
                            draggable={isInteractive && !!onLessonDragStart}
                            onClick={activate}
                            onKeyDown={keyboardActivate}
                            onDragStart={startDrag}
                            onDragOver={allowDrop}
                            onDrop={dropLesson}
                            style={{
                              ...base,
                              ...rowEdge,
                              fontWeight: 700,
                              fontSize: `${fitCellFont(subj, nCols, bodySize)}px`,
                              background: bad
                                ? SHEET_COLORS.conflict
                                : SHEET_COLORS.subject,
                              ...(item
                                ? entityStyle(
                                    item.teacherId,
                                    "teacher",
                                    rtl,
                                    state.teachers.find(
                                      t => t.id === item.teacherId
                                    )?.color
                                  )
                                : {}),
                              ...(isLocked
                                ? { opacity: 0.72, boxShadow: "inset 0 0 0 2px #536cc9" }
                                : {}),
                              ...(bad
                                ? {
                                    backgroundColor:
                                      "rgba(255, 100, 100, 0.82)",
                                  }
                                : {}),
                            }}
                          >
                            {isLocked ? "🔒 " : ""}{subj}
                          </td>
                          <td
                            className={
                              bad
                                ? `sheet-conflict-cell entity-color-cell${isSelected ? " lesson-swap-selected" : ""}${isInteractive ? " lesson-swap-cell" : ""}`
                                : item
                                  ? `sheet-teacher-cell entity-color-cell${isSelected ? " lesson-swap-selected" : ""}${isInteractive ? " lesson-swap-cell" : ""}`
                                  : `sheet-teacher-cell${canActivate ? " lesson-swap-cell" : ""}${isLocked ? " timetable-locked-cell" : ""}`
                            }
                            tabIndex={canActivate ? 0 : undefined}
                            aria-label={
                              canActivate
                                ? `${tName(c.name, lang)}, ${tName(d.name, lang)}, ${t("sheet.period", lang)} ${p + 1}: ${subj || t("common.none", lang)}, ${teach}`
                                : undefined
                            }
                            aria-pressed={canActivate ? isSelected : undefined}
                            draggable={isInteractive && !!onLessonDragStart}
                            onClick={activate}
                            onKeyDown={keyboardActivate}
                            onDragStart={startDrag}
                            onDragOver={allowDrop}
                            onDrop={dropLesson}
                            style={{
                              ...base,
                              ...rowEdge,
                              fontWeight: 700,
                              fontSize: `${fitCellFont(teach, nCols, bodySize)}px`,
                              [sideEdge]: THICK,
                              background: bad
                                ? SHEET_COLORS.conflict
                                : SHEET_COLORS.teacher,
                              ...(item
                                ? entityStyle(
                                    item.teacherId,
                                    "teacher",
                                    rtl,
                                    state.teachers.find(
                                      t => t.id === item.teacherId
                                    )?.color
                                  )
                                : {}),
                              ...(isLocked
                                ? { opacity: 0.72, boxShadow: "inset 0 0 0 2px #536cc9" }
                                : {}),
                              ...(bad
                                ? {
                                    backgroundColor:
                                      "rgba(255, 100, 100, 0.82)",
                                  }
                                : {}),
                            }}
                          >
                            {teach}
                          </td>
                        </Fragment>
                      );
                    })}
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      <div
        className="sheet-footer"
        style={{
          marginTop: "auto",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          gap: "8px",
        }}
      >
        <div
          className="sheet-note-cell"
          style={{
            background: SHEET_COLORS.note,
            ...THIN_BOX,
            padding: "4px 8px",
            fontSize: `${metadataSize}px`,
            fontWeight: 700,
            textAlign: rtl ? "right" : "left",
          }}
        >
          {t("sheet.noteA", lang)} {state.startDate} {t("sheet.noteB", lang)}
        </div>
        <div
          style={{
            textAlign: rtl ? "left" : "right",
            fontSize: `${metadataSize}px`,
            fontWeight: 700,
          }}
        >
          <div>{t("sheet.principal", lang)}</div>
          <div>{state.principal}</div>
        </div>
      </div>
    </div>
  );
}

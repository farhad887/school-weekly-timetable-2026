#!/usr/bin/env bash
set -euo pipefail
OUT=/home/ubuntu/tutorial-assets
cat > "$OUT/audio-list.txt" <<EOF
file '$OUT/comprehensive-narration-1.wav'
file '$OUT/comprehensive-narration-2.wav'
EOF
ffmpeg -y -f concat -safe 0 -i "$OUT/audio-list.txt" -c copy "$OUT/comprehensive-narration.wav"
ffmpeg -y \
  -loop 1 -t 14 -i "$OUT/step-01-add-teacher.webp" \
  -loop 1 -t 14 -i "$OUT/step-02-add-subject.webp" \
  -loop 1 -t 14 -i "$OUT/step-03-lesson-added.webp" \
  -loop 1 -t 14 -i "$OUT/step-04-auto-timetable.webp" \
  -loop 1 -t 12 -i "$OUT/step-05-export-options.webp" \
  -loop 1 -t 16 -i "$OUT/step-06-forms-and-table.webp" \
  -loop 1 -t 14 -i "$OUT/step-07-lower-table-sections.webp" \
  -loop 1 -t 14 -i "$OUT/step-08-settings-classes.webp" \
  -i "$OUT/comprehensive-narration.wav" \
  -filter_complex "[0:v]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=0x0b2f26,format=yuv420p[v0];[1:v]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=0x0b2f26,format=yuv420p[v1];[2:v]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=0x0b2f26,format=yuv420p[v2];[3:v]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=0x0b2f26,format=yuv420p[v3];[4:v]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=0x0b2f26,format=yuv420p[v4];[5:v]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=0x0b2f26,format=yuv420p[v5];[6:v]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=0x0b2f26,format=yuv420p[v6];[7:v]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=0x0b2f26,format=yuv420p[v7];[v0][v1][v2][v3][v4][v5][v6][v7]concat=n=8:v=1:a=0[v]" \
  -map "[v]" -map 8:a -c:v libx264 -preset medium -crf 23 -r 30 -c:a aac -b:a 128k -shortest -movflags +faststart "$OUT/khshta-heftane-tutorial-comprehensive.mp4"
ffprobe -v error -show_entries format=duration,size -of default=nw=1 "$OUT/khshta-heftane-tutorial-comprehensive.mp4"

#!/usr/bin/env bash
set -euo pipefail
OUT=/home/ubuntu/tutorial-assets
ffmpeg -y \
  -loop 1 -t 11.5 -i "$OUT/step-01-add-teacher.webp" \
  -loop 1 -t 11.5 -i "$OUT/step-02-add-subject.webp" \
  -loop 1 -t 13.0 -i "$OUT/step-03-lesson-added.webp" \
  -loop 1 -t 12.5 -i "$OUT/step-04-auto-timetable.webp" \
  -loop 1 -t 10.7 -i "$OUT/step-05-export-options.webp" \
  -i "$OUT/tutorial-narration.wav" \
  -filter_complex "[0:v]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=0x0b2f26,format=yuv420p[v0];[1:v]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=0x0b2f26,format=yuv420p[v1];[2:v]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=0x0b2f26,format=yuv420p[v2];[3:v]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=0x0b2f26,format=yuv420p[v3];[4:v]scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2:color=0x0b2f26,format=yuv420p[v4];[v0][v1][v2][v3][v4]concat=n=5:v=1:a=0[v]" \
  -map "[v]" -map 5:a -c:v libx264 -preset medium -crf 23 -r 30 -c:a aac -b:a 128k -shortest -movflags +faststart "$OUT/khshta-heftane-tutorial.mp4"
ffprobe -v error -show_entries format=duration,size -of default=nw=1 "$OUT/khshta-heftane-tutorial.mp4"

from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter

OUT = Path(__file__).resolve().parents[1] / "client" / "public"
OUT.mkdir(parents=True, exist_ok=True)
SIZE = 512
SCALE = 3
HI = SIZE * SCALE


def blend(a, b, t):
    return tuple(round(x + (y - x) * t) for x, y in zip(a, b))


def make_icon():
    # Cool indigo-to-periwinkle background with a soft light bloom.
    image = Image.new("RGBA", (SIZE, SIZE))
    pixels = image.load()
    start, middle, end = (35, 43, 83), (61, 77, 148), (113, 126, 210)
    for y in range(SIZE):
        for x in range(SIZE):
            t = min(1, (0.56 * x + 0.8 * y) / (SIZE * 1.28))
            color = blend(start, middle, t / 0.58) if t < 0.58 else blend(middle, end, (t - 0.58) / 0.42)
            glow = max(0, 1 - (((x - 390) ** 2 + (y - 95) ** 2) ** 0.5 / 390)) * 0.12
            pixels[x, y] = tuple(min(255, round(c + (175 - c) * glow)) for c in color) + (255,)

    image = image.resize((HI, HI), Image.Resampling.LANCZOS)
    glow = Image.new("RGBA", (HI, HI))
    gd = ImageDraw.Draw(glow)
    gd.ellipse((HI * .57, HI * .02, HI * 1.10, HI * .55), fill=(165, 208, 255, 95))
    gd.ellipse((-HI * .20, HI * .60, HI * .42, HI * 1.2), fill=(185, 158, 255, 70))
    glow = glow.filter(ImageFilter.GaussianBlur(56 * SCALE))
    image = Image.alpha_composite(image, glow)
    draw = ImageDraw.Draw(image)

    def box(x1, y1, x2, y2, radius, fill, outline=None, width=1):
        draw.rounded_rectangle(
            tuple(round(v * SCALE) for v in (x1, y1, x2, y2)),
            radius=round(radius * SCALE),
            fill=fill,
            outline=outline,
            width=max(1, round(width * SCALE)),
        )

    def line(points, fill, width=1):
        draw.line([(round(x * SCALE), round(y * SCALE)) for x, y in points], fill=fill, width=round(width * SCALE), joint="curve")

    # Outer glass bezel.
    box(48, 48, 464, 464, 104, (255, 255, 255, 25), (255, 255, 255, 112), 2)
    box(61, 61, 451, 451, 94, (226, 235, 255, 22), (255, 255, 255, 46), 1)

    # Soft shadow and translucent calendar card.
    shadow = Image.new("RGBA", (HI, HI))
    sd = ImageDraw.Draw(shadow)
    sd.rounded_rectangle((105*SCALE, 112*SCALE, 407*SCALE, 417*SCALE), radius=42*SCALE, fill=(12, 19, 52, 95))
    shadow = shadow.filter(ImageFilter.GaussianBlur(15*SCALE))
    image = Image.alpha_composite(image, shadow)
    draw = ImageDraw.Draw(image)
    box(105, 101, 407, 406, 42, (249, 251, 255, 242), (255, 255, 255, 255), 2)

    # Glossy calendar header with a true rounded gradient mask.
    header_width, header_height = 274 * SCALE, 92 * SCALE
    header = Image.new("RGBA", (header_width, header_height))
    header_draw = ImageDraw.Draw(header)
    for y in range(header_height):
        t = y / max(1, header_height - 1)
        header_draw.line((0, y, header_width, y), fill=blend((118, 150, 238), (103, 192, 234), t) + (255,))
    header_mask = Image.new("L", (header_width, header_height), 0)
    ImageDraw.Draw(header_mask).rounded_rectangle((0, 0, header_width-1, header_height-1), radius=31*SCALE, fill=255)
    image.paste(header, (119*SCALE, 115*SCALE), header_mask)
    draw = ImageDraw.Draw(image)
    draw.rounded_rectangle((119*SCALE, 115*SCALE, 393*SCALE, 207*SCALE), radius=31*SCALE, outline=(255,255,255,190), width=2*SCALE)
    draw.rounded_rectangle((119*SCALE, 115*SCALE, 393*SCALE, 207*SCALE), radius=31*SCALE, outline=(255,255,255,190), width=2*SCALE)
    # White binder loops.
    for x in (184, 328):
        box(x-8, 91, x+8, 151, 8, (246, 249, 255, 255), (255,255,255,255), 1)
        box(x-3, 101, x+3, 133, 3, (73, 92, 170, 170))

    # Timetable tiles, with a few luminous accent cells.
    cells = [
        ((129, 222), (123, 144, 220)), ((199, 222), (118, 197, 224)), ((269, 222), (162, 146, 231)),
        ((129, 277), (182, 196, 242)), ((199, 277), (119, 155, 231)), ((269, 277), (125, 204, 226)),
        ((129, 332), (161, 149, 228)), ((199, 332), (206, 216, 248)), ((269, 332), (144, 188, 232)),
    ]
    for (x, y), rgb in cells:
        box(x, y, x+53, y+38, 12, rgb + (255,), (255,255,255,225), 1)
        box(x+9, y+10, x+44, y+15, 3, (255,255,255,175))
        box(x+9, y+22, x+34, y+26, 2, (255,255,255,125))

    # Floating glass check badge.
    box(322, 321, 411, 410, 45, (239, 246, 255, 232), (255,255,255,255), 2)
    box(330, 329, 403, 402, 37, (112, 132, 220, 255), (255,255,255,105), 1)
    line([(348, 366), (361, 379), (387, 349)], (255,255,255,255), 8)

    # A fine light streak gives the icon a glass highlight without obscuring detail.
    line([(89, 111), (142, 76), (208, 65)], (255,255,255,72), 2)
    return image.resize((SIZE, SIZE), Image.Resampling.LANCZOS)


master = make_icon()
for name, size in [
    ("icon-512.png", 512),
    ("icon-192.png", 192),
    ("apple-touch-icon.png", 180),
    ("favicon.png", 64),
]:
    master.resize((size, size), Image.Resampling.LANCZOS).save(OUT / name, format="PNG", optimize=True)

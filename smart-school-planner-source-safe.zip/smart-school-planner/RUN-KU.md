# بەرنامەی پلانی قوتابخانە

نووسینی ناو بەرنامەکە بە شێوەی بنەڕەتی ڕەش، تۆخ و گەورەترە؛ لە خانەکان، دوگمەکان، کارت و خشتەکاندا جێبەجێ کراوە.

```bash
pnpm install --frozen-lockfile
NODE_ENV=production PORT=3000 pnpm start
```

package com.smartschoolplanner.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Base64;

public class MainActivity extends Activity {
    private static final int STORAGE_PERMISSION_REQUEST = 41;
    private WebView webView;
    private String pendingName;
    private String pendingBase64;
    private String pendingMime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMediaPlaybackRequiresUserGesture(false);

        webView.addJavascriptInterface(new DownloadBridge(), "AndroidDownloader");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                installDownloadBridge();
            }
        });
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private void installDownloadBridge() {
        String script = "javascript:(function(){"
                + "if(window.__androidDownloadsInstalled)return;window.__androidDownloadsInstalled=true;"
                + "document.addEventListener('click',function(e){"
                + "var a=e.target.closest&&e.target.closest('a[download]');if(!a)return;"
                + "var u=a.href;if(!u||(!u.startsWith('blob:')&&!u.startsWith('data:')))return;"
                + "e.preventDefault();var n=a.getAttribute('download')||'download';"
                + "fetch(u).then(function(r){return r.blob()}).then(function(b){"
                + "var fr=new FileReader();fr.onloadend=function(){"
                + "AndroidDownloader.save(n,fr.result.split(',')[1],b.type||'application/octet-stream');};fr.readAsDataURL(b);"
                + "}).catch(function(){AndroidDownloader.failed();});"
                + "},true);"
                + "})()";
        webView.evaluateJavascript(script, null);
    }

    private void requestOrSave(String name, String base64, String mime) {
        pendingName = sanitizeName(name);
        pendingBase64 = base64;
        pendingMime = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_PERMISSION_REQUEST);
        } else {
            saveFileNow();
        }
    }

    private String sanitizeName(String name) {
        if (name == null || name.trim().isEmpty()) return "school-planner-file";
        return name.replaceAll("[\\\\/:*?\\\"<>|]", "_");
    }

    private void saveFileNow() {
        if (pendingBase64 == null) return;
        try {
            byte[] bytes = Base64.getDecoder().decode(pendingBase64);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Downloads.DISPLAY_NAME, pendingName);
                values.put(MediaStore.Downloads.MIME_TYPE, pendingMime);
                values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                values.put(MediaStore.Downloads.IS_PENDING, 1);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                if (uri == null) throw new IllegalStateException("Cannot create download");
                try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                    if (out == null) throw new IllegalStateException("Cannot open download");
                    out.write(bytes);
                }
                values.clear();
                values.put(MediaStore.Downloads.IS_PENDING, 0);
                getContentResolver().update(uri, values, null, null);
            } else {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Cannot create Downloads");
                File file = new File(dir, pendingName);
                try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
            }
            Toast.makeText(this, "فایلەکە لە Downloads هەڵگیرا", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "هەڵە لە هەڵگرتنی فایلەکە", Toast.LENGTH_LONG).show();
        } finally {
            pendingName = null;
            pendingBase64 = null;
            pendingMime = null;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == STORAGE_PERMISSION_REQUEST && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            saveFileNow();
        } else {
            Toast.makeText(this, "مۆڵەتی هەڵگرتنی فایل پێویستە", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    private class DownloadBridge {
        @JavascriptInterface
        public void save(String name, String base64, String mime) {
            runOnUiThread(() -> requestOrSave(name, base64, mime));
        }

        @JavascriptInterface
        public void failed() {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "داگرتنی فایل سەرکەوتوو نەبوو", Toast.LENGTH_LONG).show());
        }
    }
}

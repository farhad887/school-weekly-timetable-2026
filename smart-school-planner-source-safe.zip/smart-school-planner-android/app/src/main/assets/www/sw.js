const CACHE = "school-planner-offline-v9";
const CORE = [
  "/",
  "/manifest.webmanifest",
  "/offline-precache.json",
  "/favicon.png",
  "/apple-touch-icon.png",
  "/icon-192.png",
  "/icon-512.png",
];

self.addEventListener("install", event => {
  event.waitUntil(
    (async () => {
      const response = await fetch("/offline-precache.json", { cache: "no-store" });
      if (!response.ok) throw new Error("Offline asset manifest is unavailable");
      const assets = await response.json();
      const urls = [...new Set([...CORE, ...(Array.isArray(assets) ? assets : [])])];
      const origin = self.location.origin;
      if (urls.some(url => typeof url !== "string" || !url.startsWith("/") || url.startsWith("//"))) {
        throw new Error("Offline manifest contains a non-local asset");
      }
      const cache = await caches.open(CACHE);
      await cache.addAll(urls.map(url => new Request(new URL(url, origin).href, { cache: "reload" })));
      await self.skipWaiting();
    })()
  );
});

self.addEventListener("activate", event => {
  event.waitUntil(
    (async () => {
      const keys = await caches.keys();
      await Promise.all(
        keys
          .filter(key => key !== CACHE && (key.startsWith("school-planner-offline-") || /^khshta-v\d+$/.test(key)))
          .map(key => caches.delete(key))
      );
      await self.clients.claim();
    })()
  );
});

self.addEventListener("fetch", event => {
  const request = event.request;
  if (request.method !== "GET") return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    (async () => {
      const cache = await caches.open(CACHE);
      const isNavigation = request.mode === "navigate";
      if (!isNavigation) {
        const cached = await cache.match(request);
        if (cached) return cached;
      }

      try {
        const response = await fetch(request);
        if (response.ok && response.type === "basic") {
          await cache.put(request, response.clone()).catch(() => {});
        }
        return response;
      } catch {
        const cached = await cache.match(request);
        if (cached) return cached;
        if (isNavigation) {
          const appShell = await cache.match("/");
          if (appShell) return appShell;
        }
        return Response.error();
      }
    })()
  );
});

# خشتەی هەفتانەی قوتابخانە — ئامادەکراو بۆ Google Play

ئەم پڕۆژەیە wrapper ـی Android ـە بۆ هەمان build ـی وێبی ئەسڵی. کۆدی `/home/ubuntu/smart-school-planner` دەستکاری نەکراوە.

## فایلە ئامادەکان

- `app/build/outputs/bundle/release/app-release.aab` — فایلە پێویستەکە بۆ Google Play Console
- `app/build/outputs/apk/release/app-release.apk` — بۆ تاقیکردنەوەی ڕاستەوخۆ لەسەر Android
- `release-keystore.jks` — کلیلەی واژۆی release؛ بە هیچ شێوەیەک مەسڕەوە و مەگۆڕە

## زانیاریی ئەپ

- ناوی ئەپ: خشتەی هەفتانەی قوتابخانە
- Application ID: `com.smartschoolplanner.app`
- Version name: `1.0.0`
- Version code: `1`
- Target SDK: `35`
- فایلە دروستکراوەکان: PDF، Excel و Word لە Downloads هەڵدەگیرێن

## هەنگاوەکانی Google Play Console

1. بچۆ `play.google.com/console` و حسابی Developer دروست/چالاک بکە.
2. **Create app** هەڵبژێرە.
3. زمانی ئەپ و ناوی `خشتەی هەفتانەی قوتابخانە` دابنێ.
4. لە **Testing > Internal testing** یان **Production**، فایلەی `app-release.aab` upload بکە.
5. لە **App content**، خانەکانی Data safety و Content rating پڕبکەرەوە.
6. لینکێکی Privacy Policy زیاد بکە؛ ئەپەکە داتا لە ناوخۆی ئامێری بەکارهێنەر لە localStorage هەڵدەگرێت.
7. screenshot ـی مۆبایل و icon ـی ئەپ زیاد بکە.
8. Release ـەکە بۆ review بنێرە.

## تێبینیی گرنگ

- ئەم `AAB` ـە بە کلیلەی release واژۆ کراوە.
- وشەی نهێنیی keystore: `SmartSchoolPlanner@2026`
- alias: `smart-school-planner`
- ئەگەر `release-keystore.jks` ون بکرێت، نوێکردنەوەی هەمان ئەپ لە Google Play کێشەی لێدەکەوێت.
- بڵاوکردنەوەی کۆتایی، پڕکردنەوەی Data safety و ناردنی review پێویستی بە چوونەژوورەوەی حسابی Google ـی خۆتە.
- تاقیکردنەوەی ئەپی native لەسەر ئامێری فیزیکی لەم sandbox ـەدا نەکراوە؛ APK ـەکە بۆ تاقیکردنەوە ئامادەیە.
